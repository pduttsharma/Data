var app = angular.module('myApp', []);
app.controller('blockExplorer', function($scope, $http) {

    var peerDetails = [{
        "id": "1",
        "name": "org1-peer1",
        "organization": "mojani",
        "mspId": "ORG1",
        "request": "grpcs://n86b2e7d346474627a9fe5f2cf562cc28-org1-peer1.us02.blockchain.ibm.com:31002"
    }, {
        "id": "2",
        "name": "org2-peer1",
        "organization": "kaveri",
        "mspId": "ORG2",
        "request": "grpcs://n86b2e7d346474627a9fe5f2cf562cc28-org2-peer1.us02.blockchain.ibm.com:31002"
    }, {
        "id": "3",
        "name": "org3-peeraf45",
        "organization": "loan",
        "mspId": "ORG3",
        "request": "grpcs://n86b2e7d346474627a9fe5f2cf562cc28-org3-peeraf45.us02.blockchain.ibm.com:31002"
    }];

    $scope.peerData = peerDetails;

    //Intial Page Load Will Show Current Block Data
    $scope.initialLoad = function() {
        $scope.owner = false;
        $scope.property = false;
        $scope.network = false;
        $scope.back = false;
        $scope.forward = false;
        $('#loading').show();
        $http({
            method: 'POST',
            url: '/blockChainData'
        }).then(function successCallback(response) {
            $('#loading').hide();
            $scope.forward = true;
            console.log(response);
            var currentBlockNo = response.data.channelData.peer['org1-peer1'];
            currentBlockNo = currentBlockNo.height.low;
            $scope.current_block_no = currentBlockNo;
            $scope.total_blocks = currentBlockNo;
            var msg = {
                aadharNo: "aadhar number",
                transactionId: "Txn Id : ",
                pid: "pid",
                colon: " : ",
                currentBlock: "BLOCK # ",
                blockNo: $scope.current_block_no
            }
            $scope.msg = msg;
            var txnData = response.data.current_block_data.parsed.txs;
            if (txnData.length > 0) {
                for (var i = 0; i < txnData.length; i++) {
                    var txnId = txnData[i].tx_id;
                    var channel_update = txnData[i].channel_update;
                    if (channel_update) {
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                    } else {
                        console.log(txnData[i].write_set.length);
                        if (txnData[i].write_set.length > 0) {
                            for (var m = 0; m < txnData[i].write_set.length; m++) {
                                var write_set = txnData[i].write_set[m];
                                var value = JSON.parse(write_set.value);
                                if(value['$class']){
                                    var txn_class = value['$class'];
                                    txn_class = txn_class.substring(txn_class.lastIndexOf(".") + 1);
                                    if (txn_class == "UpdateLandDetails" && value['landrecord']) {
                                        $scope.chaincode = "kaveri";
                                        $scope.peer = "org2-peer1";
                                        $scope.owner = true;
                                        $scope.property = true;
                                        var pid = value.landrecord;
                                        pid = pid.substring(pid.lastIndexOf("#") + 1);
                                        var landDetails = {
                                            pid: pid,
                                            txnId: txnId,
                                            msg: "Land record details updated with "
                                        }
                                        $scope.currentLandDetails = landDetails;

                                        var aadharNo = value.newOwner;
                                        aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                                        var ownerDetails = {
                                            aadharNo: aadharNo,
                                            txnId: txnId,
                                            msg: "Owner updated to this land with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    } else if (txn_class == "AddOwner" && value['owner']) {
                                        $scope.chaincode = "kaveri";
                                        $scope.peer = "org2-peer1";
                                        $scope.owner = true;
                                        var ownerDetails = {
                                            aadharNo: value.owner.aadharNo,
                                            txnId: txnId,
                                            msg: "Owner added with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    } else if (txn_class == "AddLandRecord" && value['landrecord']) {
                                        $scope.chaincode = "mojani";
                                        $scope.peer = "org1-peer1";
                                        $scope.property = true;
                                        var landDetails = {
                                            pid: value.landrecord.pid,
                                            txnId: txnId,
                                            msg: "Land record inserted with "
                                        }
                                        $scope.currentLandDetails = landDetails;
                                    } else if (txn_class == "AddAssignee" && value['owner']) {
                                        $scope.chaincode = "mojani";
                                        $scope.peer = "org1-peer1";
                                        $scope.owner = true;
                                        var ownerDetails = {
                                            aadharNo: value.owner.aadharNo,
                                            txnId: txnId,
                                            msg: "Owner assigned to this land with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    }
                                }
                            }
                        } else {
                            $scope.network = true;
                            var network = {
                                msg: "Network/Channel Update"
                            }
                            $scope.network = network;
                        }
                    }
                }if(!$scope.owner && !$scope.property){
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                  }
            } else {
                $scope.network = true;
                var network = {
                    msg: "Network/Channel Update"
                }
                $scope.network = network;
            }
        });
    }


    // On click Of Refresh Button
    $scope.refreshPage = function() {
        $scope.owner = false;
        $scope.property = false;
        $scope.network = false;
        $scope.back = false;
        $scope.forward = false;
        $('#loading').show();
        $http({
            method: 'POST',
            url: '/blockChainData'
        }).then(function successCallback(response) {
            $('#loading').hide();
            $scope.chaincode = "landrecord";
            $scope.forward = true;
            console.log(response);
            var currentBlockNo = response.data.channelData.peer['org1-peer1'];
            currentBlockNo = currentBlockNo.height.low;
            $scope.current_block_no = currentBlockNo;
            $scope.total_blocks = currentBlockNo;
            var msg = {
                aadharNo: "aadhar number",
                transactionId: "Txn Id : ",
                pid: "pid",
                colon: " : ",
                currentBlock: "BLOCK # ",
                blockNo: $scope.current_block_no
            }
            $scope.msg = msg;
            var txnData = response.data.current_block_data.parsed.txs;
            if (txnData.length > 0) {
                for (var i = 0; i < txnData.length; i++) {
                    var txnId = txnData[i].tx_id;
                    var channel_update = txnData[i].channel_update;
                    if (channel_update) {
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                    } else {
                        console.log(txnData[i].write_set.length);
                        if (txnData[i].write_set.length > 0) {
                            for (var m = 0; m < txnData[i].write_set.length; m++) {
                                var write_set = txnData[i].write_set[m];
                                var value = JSON.parse(write_set.value);
                                if(value['$class']){
                                    var txn_class = value['$class'];
                                    txn_class = txn_class.substring(txn_class.lastIndexOf(".") + 1);
                                    if (txn_class == "UpdateLandDetails" && value['landrecord']) {
                                        $scope.chaincode = "kaveri";
                                        $scope.peer = "org2-peer1";
                                        $scope.owner = true;
                                        $scope.property = true;
                                        var pid = value.landrecord;
                                        pid = pid.substring(pid.lastIndexOf("#") + 1);
                                        var landDetails = {
                                            pid: pid,
                                            txnId: txnId,
                                            msg: "Land record details updated with "
                                        }
                                        $scope.currentLandDetails = landDetails;

                                        var aadharNo = value.newOwner;
                                        aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                                        var ownerDetails = {
                                            aadharNo: aadharNo,
                                            txnId: txnId,
                                            msg: "Owner updated to this land with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    } else if (txn_class == "AddOwner" && value['owner']) {
                                        $scope.chaincode = "kaveri";
                                        $scope.peer = "org2-peer1";
                                        $scope.owner = true;
                                        var ownerDetails = {
                                            aadharNo: value.owner.aadharNo,
                                            txnId: txnId,
                                            msg: "Owner added with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    } else if (txn_class == "AddLandRecord" && value['landrecord']) {
                                        $scope.chaincode = "mojani";
                                        $scope.peer = "org1-peer1";
                                        $scope.property = true;
                                        var landDetails = {
                                            pid: value.landrecord.pid,
                                            txnId: txnId,
                                            msg: "Land record inserted with "
                                        }
                                        $scope.currentLandDetails = landDetails;
                                    } else if (txn_class == "AddAssignee" && value['owner']) {
                                        $scope.chaincode = "mojani";
                                        $scope.peer = "org1-peer1";
                                        $scope.owner = true;
                                        var ownerDetails = {
                                            aadharNo: value.owner.aadharNo,
                                            txnId: txnId,
                                            msg: "Owner assigned to this land with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    }
                                }
                            }

                        } else {
                            $scope.network = true;
                            var network = {
                                msg: "Network/Channel Update"
                            }
                            $scope.network = network;
                        }
                    }
                }if(!$scope.owner && !$scope.property){
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                  }
            } else {
                $scope.network = true;
                var network = {
                    msg: "Network/Channel Update"
                }
                $scope.network = network;
            }
        });
    }

    // On Click Of Back Arrow Will Show Previous Block Data
    $scope.Back = function() {
        $scope.owner = false;
        $scope.property = false;
        $scope.network = false;
        $scope.back = false;
        $scope.forward = false;
        $('#loading').show();
        $scope.current_block_no = ($scope.current_block_no - 1);
        if ($scope.current_block_no >= 0) {
            var blockNo = {
                blockNo: $scope.current_block_no - 1
            }
            $http({
                method: 'POST',
                url: '/blockData',
                data: blockNo
            }).then(function successCallback(response) {
                $('#loading').hide();
                if ($scope.current_block_no <= 1) {
                    $scope.back = true;
                }
                var msg = {
                    aadharNo: "aadhar number",
                    transactionId: "Txn Id : ",
                    pid: "pid",
                    colon: " : ",
                    currentBlock: "BLOCK # ",
                    blockNo: $scope.current_block_no
                }
                $scope.msg = msg;
                console.log(response);
                var txnData = response.data.current_block_data.parsed.txs;
                if (txnData.length > 0) {
                    for (var i = 0; i < txnData.length; i++) {
                        var txnId = txnData[i].tx_id;
                        var channel_update = txnData[i].channel_update;
                        if (channel_update) {
                            $scope.network = true;
                            var network = {
                                msg: "Network/Channel Update"
                            }
                            $scope.network = network;
                        } else {
                            console.log(txnData[i].write_set.length);
                            if (txnData[i].write_set.length > 0) {
                                for (var m = 0; m < txnData[i].write_set.length; m++) {
                                    var write_set = txnData[i].write_set[m];
                                    var value = JSON.parse(write_set.value);
                                    if(value['$class']){
                                        var txn_class = value['$class'];
                                        txn_class = txn_class.substring(txn_class.lastIndexOf(".") + 1);
                                        if (txn_class == "UpdateLandDetails" && value['landrecord']) {
                                            $scope.owner = true;
                                            $scope.property = true;
                                            var pid = value.landrecord;
                                            pid = pid.substring(pid.lastIndexOf("#") + 1);
                                            var landDetails = {
                                                pid: pid,
                                                txnId: txnId,
                                                msg: "Land record details updated with "
                                            }
                                            $scope.currentLandDetails = landDetails;

                                            var aadharNo = value.newOwner;
                                            aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                                            var ownerDetails = {
                                                aadharNo: aadharNo,
                                                txnId: txnId,
                                                msg: "Owner updated to this land with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        } else if (txn_class == "AddOwner" && value['owner']) {
                                            $scope.peer = "org2-peer1";
                                            $scope.owner = true;
                                            var ownerDetails = {
                                                aadharNo: value.owner.aadharNo,
                                                txnId: txnId,
                                                msg: "Owner added with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        } else if (txn_class == "AddLandRecord" && value['landrecord']) {
                                            $scope.property = true;
                                            var landDetails = {
                                                pid: value.landrecord.pid,
                                                txnId: txnId,
                                                msg: "Land record inserted with "
                                            }
                                            $scope.currentLandDetails = landDetails;
                                        } else if (txn_class == "AddAssignee" && value['owner']) {
                                            $scope.owner = true;
                                            var ownerDetails = {
                                                aadharNo: value.owner.aadharNo,
                                                txnId: txnId,
                                                msg: "Owner assigned to this land with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        }
                                    }
                                }

                            } else {
                                $scope.network = true;
                                var network = {
                                    msg: "Network/Channel Update"
                                }
                                $scope.network = network;
                            }
                        }
                    }if(!$scope.owner && !$scope.property){
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                  }
                } else {
                    $scope.network = true;
                    var network = {
                        msg: "Network/Channel Update"
                    }
                    $scope.network = network;
                }
            });
        }
    }

    // On Click Will Show Data Of Block Added After This Block(if any)
    $scope.Forward = function() {
        $scope.owner = false;
        $scope.property = false;
        $scope.network = false;
        $scope.back = false;
        $scope.forward = false;
        $('#loading').show();
        $scope.current_block_no = ($scope.current_block_no + 1);
        if ($scope.current_block_no <= $scope.total_blocks) {
            var blockNo = {
                blockNo: $scope.current_block_no - 1
            }
            $http({
                method: 'POST',
                url: '/blockData',
                data: blockNo
            }).then(function successCallback(response) {
                $('#loading').hide();
                if ($scope.current_block_no >= $scope.total_blocks) {
                    $scope.forward = true;
                }
                var msg = {
                    aadharNo: "aadhar number",
                    transactionId: "Txn Id : ",
                    pid: "pid",
                    colon: " : ",
                    currentBlock: "BLOCK # ",
                    blockNo: $scope.current_block_no
                }
                $scope.msg = msg;
                console.log(response);
                var txnData = response.data.current_block_data.parsed.txs;
                if (txnData.length > 0) {
                    for (var i = 0; i < txnData.length; i++) {
                        var txnId = txnData[i].tx_id;
                        var channel_update = txnData[i].channel_update;
                        if (channel_update) {
                            $scope.network = true;
                            var network = {
                                msg: "Network/Channel Update"
                            }
                            $scope.network = network;
                        } else {
                            console.log(txnData[i].write_set.length);
                            if (txnData[i].write_set.length > 0) {
                                for (var m = 0; m < txnData[i].write_set.length; m++) {
                                    var write_set = txnData[i].write_set[m];
                                    var value = JSON.parse(write_set.value);
                                    if(value['$class']){
                                        var txn_class = value['$class'];
                                        txn_class = txn_class.substring(txn_class.lastIndexOf(".") + 1);
                                        if (txn_class == "UpdateLandDetails" && value['landrecord']) {
                                            $scope.owner = true;
                                            $scope.property = true;
                                            var pid = value.landrecord;
                                            pid = pid.substring(pid.lastIndexOf("#") + 1);
                                            var landDetails = {
                                                pid: pid,
                                                txnId: txnId,
                                                msg: "Land record details updated with "
                                            }
                                            $scope.currentLandDetails = landDetails;

                                            var aadharNo = value.newOwner;
                                            aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                                            var ownerDetails = {
                                                aadharNo: aadharNo,
                                                txnId: txnId,
                                                msg: "Owner updated to this land with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        } else if (txn_class == "AddOwner" && value['owner']) {
                                            $scope.owner = true;
                                            var ownerDetails = {
                                                aadharNo: value.owner.aadharNo,
                                                txnId: txnId,
                                                msg: "Owner added with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        } else if (txn_class == "AddLandRecord" && value['landrecord']) {
                                            $scope.property = true;
                                            var landDetails = {
                                                pid: value.landrecord.pid,
                                                txnId: txnId,
                                                msg: "Land record inserted with "
                                            }
                                            $scope.currentLandDetails = landDetails;
                                        } else if (txn_class == "AddAssignee" && value['owner']) {
                                            $scope.owner = true;
                                            var ownerDetails = {
                                                aadharNo: value.owner.aadharNo,
                                                txnId: txnId,
                                                msg: "Owner assigned to this land with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        }
                                    }
                                }

                            } else {
                                $scope.network = true;
                                var network = {
                                    msg: "Network/Channel Update"
                                }
                                $scope.network = network;
                            }
                        }
                    }if(!$scope.owner && !$scope.property){
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                  }
                } else {
                    $scope.network = true;
                    var network = {
                        msg: "Network/Channel Update"
                    }
                    $scope.network = network;
                }
            });
        }
    }

    // On Click Of Find Button In Block View
    $scope.find = function() {
        $scope.findOwner = false;
        $scope.findProperty = false;
        $scope.findNetwork = false;
        $('#loading').show();
        var data = {
            selectedOpt: $scope.selectedOpt,
            inputValue: $scope.inputValue
        };
        if (data.selectedOpt != undefined && data.inputValue != undefined) {
            if (data.selectedOpt == "Block") {
                var blockNo = {
                    blockNo: data.inputValue - 1
                }
                if (blockNo.blockNo > 0 && blockNo.blockNo < $scope.total_blocks) {
                    $http({
                        method: 'POST',
                        url: '/blockData',
                        data: blockNo
                    }).then(function successCallback(response) {
                        $('#loading').hide();
                        $('#blockModal').modal('show');
                        console.log(response);
                        var txnData = response.data.current_block_data.parsed.txs;
                        if (txnData.length > 0) {
                            for (var i = 0; i < txnData.length; i++) {
                                var txnId = txnData[i].tx_id;
                                var channel_update = txnData[i].channel_update;
                                if (channel_update) {
                                    $scope.findNetwork = true;
                                    var network = {
                                        msg: "Network/Channel Update"
                                    }
                                    $scope.blockNetwork = network;
                                } else {
                                    console.log(txnData[i].write_set.length);
                                    if (txnData[i].write_set.length > 0) {
                                        for (var m = 0; m < txnData[i].write_set.length; m++) {
                                            var write_set = txnData[i].write_set[m];
                                            var value = JSON.parse(write_set.value);
                                            if(value['$class']){
                                                var txn_class = value['$class'];
                                                txn_class = txn_class.substring(txn_class.lastIndexOf(".") + 1);
                                                if (txn_class == "UpdateLandDetails" && value['landrecord']) {
                                                    $scope.findOwner = true;
                                                    $scope.findProperty = true;
                                                    var pid = value.landrecord;
                                                    pid = pid.substring(pid.lastIndexOf("#") + 1);
                                                    var landDetails = {
                                                        pid: pid,
                                                        txnId: txnId,
                                                        msg: "Land record details updated with "
                                                    }
                                                    $scope.blockLandDetails = landDetails;

                                                    var aadharNo = value.newOwner;
                                                    aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                                                    var ownerDetails = {
                                                        aadharNo: aadharNo,
                                                        txnId: txnId,
                                                        msg: "Owner updated to this land with "
                                                    }
                                                    $scope.blockOwnerDetails = ownerDetails;
                                                } else if (txn_class == "AddOwner" && value['owner']) {
                                                    $scope.findOwner = true;
                                                    var ownerDetails = {
                                                        aadharNo: value.owner.aadharNo,
                                                        txnId: txnId,
                                                        msg: "Owner added with "
                                                    }
                                                    $scope.blockOwnerDetails = ownerDetails;
                                                } else if (txn_class == "AddLandRecord" && value['landrecord']) {
                                                    $scope.findProperty = true;
                                                    var landDetails = {
                                                        pid: value.landrecord.pid,
                                                        txnId: txnId,
                                                        msg: "Land record inserted with "
                                                    }
                                                    $scope.blockLandDetails = landDetails;
                                                } else if (txn_class == "AddAssignee" && value['owner']) {
                                                    $scope.findOwner = true;
                                                    var ownerDetails = {
                                                        aadharNo: value.owner.aadharNo,
                                                        txnId: txnId,
                                                        msg: "Owner assigned to this land with "
                                                    }
                                                    $scope.blockOwnerDetails = ownerDetails;
                                                }
                                            }
                                        }

                                    } else {
                                        $scope.findNetwork = true;
                                        var network = {
                                            msg: "Network/Channel Update"
                                        }
                                        $scope.blockNetwork = network;
                                    }
                                }
                            }if(!$scope.findOwner && !$scope.findProperty){
                                $scope.findNetwork = true;
                                var network = {
                                    msg: "Network/Channel Update"
                                }
                                $scope.blockNetwork = network;
                             }
                        } else {
                            $scope.findNetwork = true;
                            var network = {
                                msg: "Network/Channel Update"
                            }
                            $scope.blockNetwork = network;
                        }
                    });
                } else {
                    alert("Block value can only be found between 0 to " + $scope.total_blocks);
                }
            } else {
                var txnNo = {
                    txnNo: data.inputValue
                }
                $http({
                    method: 'POST',
                    url: '/txnData',
                    data: txnNo
                }).then(function successCallback(response) {
                    console.log(response);
                    $('#loading').hide();
                    $('#txnModal').modal('show');
                    var txn_data = response.data;
                    var txn_class = txn_data.txn_class;
                    if (txn_class == "UpdateLandDetails") {
                        var txnId = txn_data.txnData[0].transactionId;
                        $scope.findOwner = true;
                        $scope.findProperty = true;
						var pid = txn_data.txnData[0].landrecord;
						pid = pid.substring(pid.lastIndexOf("#") + 1);
                        var landDetails = {
                            pid: pid,
                            txnId: txnId,
                            msg: "Land record details updated with "
                        }
                        $scope.txnLandDetails = landDetails;

                        var aadharNo = txn_data.txnData[0].newOwner;
						aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                        var ownerDetails = {
                            aadharNo: aadharNo,
                            txnId: txnId,
                            msg: "Owner updated to this land with "
                        }
                        $scope.txnOwnerDetails = ownerDetails;
                    } else if (txn_class == "AddOwner") {
                        var txnId = txn_data.txnData[0].transactionId;
                        var aadharNo = txn_data.txnData[0].owner.aadharNo;
                        $scope.findOwner = true;
                        var ownerDetails = {
                            aadharNo: aadharNo,
                            txnId: txnId,
                            msg: "Owner added with "
                        }
                        $scope.txnOwnerDetails = ownerDetails;
                    } else if (txn_class == "AddLandRecord") {
                        var txnId = txn_data.txnData[0].transactionId;
                        var pid = txn_data.txnData[0].landrecord.pid;
                        $scope.findProperty = true;
                        var landDetails = {
                            pid: pid,
                            txnId: txnId,
                            msg: "Land record inserted with "
                        }
                        $scope.txnLandDetails = landDetails;
                    } else if (txn_class == "AddAssignee") {
                        var txnId = txn_data.txnData[0].transactionId;
                        var aadharNo = txn_data.txnData[0].owner.aadharNo;
                        $scope.findOwner = true;
                        var ownerDetails = {
                            aadharNo: aadharNo,
                            txnId: txnId,
                            msg: "Owner assigned to this land with "
                        }
                        $scope.txnOwnerDetails = ownerDetails;
                    } else {
                        $scope.findNetwork = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.txnNetwork = network;
                    }
                });
            }
        } else {
            alert("Please check the radio button and add text in the input to continue..!!")
        }
    }

});
