var express = require('express');
var request = require('request');
var path = require('path');
var fs = require("fs");
var bodyParser = require('body-parser');
var port = process.env.PORT || process.env.VCAP_APP_PORT || '8084';
var nano = require('nano')('http://localhost:' + port);
var app = express();
var multer = require('multer');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

var upload = multer({
    dest: __dirname + '/upload'
});
var type = upload.single('file');

app.use('/', express.static(__dirname + '/'));
app.use('/', express.static(__dirname + '/Images'));

var cloudantUserName = "97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix";
var cloudantPassword = "ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b";
var dbCredentials_url = "https://" + cloudantUserName + ":" + cloudantPassword + "@" + cloudantUserName + ".cloudant.com"; // Set this to your own account

// Initialize the library with my account.
var cloudant = require('cloudant')(dbCredentials_url);

var dbForLogin = cloudant.db.use("logindetails");
var dbForStudentUniversityData = cloudant.db.use("studentuniversitydata");
var dbForAdminUniversityRequestTable = cloudant.db.use("adminuniversityrequesttable");
var dbForAdminRequestTable = cloudant.db.use("applicantdata");


// viewed at http://localhost:8080
app.get('/', function(req, res) {
    console.log("Open LoginPage.html page");
    res.sendFile(path.join(__dirname + '/LoginPage.html'));
});

app.post('/loginData', function(req, res) {
    console.log("Got a POST request for LoginPage.html page");
    var response = "";
    var userName = req.body.username;
    var password = req.body.password;
    dbForLogin.get(userName, function(err, body) {
        if (!err) {
            var dbPassword = body.agentPassword;
            if (dbPassword === password) {
                response = {
                    status: 200,
                    message: 'Success'
                }
            } else {
                response = {
                    status: 300,
                    message: 'Username and Password does not match'
                }
            }
        } else {
            console.log(err);
            response = {
                status: 400,
                message: 'Username does not exists'
            }
        }
        res.send(JSON.stringify(response));
    });
});

app.post('/requestTableData', function(req, res) {
    console.log("Got an on-load POST request for RequestTable.html page");
    var response = "";
    dbForAdminUniversityRequestTable.list({
        include_docs: true
    }, function(err, body) {
        if (!err) {
            console.log('Data is sent to the page.')
            response = {
                status: 200,
                message: body
            }
        } else {
            response = {
                status: 400,
                message: 'No data found.'
            }
        }
        res.send(JSON.stringify(response));
    })
});

app.post('/applicantData', function(req, res) {
    console.log("Got a POST request for RequestTable.html page");
    var response = "";
    var userData = "";
    dbForStudentUniversityData.list({
        include_docs: true
    }, function(err, body) {
        if (!err) {
            console.log(body.rows[0].doc);
            for (var i = 0; i < body.rows.length; i++) {
                if (body.rows[i].doc.digitalId === req.body.id) {
                    userData = body.rows[i].doc;
                }
            }
            response = {
                status: 200,
                message: userData
            }
        } else {
            response = {
                status: 400,
                message: 'No data found for this applicant.'
            }
        }
        res.send(JSON.stringify(response));
    })
});

app.post('/applicantDataStatus', function(req, res) {
    console.log("Got a POST request for StudentDetails.html page");
    var newstatus = req.body.status;
    var id = "";
    var revId = "";
    var requestDate = "";
    var appliedFor = "";
    var applicantName = "";
    var digitalId = "";
    dbForAdminUniversityRequestTable.list({
        include_docs: true
    }, function(err, body) {
        if (err) {
            console.log('Issue in fetching data.');
        }
        for (var i = 0; i < body.rows.length; i++) {
            if (body.rows[i].doc.digitalId === req.body.id) {
                id = body.rows[i].doc._id;
                revId = body.rows[i].doc._rev;
                requestDate = body.rows[i].doc.requestDate;
                applicantName = body.rows[i].doc.applicantName;
                appliedFor = body.rows[i].doc.appliedFor;
                digitalId = body.rows[i].doc.digitalId;
            }
        }
        console.log('Status to be updated for reqId : ' + id);
        dbForAdminUniversityRequestTable.insert({
            _id: id,
            _rev: revId,
            status: newstatus,
            digitalId: digitalId,
            requestDate: requestDate,
            applicantName: applicantName,
            appliedFor: appliedFor,
            digitalIdVerified: req.body.digitalIdVerified
        }, function(err, body) {
            if (!err) {
                var response = {
                    status: 200,
                    message: 'Status updated.'
                }
                dbForAdminUniversityRequestTable.list({
                    include_docs: true
                }, function(err, body) {
                    if (!err) {
                    }
                })
                console.log('Status updated.');
            } else {
                response = {
                    status: 400,
                    message: 'Issue in updating the status.'
                }
                console.log('Status updation issue.');
            }
            res.send(JSON.stringify(response));
        })
    })
});

app.post('/verifyDigitalIdStatus', function(req, res) {
    console.log("Got a POST request for StudentDetails.html page");
    var response = "";
    var response = "";
    var message = "Failure";
    var requestDate = "";
    var token = "";
    var name = "";
    var id = "";
    dbForAdminRequestTable.list({
        include_docs: true
    }, function(err, body) {
        if (err) {
            console.log('Issue in fetching data.');
        }
        for (var i = 0; i < body.rows.length; i++) {
            if (body.rows[i].doc._id === req.body.id) {
                token = body.rows[i].doc.token;
                name = body.rows[i].doc.name;
                id = req.body.id;
            }
        }
        console.log("Token  :-" + token);
        //Chain code call to verify with token
        // Set the headers
        var headers = {
            'authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }
        var options = {
            url: 'http://52.91.179.226:4000/channels/mychannel/chaincodes/studentcc?peer=peer1&fcn=get&args=%5B%22' + id + '%22%5D',
            method: 'GET',
            headers: headers
        }

        console.log("Get command", options);
        request(options, function(error, response, body) {
            if (!error && response.statusCode == 200) {
                // Print out the response body
                var ch = "'";
                var nameCC = body;

                console.log('Value of id', id);
                nameCC = nameCC.replace('now has', '');
                nameCC = nameCC.replace('after the move', '');
                nameCC = nameCC.replace(id, '');
                var nametoget = JSON.parse(nameCC);

                console.log("Name from body" + nametoget);
                console.log("Name from body name" + nameCC);
                console.log("Name from DB" + name);
                if (nametoget.Name === name)
                    message = "Success";

                console.log("Response from GET  ", body);

            }
            response = {
                status: 200,
                message: message
            }
            res.send(JSON.stringify(response));
        });

    });
});

app.post('/searchApplicants', function(req, res) {
    console.log("Got a POST request for StudentDetails.html page");
    var response = "";
    var studentList = [];
    var data = "";
    dbForStudentUniversityData.list({
        include_docs: true
    }, function(err, body) {
        if (err) {
            console.log('Issue in fetching data.');
        }

        for (var i = 0; i < body.rows.length; i++) {
            if (body.rows[i].doc.selectedCourse === req.body.course && body.rows[i].doc.applyingFor == req.body.degree) {
                data = body.rows[i].doc;
                studentList.push(data);
            }
        }
        response = {
            status: 200,
            message: studentList
        }
        res.send(JSON.stringify(response));
    });
});

app.post('/addGradDate', function(req, res) {
    console.log("Got a POST request for RequestTable.html page");
    var studentList = req.body.data;
    var response = "";
    var data = "";
    var token = "";

    dbForStudentUniversityData.list({
        include_docs: true
    }, function(err, body) {
        if (err) {
            console.log('Issue in fetching data.');
        }

        for (var j = 0; j < studentList.length; j++) {
            var revId = "";
            var applicantName = "";
            var ssn = "";
            var dateOfBirth = "";
            var gender = "";
            var emailId = "";
            var code = "";
            var number = "";
            var address = "";
            var digitalId = "";
            var degree = "";
            var course = "";
            var attachmentData = "";
            for (var i = 0; i < body.rows.length; i++) {
                if (body.rows[i].doc._id === studentList[j]) {
                    revId = body.rows[i].doc._rev;
                    applicantName = body.rows[i].doc.name;
                    ssn = body.rows[i].doc.ssn;
                    dateOfBirth = body.rows[i].doc.dob;
                    gender = body.rows[i].doc.gender;
                    emailId = body.rows[i].doc.email;
                    code = body.rows[i].doc.countryCode;
                    number = body.rows[i].doc.phoneNumber;
                    address = body.rows[i].doc.address;
                    digitalId = body.rows[i].doc.digitalId;
                    degree = body.rows[i].doc.applyingFor;
                    course = body.rows[i].doc.selectedCourse;
                    attachmentData = body.rows[i].doc._attachments;
                }
            }


            /*dbForAdminRequestTable.list({ include_docs: true },function(err, body) {
              if (err) {
                    console.log('Issue in fetching data.');
              }
                    for(var i=0; i<body.rows.length; i++){
                            if(body.rows[i].doc.digitalId === digitalId){
                                    token = body.rows[i].doc.token;
                            }
                    }

                    //Chain code call to publish


            });*/

            //Call to chaincode

            // Set the headers
            var headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }

            console.log("Applicant Name" + applicantName);
            // Configure the request
            var options = {
                url: 'http://52.91.179.226:4000/users',
                method: 'POST',
                headers: headers,
                form: {
                    'username': applicantName,
                    'orgName': 'illinois'
                }
            }
            console.log("Options values" + options);

            request(options, function(error, response, body) {
                if (!error && response.statusCode == 200) {
                    // Print out the response body
                    var temp = JSON.parse(body);
                    token = temp.token;
                    dbForStudentUniversityData.insert({
                        _id: studentList[j],
                        _rev: revId,
                        name: applicantName,
                        ssn: ssn,
                        dob: dateOfBirth,
                        gender: gender,
                        email: emailId,
                        countryCode: code,
                        phoneNumber: number,
                        address: address,
                        digitalId: digitalId,
                        applyingFor: degree,
                        selectedCourse: course,
                        _attachments: attachmentData,
                        graduationDate: req.body.graduationDate,
                        token: token
                    }, function(err, body) {
                        if (!err) {
                            console.log('Graduation Date Updated Successfully.');
                        } else {
                            console.log('Graduation Date Not Updated Successfully.');
                        }
                    })

                    console.log("ccccccccccccccccc", temp.token);
                    var headers = {
                        'authorization': 'Bearer ' + temp.token,
                        'Content-Type': 'application/json'

                    }
                    var tempArgs = [];
                    tempArgs.push({
                        'UName': 'First University'
                    });
                    console.log("Testing the output", JSON.stringify(tempArgs));
                    var strfy = JSON.stringify(tempArgs);

                    // Configure the request
                    var options = {
                        url: 'http://52.91.179.226:4000/channels/mychannel/chaincodes/studentcc',
                        method: 'POST',

                        headers: headers,

                        body: {

                            'fcn': 'add',

                            'args': [digitalId, JSON.stringify({
                                'UName': "Illinious University"
                            })]

                        },
                        json: true

                        //form: {'fcn': 'create', 'args':strfy }
                    }

                    console.log("Req for options", options);
                    // Start the request
                    request(options, function(error, response, body) {

                        if (!error && response.statusCode == 200) {

                            // Print out the response body

                            //Code for illunoise code testing

                            //var input = '%5B%22a%22%5D';

                            var input = [];
                            input.push('a');


                            var options = {
                                url: 'http://52.91.179.226:4000/channels/mychannel/chaincodes/studentcc?peer=peer1&fcn=get&args=%5B%22' + digitalId + '%22%5D',

                                method: 'GET',

                                headers: headers

                            }

                            console.log("Get command", options);

                            request(options, function(error, response, body) {

                                if (!error && response.statusCode == 200) {

                                    // Print out the response body

                                    console.log("Response from GET  ", body)


                                }

                            });
                        }
                    });
                }
            });
        }
    });
    response = {
        status: 200,
        message: "Success"
    }
    res.send(JSON.stringify(response));
});
app.listen(port);
