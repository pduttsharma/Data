var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var requestify = require('requestify');
var port = process.env.PORT || process.env.VCAP_APP_PORT || '8080';
var username = 'org1';
var password = 'sHvN1FwNUf2LrQnALU8CBN4_HS2WCZ1OAh3MOIR4IJc5wg8jWP9V-gACoiNFjQJB';
var auth = "Basic " + new Buffer(username + ":" + password).toString("base64");
var app = express();
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use('/', express.static(__dirname + '/'));

// viewed at http://localhost:8080
app.get('/', function(req, res) {
    console.log("Open blockData.html page");
    res.sendFile(path.join(__dirname + '/blockData.html'));
});

app.post('/blockChainData', function(req, res) {
    requestify.request('https://blockchain-starter.ng.bluemix.net/api/v1/networks/n86b2e7d346474627a9fe5f2cf562cc28/channels/defaultchannel', {
            method: 'POST',
            body: {
                "peer_names": [
                    "org1-peer1"
                ]
            },
            headers: {
                "Authorization": auth
            },
            dataType: 'json'
        })
        .then(function(response) {
            // get the response body
            var blockData = response.getBody();
            totalBlocks = (blockData.peer['org1-peer1']).height.low - 1;
            requestify.request('https://blockchain-starter.ng.bluemix.net/api/v1/networks/n86b2e7d346474627a9fe5f2cf562cc28/channels/defaultchannel/blocks/' + totalBlocks, {
                    method: 'POST',
                    body: {
                        "peer_names": [
                            "org1-peer1"
                        ]
                    },
                    headers: {
                        "Authorization": auth
                    },
                    dataType: 'json'
                })
                .then(function(response) {
                    // get the response body
                    var currentBlockData = response.getBody();
                    var data = {
                        channelData: blockData,
                        current_block_data: currentBlockData,
                        responseCode: 200
                    }
                    res.send(JSON.stringify(data));
                });
        });
});

app.post('/blockData', function(req, res) {
    var blockNo = req.body.blockNo;
    requestify.request('https://blockchain-starter.ng.bluemix.net/api/v1/networks/n86b2e7d346474627a9fe5f2cf562cc28/channels/defaultchannel/blocks/' + blockNo, {
            method: 'POST',
            body: {
                "peer_names": [
                    "org1-peer1"
                ]
            },
            headers: {
                "Authorization": auth
            },
            dataType: 'json'
        })
        .then(function(response) {
            // get the response body
            var currentBlockData = response.getBody();
            var data = {
                current_block_data: currentBlockData,
                responseCode: 200
            }
            res.send(JSON.stringify(data));
        });
});
app.listen(port);