/* Angular Module Definition */
var myApp = angular.module('myModule', ['ngTable']);
/* File Upload Directive */
myApp.directive('fileModel', [
  '$parse'
  , function ($parse) {
        return {
            restrict: 'A'
            , link: function (scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;
                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
  }
]);
/* File Upload Service */
myApp.service('fileUpload', [
  '$http'
  , function ($http) {
        this.uploadFileAndFieldsToUrl = function (idProofFile, ppFile, data, uploadUrl) {
            var fd = new FormData();
            fd.append('file', idProofFile);
            fd.append('data', JSON.stringify(data));
            $http({
                method: 'POST'
                , url: uploadUrl
                , data: fd
                , transformRequest: angular.identity
                , headers: {
                    'Content-Type': undefined
                }
            }).then(function successCallback(response) {
                if (response.data.success == true && uploadUrl === '/addDigitalDataToDB') {
                    var fd = new FormData();
                    fd.append('file', ppFile);
                    fd.append('data', JSON.stringify(data));
                    $http({
                        method: 'POST'
                        , url: '/addApplicantPicToDocumentDB'
                        , data: fd
                        , transformRequest: angular.identity
                        , headers: {
                            'Content-Type': undefined
                        }
                    }).then(function successCallback(response) {
                        if (response.data.success == true) {
                            window.location.href = '/digital_id_success.html';
                        }
                        else {
                            alert(response);
                        }
                    });
                }
                else if (response.data.success == true && (uploadUrl === '/addCertsRelatedToDigitalIdToDB' || uploadUrl === '/addSemesterWiseCerts')) {
                    window.location.href = '/university_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
  }
]);
/* Main Portal Controller */
myApp.controller('mainPortal', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.studentPortal = function () {
            window.open('/student_portal.html', '_blank');
        };
        $scope.awardingBodyPortal = function () {
            window.open('/awarding_body_admin_login.html', '_blank');
        };
        $scope.coordinatorPortal = function () {
            window.open('/co-ordinator_portal.html', '_blank');
        };
        $scope.universityPortal = function () {
            window.open('/university_admin_login.html', '_blank');
        };
        $scope.portFolioView = function () {
            window.open('/port_folio_view.html', '_blank');
        };
        $scope.studentExplorer = function () {
            window.open('/explorer.html', '_blank');
        };
  }
]);
/* Student Portal Controller */
myApp.controller('studentPortal', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.applyFinalDiplomaExam = function () {
            window.location.href = '/apply_final_exam.html';
        };
        $scope.applyUniversity = function () {
            window.location.href = '/apply_university.html';
        };
        $scope.portFolioView = function () {
            window.open('/port_folio_view.html', '_blank');
        };
  }
]);
/* Co-ordinator Portal Controller */
myApp.controller('coordinatorPortal', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.applyDigitalId = function () {
            window.location.href = '/apply_digital_id.html';
        };
        $scope.coordinatorAdmin = function () {
            window.location.href = '/co-ordinator_admin_login.html';
        };
  }
]);
/* Apply For Digital Id Controller */
myApp.controller('applyDigitalId', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.isDisabled = false;
        var uniqueId = Date.now();
        $scope.Back = function () {
            $window.location.href = '/co-ordinator_portal.html';
        };
        $scope.Logout = function () {
            window.close();
        };
        var idProof = {
            _id: uniqueId + '-IdProof'
            , docName: ''
            , docType: 'Identification Proof'
            , digitalId: uniqueId + ''
        };
        var pp = {
            _id: uniqueId + '-PP'
            , docName: ''
            , docType: 'Applicant Photo'
            , digitalId: uniqueId + ''
        };
        var diplomaDetails = {
            group1Subject: ''
            , group1Score: ''
            , group2Subject: ''
            , group2Score: ''
            , group3Subject: ''
            , group3Score: ''
            , group4Subject: ''
            , group4Score: ''
            , group5Subject: ''
            , group5Score: ''
            , group6Subject: ''
            , group6Score: ''
        };
        var finalDiplomaDetails = {
            diplomaRegistartionId: ''
            , diplomaTotalScore: ''
            , diplomaCertificate: ''
            , diplomaStartDate: ''
            , diplomaEndDate: ''
            , diplomaSubjectsAndScores: diplomaDetails
        };
        var digitalIdData = {
            digitalId: uniqueId + ''
            , fullName: ''
            , emailId: ''
            , countrycode: ''
            , nationalId: ''
            , mobileNumber: ''
            , gender: ''
            , address: ''
            , createTimestamp: uniqueId
            , dateOfBirth: ''
            , idProof: idProof
            , applicantImg: pp
            , universityDetails: []
            , internalAssessmentDetails: []
            , diplomaDetails: finalDiplomaDetails
            , txnMsg: ''
        };
        var applicantData = {
            _id: uniqueId + ''
            , digitalIdInfo: digitalIdData
            , internalAssessmentRegistrationId: ''
            , digitalIdStatus: 'Pending'
            , diplomaScoreUpdated: 'Pending'
            , finalDiplomaRegistrationByCoordinator: 'Pending'
            , finalDiplomaRegistrationByApplicant: 'Pending'
            , nationalId: ''
            , message: ''
        };
        $scope.applicantData = applicantData;
        $scope.$watch('idProof', function (newFileObj) {
            if (newFileObj) $scope.idProofFilename = newFileObj.name;
        });
        $scope.$watch('pp', function (newFileObj) {
            if (newFileObj) $scope.profilePicFileName = newFileObj.name;
        });
        $scope.group1 = [
      'English Language(SL)'
      , 'English Language(HL)'
      , 'Spanish Language(SL)'
      , 'Spanish Language(HL)'
    ];
        $scope.group2 = ['Hindi(SL)', 'Hindi(HL)', 'French(SL)', 'French(HL)'];
        $scope.group3 = [
      'Economics(SL)'
      , 'Economics(HL)'
      , 'History(SL)'
      , 'History(HL)'
      , 'Pyschology(SL)'
      , 'Pyschology(SL)'
      , 'Business and Management(SL)'
      , 'Business and Management(HL)'
    ];
        $scope.group4 = [
      'Biology(SL)'
      , 'Biology(HL)'
      , 'Chemistry(SL)'
      , 'Chemistry(HL)'
      , 'Physics(SL)'
      , 'Physics(HL)'
      , 'Computer Science(SL)'
      , 'Computer Science(HL)'
    ];
        $scope.group5 = [
      'Mathematics(SL)'
      , 'Mathematics(HL)'
      , 'Mathematical Studies(SL)'
    ];
        $scope.group6 = ['Theatre', 'Film', 'Music', 'Visual Arts'];
        $scope.genderTypes = ['Male', 'Female'];
        $scope.submitDigitalIdData = function () {
            $scope.isDisabled = true;
            var idProofFile = $scope.idProof;
            var ppFile = $scope.pp;
            $scope.applicantData.digitalIdInfo.idProof.docName = idProofFile.name;
            $scope.applicantData.digitalIdInfo.applicantImg.docName = ppFile.name;
            $scope.applicantData.nationalId = $scope.applicantData.digitalIdInfo.nationalId;
            $scope.applicantData.message = 'Record inserted successfully in Cloudant DB.';
            var uploadUrl = '/addDigitalDataToDB';
            fileUpload.uploadFileAndFieldsToUrl(idProofFile, ppFile, $scope.applicantData, uploadUrl);
        };
  }
]);
/* Awarding Body Admin Login Controller */
myApp.controller('awardingBodyAdminLogin', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.verifyLogin = function () {
            var data = {
                username: $scope.username
                , password: $scope.password
            };
            $http({
                method: 'POST'
                , url: '/verifyLogin'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    window.location.href = '/awarding_body_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
  }
]);
/* University Admin Login Controller */
myApp.controller('universityAdminLogin', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.verifyLogin = function () {
            var data = {
                username: $scope.username
                , password: $scope.password
            };
            $http({
                method: 'POST'
                , url: '/verifyLogin'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    window.location.href = '/university_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
  }
]);

/* University Admin Controller */
myApp.controller('universityAdmin', ['$scope', '$http', '$window', 'NgTableParams', function ($scope, $http, $window, NgTableParams) {

    $scope.getUniversityApplicantRequests = function () {
        $http({
            method: 'GET',
            url: '/getUniversityApplicantRequests'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                var list = [];
                for (var i = 0; i < response.data.result.length; i++) {
                    var map = new Object();
                    var registrationId = response.data.result[i].registrationId;
                    map['name'] = response.data.result[i].digitalIdInfo.fullName;
                    for (var j = 0; j < response.data.result[i].digitalIdInfo.universityDetails.length; j++) {
                        if (registrationId == response.data.result[i].digitalIdInfo.universityDetails[j].registrationId) {
                            map['universityName'] = response.data.result[i].digitalIdInfo.universityDetails[j].universityName;
                            map['digitalId'] = response.data.result[i].digitalIdInfo.universityDetails[j].digitalId;
                            map['courseAppliedFor'] = response.data.result[i].digitalIdInfo.universityDetails[j].courseAppliedFor;
                            map['appliedDegreeType'] = response.data.result[i].digitalIdInfo.universityDetails[j].appliedDegreeType;
                            list.push(map);
                        }
                    }
                }
                $scope.tableData = list;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert('No records found in database');
            }
        });
    }

    $scope.getIdToAddSemesterCert = function () {
        $http({
            method: 'GET',
            url: '/getUniversitySemApplicantRequests'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                var list = [];
                for (var i = 0; i < response.data.result.length; i++) {
                    var map = new Object();
                    var registrationId = response.data.result[i].registrationId;
                    map['name'] = response.data.result[i].digitalIdInfo.fullName;
                    for (var j = 0; j < response.data.result[i].digitalIdInfo.universityDetails.length; j++) {
                        if (registrationId == response.data.result[i].digitalIdInfo.universityDetails[j].registrationId) {
                            map['universityName'] = response.data.result[i].digitalIdInfo.universityDetails[j].universityName;
                            map['digitalId'] = response.data.result[i].digitalIdInfo.universityDetails[j].digitalId;
                            map['courseAppliedFor'] = response.data.result[i].digitalIdInfo.universityDetails[j].courseAppliedFor;
                            map['appliedDegreeType'] = response.data.result[i].digitalIdInfo.universityDetails[j].appliedDegreeType;
                            map['length'] = response.data.result[i].digitalIdInfo.universityDetails[j].semesterDetails.length;
                            list.push(map);
                        }
                    }
                }
                $scope.tableData = list;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert('No records found in database');
            }
        });
    }

    $scope.getUniversityPublishDetails = function () {
        $http({
            method: 'GET',
            url: '/getUniversityPublishDetails'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                var list = [];
                for (var i = 0; i < response.data.result.length; i++) {
                    var map = new Object();
                    var registrationId = response.data.result[i].registrationId;
                    map['name'] = response.data.result[i].digitalIdInfo.fullName;
                    for (var j = 0; j < response.data.result[i].digitalIdInfo.universityDetails.length; j++) {
                        if (registrationId == response.data.result[i].digitalIdInfo.universityDetails[j].registrationId && !response.data.result[i].digitalIdInfo.universityDetails[j].degreeCompleteStatus) {
                            map['universityName'] = response.data.result[i].digitalIdInfo.universityDetails[j].universityName;
                            map['digitalId'] = response.data.result[i].digitalIdInfo.universityDetails[j].digitalId;
                            map['courseAppliedFor'] = response.data.result[i].digitalIdInfo.universityDetails[j].courseAppliedFor;
                            map['appliedDegreeType'] = response.data.result[i].digitalIdInfo.universityDetails[j].appliedDegreeType;
                            list.push(map);
                        }
                    }
                }
                $scope.tableData = list;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert('No records found in database');
            }
        });
    }
    $scope.publishDataForDigitalId = function (digitalId) {
        $window.sessionStorage.setItem("_id", digitalId);
        $window.location.href = '/university_add_certs.html';
    }

    $scope.selectedDigitalId = function (digitalId) {
        $window.sessionStorage.setItem("_id", digitalId);
        $window.location.href = '/university_read_only.html';
    }

    $scope.selectedSemDigitalId = function (digitalId) {
        $window.sessionStorage.setItem("_id", digitalId);
        $window.location.href = '/university_add_semester_certs.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Assessment Admin Login Controller */
myApp.controller('coordinatorAdminLogin', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.verifyLogin = function () {
            var data = {
                username: $scope.username
                , password: $scope.password
            };
            $http({
                method: 'POST'
                , url: '/verifyLogin'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    window.location.href = '/co-ordinator_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
  }
]);
/* Awarding Body Admin Page Controller */
myApp.controller('awardingBodyAdmin', [
  '$scope'
  , '$http'
  , '$window'
  , 'NgTableParams'
  , function ($scope, $http, $window, NgTableParams) {
        $scope.getDigitalIdRequests = function () {
            $http({
                method: 'GET'
                , url: '/getDigitalIdRequests'
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.tableData = response.data.result;
                    $scope.tableParams = new NgTableParams({
                        count: 4
                    }, {
                        counts: []
                        , dataset: $scope.tableData
                    });
                }
                else {
                    alert('No records found in database');
                }
            });
        };
        $scope.getInternalAssessmentScoreEvaluationByAwardingBody = function () {
            $http({
                method: 'GET'
                , url: '/getInternalAssessmentScoreEvaluationByAwardingBody'
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    var list = [];
                    for (var i = 0; i < response.data.result.length; i++) {
                        var map = new Object();
                        var internalAssessmentRegistrationId = response.data.result[i].internalAssessmentRegistrationId;
                        map['name'] = response.data.result[i].digitalIdInfo.fullName;
                        map['emailId'] = response.data.result[i].digitalIdInfo.emailId;
                        for (var j = 0; j < response.data.result[i].digitalIdInfo.internalAssessmentDetails.length; j++) {
                            if (internalAssessmentRegistrationId == response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].internalAssessmentRegistrationId) {
                                map['internalAssessmentRegistrationId'] = response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].internalAssessmentRegistrationId;
                                map['digitalId'] = response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].digitalId;
                                map['selectedSkill'] = response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].selectedSkill;
                                map['assessmentCode'] = response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].assessmentCode;
                                list.push(map);
                            }
                        }
                    }
                    $scope.tableData = list;
                    $scope.tableParams = new NgTableParams({
                        count: 4
                    }, {
                        counts: []
                        , dataset: $scope.tableData
                    });
                }
                else {
                    alert('No records found in database');
                }
            });
        };
        $scope.getDiplomaRegistrationIdRequestsForAwardingBody = function () {
            $http({
                method: 'GET'
                , url: '/getDiplomaRegistrationIdRequestsForAwardingBody'
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.tableData = response.data.result;
                    $scope.tableParams = new NgTableParams({
                        count: 4
                    }, {
                        counts: []
                        , dataset: $scope.tableData
                    });
                }
                else {
                    alert('No records found in database');
                }
            });
        };
        $scope.getDigitalIdToUpdateDiplomaScoreAndTranscript = function () {
            $http({
                method: 'GET'
                , url: '/getDigitalIdToUpdateDiplomaScoreAndTranscript'
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.tableData = response.data.result;
                    $scope.tableParams = new NgTableParams({
                        count: 4
                    }, {
                        counts: []
                        , dataset: $scope.tableData
                    });
                }
                else {
                    alert('No records found in database');
                }
            });
        };
        $scope.selectedDigitalId = function (digitalId) {
            $window.sessionStorage.setItem('_id', digitalId);
            $window.location.href = '/digital_id_read_only.html';
        };
        $scope.selectedDigitalIdForInternalAssessment = function (digitalId) {
            $window.sessionStorage.setItem('_id', digitalId);
            $window.location.href = '/internal_assessment_score_review.html';
        };
        $scope.selectedDigitalIdForDiplomaId = function (digitalId) {
            $window.sessionStorage.setItem('_id', digitalId);
            $window.location.href = '/review_final_exam_form_awarding_body.html';
        };
        $scope.selectedDigitalIdForScoreUpdation = function (digitalId) {
            $window.sessionStorage.setItem('_id', digitalId);
            $window.location.href = '/add_transcript_details.html';
        };
        $scope.Logout = function () {
            window.close();
        };
  }
]);
/* Co-ordinator Admin Page Controller */
myApp.controller('coordinatorAdmin', [
  '$scope'
  , '$http'
  , '$window'
  , 'NgTableParams'
  , function ($scope, $http, $window, NgTableParams) {
        $scope.getDigitalIdForSkillAssignmentForAssessment = function () {
            $http({
                method: 'GET'
                , url: '/getDigitalIdForSkillAssignmentForAssessment'
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.tableData = response.data.result;
                    $scope.tableParams = new NgTableParams({
                        count: 4
                    }, {
                        counts: []
                        , dataset: $scope.tableData
                    });
                }
                else {
                    alert('No records found in database');
                }
            });
        };
        $scope.getDigitalIdForInternalAssessmentScore = function () {
            $http({
                method: 'GET'
                , url: '/getDigitalIdForInternalAssessmentScore'
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    var list = [];
                    for (var i = 0; i < response.data.result.length; i++) {
                        var map = new Object();
                        var internalAssessmentRegistrationId = response.data.result[i].internalAssessmentRegistrationId;
                        map['name'] = response.data.result[i].digitalIdInfo.fullName;
                        map['emailId'] = response.data.result[i].digitalIdInfo.emailId;
                        for (var j = 0; j < response.data.result[i].digitalIdInfo.internalAssessmentDetails.length; j++) {
                            if (internalAssessmentRegistrationId == response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].internalAssessmentRegistrationId) {
                                map['internalAssessmentRegistrationId'] = response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].internalAssessmentRegistrationId;
                                map['digitalId'] = response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].digitalId;
                                map['selectedSkill'] = response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].selectedSkill;
                                map['assessmentCode'] = response.data.result[i].digitalIdInfo.internalAssessmentDetails[j].assessmentCode;
                                list.push(map);
                            }
                        }
                    }
                    $scope.tableData = list;
                    $scope.tableParams = new NgTableParams({
                        count: 4
                    }, {
                        counts: []
                        , dataset: $scope.tableData
                    });
                }
                else {
                    alert('No records found in database');
                }
            });
        };
        $scope.getDiplomaRegistrationIdRequests = function () {
            $http({
                method: 'GET'
                , url: '/getDiplomaRegistrationIdRequestsForCoordinator'
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.tableData = response.data.result;
                    $scope.tableParams = new NgTableParams({
                        count: 4
                    }, {
                        counts: []
                        , dataset: $scope.tableData
                    });
                }
                else {
                    alert('No records found in database');
                }
            });
        };
        $scope.selectedDigitalIdForSkillAssignment = function (digitalId) {
            $window.sessionStorage.setItem('_id', digitalId);
            $window.location.href = '/add_skill_sets.html';
        };
        $scope.selectedDigitalIdForAssessmentEvaluation = function (x) {
            $window.sessionStorage.setItem('_id', x.digitalId);
            var assessmentcode = x.assessmentCode;
            $window.location.href = '/' + assessmentcode + '_readonly.html';
        };
        $scope.selectedDigitalIdForDiplomaRegistrationId = function (digitalId) {
            $window.sessionStorage.setItem('_id', digitalId);
            $window.location.href = '/review_final_exam_form_coordinator.html';
        };
        $scope.Logout = function () {
            window.close();
        };
  }
]);
/* Apply For Skill Set Assessment Controller */
myApp.controller('addSkillSets', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , '$sce'
  , function ($scope, fileUpload, $http, $filter, $window, $sce) {
        $scope.isDisabled = false;
        $scope.skillSet = '';
        $scope.technicalSkills = ['Computer Science', 'Mathematics'];
        $scope.Back = function () {
            $window.location.href = '/co-ordinator_admin.html';
        };
        $scope.openIdProofImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.idProof.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.idProof._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.openApplicantImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.applicantImg.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.applicantImg._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.loadDigitalIdData = function () {
            var data = {
                _id: $window.sessionStorage.getItem('_id')
            };
            $http({
                method: 'POST'
                , url: '/getDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true && response.data.result[0].digitalIdStatus == 'Approved') {
                    $scope.digitalIdData = response.data.result[0];
                    $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                    $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                    $scope.list = [];
                    for (var i = 0; i < $scope.allTxnIds.length; i++) {
                        var map = new Object();
                        map['txnId'] = $scope.allTxnIds[i].tx_id;
                        map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                        $scope.list.push(map);
                    }
                }
                else {
                    alert('You have already applied for skill sets.');
                    window.close();
                }
            });
        };
        $scope.updateDigitalIdData = function () {
            $scope.isDisabled = true;
            var uniqueId = Date.now();
            var assessmentDetails = {
                internalAssessmentRegistrationId: uniqueId + ''
                , assessmentUserAnswer: ''
                , assessmentCorrectAnswer: ''
                , assessmentScore: ''
                , digitalId: $scope.digitalIdData.digitalIdInfo.digitalId
                , assessmentCode: ''
                , selectedSkill: $scope.skillSet
                , assessmentStatus: 'Pending'
            };
            var message = $scope.digitalIdData.message + ' The applicant has added his skillsets successfully.';
            $scope.digitalIdData.message = message;
            $scope.digitalIdData.internalAssessmentRegistrationId = assessmentDetails.internalAssessmentRegistrationId;
            $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails.push(assessmentDetails);
            var data = {
                data: $scope.digitalIdData
                , chaincodeFunction: 'addSkillSet'
                , user: 'applicant'
            };
            $http({
                method: 'POST'
                , url: '/updateDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/skill_set_add_success.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
  }
]);
/* Assessment Controller */
myApp.controller('assessment', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.isDisabled = false;
        $scope.on = function () {
            $('#myModal').modal('show');
            document.getElementById('overlay').style.display = 'block';
        };
        $scope.off = function () {
            document.getElementById('overlay').style.display = 'none';
        };
        $scope.proceed = function () {
            $('#myModal').modal('hide');
            document.getElementById('overlay').style.display = 'block';
        };
        $scope.dontProceed = function () {
            $window.location.href = '/assessment_no_choice.html';
        };
        $scope.getRegistrationId = function () {
            var data = {
                _id: $scope.digitalId
                , functionName: 'queryStudentDetails'
                , user: 'assessment'
                , toBeFetchedFrom: 'cloudant'
            };
            $http({
                method: 'POST'
                , url: '/getDigitalIdDataFromCloudant'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.internalAssessmentRegistrationId = response.data.result[0].internalAssessmentRegistrationId;
                    $scope.off();
                }
                else {
                    alert(response.data.message);
                }
            });
        };
        $scope.submitAssessment = function () {
            $scope.isDisabled = true;
            var userAnsers = $scope.answer1 + ',' + $scope.answer2 + ',' + $scope.answer3 + ',' + $scope.answer4 + ',' + $scope.answer5;
            var data = {
                digitalId: $scope.digitalId
                , internalAssessmentRegistrationId: $scope.internalAssessmentRegistrationId
                , chaincodeFunction: 'submitAssessment'
                , user: 'applicant'
                , answer: userAnsers
            };
            $http({
                method: 'POST'
                , url: '/submitAssessmentData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/assessment_success.html';
                }
                else {
                    alert(response.data.message);
                    window.close();
                }
            });
        };
  }
]);
/* Assessment Read Only Controller */
myApp.controller('assessmentReadOnly', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , '$sce'
  , function ($scope, fileUpload, $http, $filter, $window, $sce) {
        $scope.isDisabled = false;
        var data = {
            _id: $window.sessionStorage.getItem('_id')
        };
        $scope.loadDigitalIdData = function () {
            $http({
                method: 'POST'
                , url: '/getDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.digitalIdData = response.data.result[0];
                    $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                    $scope.list = [];
                    for (var i = 0; i < $scope.allTxnIds.length; i++) {
                        var map = new Object();
                        map['txnId'] = $scope.allTxnIds[i].tx_id;
                        map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                        $scope.list.push(map);
                    }
                    var digitalIdData = response.data.result[0].digitalIdInfo.internalAssessmentDetails;
                    for (var i = 0; i < digitalIdData.length; i++) {
                        if (digitalIdData[i].assessmentScore == '') {
                            $scope.digitalId = digitalIdData[i].digitalId;
                            $scope.internalAssessmentRegistrationId = digitalIdData[i].internalAssessmentRegistrationId;
                            var answers = digitalIdData[i].assessmentUserAnswer.split(',');
                            $scope.answer1 = answers[0];
                            $scope.answer2 = answers[1];
                            $scope.answer3 = answers[2];
                            $scope.answer4 = answers[3];
                            $scope.answer5 = answers[4];
                        }
                    }
                }
                else {
                    alert(response.data.message);
                }
            });
        };
        $scope.getScore = function () {
            var assessmentData = $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails;
            var score = 0;
            for (var i = 0; i < assessmentData.length; i++) {
                if (assessmentData[i].assessmentScore == '' && assessmentData[i].internalAssessmentRegistrationId == $scope.internalAssessmentRegistrationId) {
                    var userAnswers = assessmentData[i].assessmentUserAnswer.split(',');
                    var correctAnswers = assessmentData[i].assessmentCorrectAnswer.split(',');
                    for (var i = 0; i < correctAnswers.length; i++) {
                        if (userAnswers[i] != '' && userAnswers[i] == correctAnswers[i]) score++;
                    }
                }
            }
            $scope.score = '4';
        };
        $scope.submitResult = function () {
            $scope.isDisabled = true;
            var message = $scope.digitalIdData.message + ' The score has been evaluated and sent as transcript to applicant .';
            $scope.digitalIdData.message = message;
            $scope.digitalIdData.transcriptSent = 'Approved';
            for (var i = 0; i < $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails.length; i++) {
                if ($scope.digitalIdData.digitalIdInfo.internalAssessmentDetails[i].assessmentScore == '' && $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId == $scope.internalAssessmentRegistrationId) {
                    $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails[i].assessmentScore = $scope.score;
                }
            }
            var data = {
                data: $scope.digitalIdData
                , chaincodeFunction: 'addAssessmentDetails'
                , user: 'applicant'
            };
            $http({
                method: 'POST'
                , url: '/updateDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/co-ordinator_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
        $scope.Back = function () {
            $window.location.href = '/co-ordinator_admin.html';
        };
        $scope.Logout = function () {
            window.close();
        };
  }
]);
/* Internal Assessment Score Review Form Controller */
myApp.controller('internalAssessmentScoreReview', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.isDisabled = false;
        var data = {
            _id: $window.sessionStorage.getItem('_id')
        };
        $scope.openIdProofImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.idProof.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.idProof._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.openApplicantImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.applicantImg.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.applicantImg._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.loadDigitalIdData = function () {
            $http({
                method: 'POST'
                , url: '/getDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.digitalIdData = response.data.result[0];
                    $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                    for (var i = 0; i < response.data.result[0].digitalIdInfo.internalAssessmentDetails.length; i++) {
                        if (response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId == response.data.result[0].internalAssessmentRegistrationId) {
                            $scope.internalAssessmentRegistrationId = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId;
                            $scope.assessmentScore = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].assessmentScore;
                            $scope.selectedSkill = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].selectedSkill;
                        }
                    }
                    $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                    $scope.list = [];
                    for (var i = 0; i < $scope.allTxnIds.length; i++) {
                        var map = new Object();
                        map['txnId'] = $scope.allTxnIds[i].tx_id;
                        map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                        $scope.list.push(map);
                    }
                }
                else {
                    alert(response.data.message);
                }
            });
        };
        $scope.updateDigitalIdData = function (buttonValue) {
            $scope.isDisabled = true;
            var message = $scope.digitalIdData.message + ' The score has been evaluated and sent as transcript to applicant .';
            $scope.digitalIdData.message = message;
            for (var i = 0; i < $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails.length; i++) {
                if ($scope.digitalIdData.digitalIdInfo.internalAssessmentDetails[i].assessmentScore != '' && $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId == $scope.internalAssessmentRegistrationId) {
                    $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails[i].assessmentScore = $scope.assessmentScore;
                    $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails[i].assessmentStatus = 'Approved';
                }
            }
            var data = {
                data: $scope.digitalIdData
                , chaincodeFunction: 'addInternalAssessmentDetails'
                , user: 'university'
            };
            $http({
                method: 'POST'
                , url: '/updateDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/awarding_body_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
        $scope.Back = function () {
            $window.location.href = '/awarding_body_admin.html';
        };
        $scope.Logout = function () {
            window.close();
        };
  }
]);
/* Apply For Final Exam Controller */
myApp.controller('applyFinalExam', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , '$sce'
  , function ($scope, fileUpload, $http, $filter, $window, $sce) {
        $scope.isDisabled = false;
        $scope.Back = function () {
            $window.location.href = '/student_portal.html';
        };
        $scope.on = function () {
            document.getElementById('overlay').style.display = 'block';
        };
        $scope.off = function () {
            document.getElementById('overlay').style.display = 'none';
        };
        $scope.openIdProofImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.idProof.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.idProof._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.openApplicantImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.applicantImg.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.applicantImg._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.loadDigitalIdData = function () {
            var data = {
                _id: $scope.digitalId
            };
            $http({
                method: 'POST'
                , url: '/getDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true && response.data.result[0].digitalIdStatus == 'Approved') {
                    $scope.digitalIdData = response.data.result[0];
                    $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                    for (var i = 0; i < response.data.result[0].digitalIdInfo.internalAssessmentDetails.length; i++) {
                        if (response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId == response.data.result[0].internalAssessmentRegistrationId) {
                            $scope.internalAssessmentRegistrationId = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId;
                            $scope.assessmentScore = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].assessmentScore;
                            $scope.selectedSkill = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].selectedSkill;
                        }
                    }
                    $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                    $scope.list = [];
                    for (var i = 0; i < $scope.allTxnIds.length; i++) {
                        var map = new Object();
                        map['txnId'] = $scope.allTxnIds[i].tx_id;
                        map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                        $scope.list.push(map);
                    }
                    $scope.off();
                }
                else {
                    alert(response.data.message);
                    window.close();
                }
            });
        };
        $scope.applyForFinalExam = function () {
            $scope.isDisabled = true;
            var message = $scope.digitalIdData.message + ' The applicant has applied for final exam.';
            $scope.digitalIdData.message = message;
            $scope.digitalIdData.finalDiplomaRegistrationByApplicant = 'Completed';
            var data = {
                data: $scope.digitalIdData
                , chaincodeFunction: 'applyForFinalExam'
                , user: 'applicant'
            };
            $http({
                method: 'POST'
                , url: '/updateDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/final_exam_registration_success.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
  }
]);
/* Review Applicant Final Exam Registration Form(Coordinator) Controller */
myApp.controller('finalExamFormReviewByCoordinator', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , '$sce'
  , function ($scope, fileUpload, $http, $filter, $window, $sce) {
        $scope.isDisabled = false;
        $scope.Back = function () {
            $window.location.href = '/co-rodinator_admin.html';
        };
        $scope.openIdProofImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.idProof.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.idProof._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.openApplicantImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.applicantImg.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.applicantImg._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.loadDigitalIdData = function () {
            var data = {
                _id: $window.sessionStorage.getItem("_id")
            };
            $http({
                method: 'POST'
                , url: '/getDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true && response.data.result[0].digitalIdStatus == 'Approved') {
                    $scope.digitalIdData = response.data.result[0];
                    $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                    for (var i = 0; i < response.data.result[0].digitalIdInfo.internalAssessmentDetails.length; i++) {
                        if (response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId == response.data.result[0].internalAssessmentRegistrationId) {
                            $scope.internalAssessmentRegistrationId = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId;
                            $scope.assessmentScore = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].assessmentScore;
                            $scope.selectedSkill = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].selectedSkill;
                        }
                    }
                    $scope.list = [];
                    $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                    $scope.list = [];
                    for (var i = 0; i < $scope.allTxnIds.length; i++) {
                        var map = new Object();
                        map['txnId'] = $scope.allTxnIds[i].tx_id;
                        map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                        $scope.list.push(map);
                    }
                }
                else {
                    alert(response.data.message);
                    window.close();
                }
            });
        };
        $scope.submissionByCoordinator = function () {
            $scope.isDisabled = true;
            var message = $scope.digitalIdData.message + ' The applicant form has been successfully reviewed by coordinator';
            $scope.digitalIdData.message = message;
            $scope.digitalIdData.finalDiplomaRegistrationByCoordinator = 'Completed';
            var data = {
                data: $scope.digitalIdData
                , chaincodeFunction: 'reviewFinalExamFormByCoordinator'
                , user: 'applicant'
            };
            $http({
                method: 'POST'
                , url: '/updateDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/co-ordinator_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
  }
]);
/* Review Applicant Final Exam Registration Form(Awarding Body) Controller */
myApp.controller('finalExamFormReviewByAwardingBody', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , '$sce'
  , function ($scope, fileUpload, $http, $filter, $window, $sce) {
        $scope.isDisabled = false;
        $scope.Back = function () {
            $window.location.href = '/awarding_body_admin.html';
        };
        $scope.openIdProofImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.idProof.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.idProof._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.openApplicantImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.applicantImg.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.applicantImg._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.loadDigitalIdData = function () {
            var data = {
                _id: $window.sessionStorage.getItem("_id")
            };
            $http({
                method: 'POST'
                , url: '/getDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true && response.data.result[0].digitalIdStatus == 'Approved') {
                    $scope.digitalIdData = response.data.result[0];
                    $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                    for (var i = 0; i < response.data.result[0].digitalIdInfo.internalAssessmentDetails.length; i++) {
                        if (response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId == response.data.result[0].internalAssessmentRegistrationId) {
                            $scope.internalAssessmentRegistrationId = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId;
                            $scope.assessmentScore = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].assessmentScore;
                            $scope.selectedSkill = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].selectedSkill;
                        }
                    }
                    $scope.list = [];
                    $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                    $scope.list = [];
                    for (var i = 0; i < $scope.allTxnIds.length; i++) {
                        var map = new Object();
                        map['txnId'] = $scope.allTxnIds[i].tx_id;
                        map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                        $scope.list.push(map);
                    }
                }
                else {
                    alert(response.data.message);
                    window.close();
                }
            });
        };
        $scope.submitApplicantDetails = function () {
            $scope.isDisabled = true;
            var message = $scope.digitalIdData.message + ' The applicant form has been successfully reviewed by coordinator';
            $scope.digitalIdData.message = message;
            var uniqueId = Date.now();
            $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaRegistartionId = uniqueId;
            var data = {
                data: $scope.digitalIdData
                , chaincodeFunction: 'addFinalDiplomaExamRegistrationId'
                , user: 'university'
            };
            $http({
                method: 'POST'
                , url: '/updateDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/awarding_body_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
  }
]);
/* Apply For University Controller */
myApp.controller('applyUniversity', ['$scope', 'fileUpload', '$http', '$filter', '$window', '$sce', function ($scope, fileUpload, $http, $filter, $window, $sce) {
    $scope.isDisabled = false;
    $scope.selectedUniversityName = "";
    $scope.courses = ["Ancient History", "Computer Science", "Microservices"];
    $scope.degreeTypes = ["UG", "PG"];
    $scope.Back = function () {
        $window.location.href = '/student_portal.html';
    }
    $scope.on = function () {
        document.getElementById("overlay").style.display = "block";
    }
    $scope.off = function () {
        document.getElementById("overlay").style.display = "none";
    }
    $scope.changeUniversity = function (data) {
        $scope.selectedUniversityAddress = data.universityAddress;
        $scope.selectedUniversityId = data.universityId;
    }
    $scope.universityData = [{
        universityName: "University College London"
        , universityAddress: "United Kingdom"
        , universityId: "U-1"
 }, {
        universityName: "University of Chicago"
        , universityAddress: "United States"
        , universityId: "U-2"
 }, {
        universityName: "Imperial College London"
        , universityAddress: "United Kingdom"
        , universityId: "U-3"
 }, {
        universityName: " Massachusetts Institute of Technology"
        , universityAddress: "United States"
        , universityId: "U-4"
 }];
    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }
    $scope.openTranscriptImg = function () {
        window.open('https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com/digital_id_applicant_documents/39d35777d0bc219fdef69d2ebf33ca30/transcript.png', '_blank');
    }
    $scope.transcriptImg = 'transcript.png';
    $scope.loadDigitalIdData = function () {
        var data = {
            _id: $scope.digitalId
        }
        $http({
            method: 'POST'
            , url: '/getDigitalIdData'
            , data: data
        }).then(function successCallback(response) {
            if (response.data.success == true && response.data.result[0].digitalIdStatus == 'Approved') {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                var assessmentDetails = $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails;
                for (var i = 0; i < assessmentDetails.length; i++) {
                    if (assessmentDetails[i].internalAssessmentRegistrationId == $scope.digitalIdData.internalAssessmentRegistrationId) {
                        $scope.internalAssessmentRegistrationId = assessmentDetails[i].internalAssessmentRegistrationId;
                        $scope.skillset = assessmentDetails[i].selectedSkill;
                        $scope.score = assessmentDetails[i].assessmentScore;
                    }
                }
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
                $scope.off();
            }
            else {
                alert(response.data.message);
                window.close();
            }
        });
    }
    $scope.addUniversityData = function () {
        $scope.isDisabled = true;
        var universityData = {
            universityName: $scope.selectedUniversityName.universityName
            , universityAddress: $scope.selectedUniversityAddress
            , universityId: $scope.selectedUniversityId
            , courseAppliedFor: $scope.selectedCourse
            , appliedDegreeType: $scope.selectedDegreeType
            , courseStartDate: ''
            , courseEndDate: ''
            , degreeCompleteStatus: false
            , digitalId: $scope.digitalIdData.digitalIdInfo.digitalId
            , registrationId: $scope.digitalIdData.registrationId
            , universityDocument: ''
            , semesterDetails: []
        };
        var message = $scope.digitalIdData.message + " The applicant has added his university choices.";
        $scope.digitalIdData.message = message;
        $scope.digitalIdData.digitalIdInfo.universityDetails.push(universityData);
        var data = {
            data: $scope.digitalIdData
            , chaincodeFunction: "addUniversity"
            , user: "applicant"
        }
        $http({
            method: 'POST'
            , url: '/updateDigitalIdData'
            , data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/university_success.html';
            }
            else {
                alert(response.data.message);
            }
        });
    }
}]);
/* University Read Only Form Controller */
myApp.controller('universityReadOnlyForm', ['$scope', 'fileUpload', '$http', '$filter', '$window', '$sce', function ($scope, fileUpload, $http, $filter, $window, $sce) {
    $scope.isDisabled = false;
    var data = {
        _id: $window.sessionStorage.getItem("_id")
    }
    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }
    $scope.openTranscriptImg = function () {
        window.open('https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com/digital_id_applicant_documents/39d35777d0bc219fdef69d2ebf33ca30/transcript.png', '_blank');
    }
    $scope.transcriptImg = 'transcript.png';
    $scope.loadDigitalIdData = function () {
        $http({
            method: 'POST'
            , url: '/getDigitalIdData'
            , data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                var assessmentDetails = $scope.digitalIdData.digitalIdInfo.internalAssessmentDetails;
                for (var i = 0; i < assessmentDetails.length; i++) {
                    if (assessmentDetails[i].internalAssessmentRegistrationId == $scope.digitalIdData.internalAssessmentRegistrationId) {
                        $scope.internalAssessmentRegistrationId = assessmentDetails[i].internalAssessmentRegistrationId;
                        $scope.skillset = assessmentDetails[i].selectedSkill;
                        $scope.score = assessmentDetails[i].assessmentScore;
                    }
                }
                var universityDetails = $scope.digitalIdData.digitalIdInfo.universityDetails;
                for (var i = 0; i < universityDetails.length; i++) {
                    if (universityDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                        $scope.universityName = universityDetails[i].universityName;
                        $scope.universityAddress = universityDetails[i].universityAddress;
                        $scope.universityId = universityDetails[i].universityId;
                        $scope.courseAppliedFor = universityDetails[i].courseAppliedFor;
                        $scope.appliedDegreeType = universityDetails[i].appliedDegreeType;
                    }
                }
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
            }
            else {
                alert(response.data.message);
            }
        });
    }
    $scope.updateDigitalIdData = function (buttonValue) {
        $scope.isDisabled = true;
        var message = $scope.digitalIdData.message + " The university admission request has been " + buttonValue + ".";
        $scope.digitalIdData.message = message;
        if (buttonValue == "Approved") {
            $scope.digitalIdData.universityAdmissionStatus = "Approved";
            for (var i = 0; i < $scope.digitalIdData.digitalIdInfo.universityDetails.length; i++) {
                if ($scope.digitalIdData.digitalIdInfo.universityDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                    $scope.digitalIdData.digitalIdInfo.universityDetails[i].courseStartDate = Date.now() + '';
                }
            }
        }
        if (buttonValue == "Rejected") $scope.digitalIdData.digitalIdStatus = "Rejected";
        var data = {
            data: $scope.digitalIdData
            , chaincodeFunction: "addUniveristyDetails"
            , user: "university"
        }
        $http({
            method: 'POST'
            , url: '/updateDigitalIdData'
            , data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/university_admin.html';
            }
            else {
                alert(response.data.message);
            }
        });
    }
    $scope.Back = function () {
        $window.location.href = '/university_admin.html';
    }
    $scope.Logout = function () {
        window.close();
    }
}]);
/* Add Trabscript Details Form(Awarding Body) Controller */
myApp.controller('addTranscriptDetails', [
    '$scope'
    , 'fileUpload'
    , '$http'
    , '$filter'
    , '$window'
    , '$sce'
    , function ($scope, fileUpload, $http, $filter, $window, $sce) {
        $scope.isDisabled = false;
        $scope.Back = function () {
            $window.location.href = '/awarding_body_admin.html';
        };
        $scope.openIdProofImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.idProof.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.idProof._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.openApplicantImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.applicantImg.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.applicantImg._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.loadDigitalIdData = function () {
            var data = {
                _id: $window.sessionStorage.getItem("_id")
            };
            $http({
                method: 'POST'
                , url: '/getDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true && response.data.result[0].digitalIdStatus == 'Approved') {
                    $scope.digitalIdData = response.data.result[0];
                    $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                    $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaSubjectsAndScores.group1Score = '6';
                    $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaSubjectsAndScores.group2Score = '4';
                    $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaSubjectsAndScores.group3Score = '5';
                    $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaSubjectsAndScores.group4Score = '4';
                    $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaSubjectsAndScores.group5Score = '4';
                    $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaSubjectsAndScores.group6Score = '5';
                    $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaTotalScore = '29';
                    for (var i = 0; i < response.data.result[0].digitalIdInfo.internalAssessmentDetails.length; i++) {
                        if (response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId == response.data.result[0].internalAssessmentRegistrationId) {
                            $scope.internalAssessmentRegistrationId = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId;
                            $scope.assessmentScore = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].assessmentScore;
                            $scope.selectedSkill = response.data.result[0].digitalIdInfo.internalAssessmentDetails[i].selectedSkill;
                        }
                    }
                    $scope.list = [];
                    $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                    $scope.list = [];
                    for (var i = 0; i < $scope.allTxnIds.length; i++) {
                        var map = new Object();
                        map['txnId'] = $scope.allTxnIds[i].tx_id;
                        map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                        $scope.list.push(map);
                    }
                }
                else {
                    alert(response.data.message);
                    window.close();
                }
            });
        };
        $scope.submitApplicantDetails = function () {
            $scope.isDisabled = true;
            var message = $scope.digitalIdData.message + ' The transcript details have been submitted by the awarding body.';
            $scope.digitalIdData.message = message;
            var data = {
                data: $scope.digitalIdData
                , chaincodeFunction: 'addFinalDiplomaScoreDetails'
                , user: 'university'
            };
            $http({
                method: 'POST'
                , url: '/updateDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/awarding_body_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
    }
  ]);
/* Digital Id Read Only Form Controller */
myApp.controller('digitalIdReadOnlyForm', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.isDisabled = false;
        var data = {
            _id: $window.sessionStorage.getItem('_id')
        };
        $scope.openIdProofImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.idProof.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.idProof._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.openApplicantImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.applicantImg.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.applicantImg._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.loadDigitalIdData = function () {
            $http({
                method: 'POST'
                , url: '/getDigitalIdDataFromCloudant'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.digitalIdData = response.data.result[0];
                    $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                }
                else {
                    alert(response.data.message);
                }
            });
        };
        $scope.updateDigitalIdData = function (buttonValue) {
            $scope.isDisabled = true;
            var message = $scope.digitalIdData.message + ' The digital id request has been ' + buttonValue + '.';
            $scope.digitalIdData.message = message;
            if (buttonValue == 'Approved') {
                $scope.digitalIdData.digitalIdStatus = 'Approved';
                var uniqueId = Date.now();
                $scope.digitalIdData.digitalIdInfo.diplomaDetails.diplomaStartDate = uniqueId;
            }
            if (buttonValue == 'Rejected') $scope.digitalIdData.digitalIdStatus = 'Rejected';
            var data = {
                data: $scope.digitalIdData
                , chaincodeFunction: 'addStudentRecord'
                , user: 'university'
            };
            $http({
                method: 'POST'
                , url: '/updateDigitalIdData'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $window.location.href = '/awarding_body_admin.html';
                }
                else {
                    alert(response.data.message);
                }
            });
        };
        $scope.Back = function () {
            $window.location.href = '/consortium_admin.html';
        };
        $scope.Logout = function () {
            window.close();
        };
  }
]);

/* Port Folio View Controller */
myApp.controller('portFolioView', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.on = function () {
            document.getElementById('overlay').style.display = 'block';
        };
        $scope.off = function () {
            document.getElementById('overlay').style.display = 'none';
        };
        $scope.transcriptImg = 'transcript.png';
        $scope.openIdProofImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.idProof.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.idProof._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.openTranscriptImg = function () {
            window.open('https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com/digital_id_applicant_documents/39d35777d0bc219fdef69d2ebf33ca30/transcript.png', '_blank');
        };
        $scope.openApplicantImg = function () {
            var cloudantURL = 'https://63ded591-69b0-479d-95ff-270c54c2260d-bluemix:1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796@63ded591-69b0-479d-95ff-270c54c2260d-bluemix.cloudant.com';
            var cloudantDocDB = 'digital_id_applicant_documents';
            var documentName = $scope.digitalIdData.digitalIdInfo.applicantImg.docName;
            var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.applicantImg._id;
            window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');
        };
        $scope.getDataFromBlockChain = function () {
            var data = {
                _id: $scope.digitalId
            };
            $http({
                method: 'POST'
                , url: '/getDataFromBlockChain'
                , data: data
            }).then(function successCallback(response) {
                if (response.data.success == true) {
                    $scope.universityDetails= [];
                    $scope.internalAssessmentDetails= [];
                    $scope.off();
                    var digitalIdData = JSON.parse(response.data.response.digitalIdData.response);
                    var txnDetails = JSON.parse(response.data.response.txnIds.response);
                    var basicApplicantInfo = {
                        digitalId: digitalIdData.digitalId
                        , nationalId: digitalIdData.nationalId
                        , dateOfBirth: new Date(digitalIdData.dateOfBirth)
                        , gender: digitalIdData.gender
                        , address: digitalIdData.address
                        , emailId: digitalIdData.emailId
                        , countrycode: digitalIdData.countrycode
                        , mobileNumber: digitalIdData.mobileNumber
                        , fullName: digitalIdData.fullName
                        , txnId: ''
                    };
                    var applicantDoc = {
                        applicantDocument: digitalIdData.applicantImg
                        , txnId: ''
                    };
                    var idProof = {
                        documentDetails: digitalIdData.idProof
                        , txnId: ''
                    };
                    var allDocs = {
                        idProof: idProof
                        , applicantDoc: applicantDoc
                        , finalDegreeDoc: {"_id": "39d35777d0bc219fdef69d2ebf33ca30","_rev": "2-c5450941ebb536577321941199dddf46",
                                           "_attachments": {"transcript.png": {"content_type": "image/png","revpos": 2, "digest": "md5-xPS6Wa5KAblebxZ7asUWow==","length": 65981,"stub": true}}},
                        finalDegreeTxn: ''
                    };
                    //Internal Assessment Details
                    var assessmentDetails ={
                        assessmentDetails : digitalIdData.internalAssessmentDetails
                        , txnId: ''
                    } 
                    //University Details
                    var universityDetails = '';
                    if(digitalIdData.universityDetails.length > 0){
                        universityDetails = {
                            universityDetails : digitalIdData.universityDetails
                            , txnId: ''                    
                        }
                    }
                    //Transcript Details
                    var transcriptDetails = {
                            transcriptDetails: digitalIdData.diplomaDetails
                            , txnId: ''
                        }
                    //Applicant Details
                    for (var i = 0; i < txnDetails.length; i++) {
                        if (txnDetails[i].Record.txnMsg == 'Applicant data successfully inserted into blockchain.') {
                            basicApplicantInfo.txnId = txnDetails[i].tx_id;
                            allDocs.applicantDoc.txnId = txnDetails[i].tx_id;
                            allDocs.idProof.txnId = txnDetails[i].tx_id;
                        }
                        if (txnDetails[i].Record.txnMsg == 'Final diploma score details added to the applicant record.') {
                            transcriptDetails.txnId = txnDetails[i].tx_id;
                            allDocs.finalDegreeTxn = txnDetails[i].tx_id;
                        }
                        if (txnDetails[i].Record.txnMsg == 'Internal Assessment details added to the applicant record.') {
                            assessmentDetails.txnId = txnDetails[i].tx_id;
                        }
                        if (txnDetails[i].Record.txnMsg == 'University details added to the applicant record.') {
                            universityDetails.txnId = txnDetails[i].tx_id;
                        }
                    }
                    $scope.basicInfo = basicApplicantInfo;
                    $scope.universityDetails.push(universityDetails);
                    $scope.internalAssessmentDetails.push(assessmentDetails);
                    $scope.transcriptDetails = transcriptDetails;
                    $scope.allDocs = allDocs;
                }
            });
        };
  }
]);
/* Student Digital Id Explorer */
myApp.controller('explorerApp', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        //Intial Page Load Will Show Current Block Data
        $scope.initialLoad = function () {
            $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
            $('#loading').show();
            $http({
                method: 'POST'
                , url: '/explorerLoadData'
            }).then(function successCallback(response) {
                if (response.data.success) {
                    $('#loading').hide();
                    $scope.forward = true;
                    var channelData = response.data.response.channelInfo;
                    var blockData = response.data.response.blockInfo;
                    var chaincodeData = response.data.response.chaincodeInfo;
                    var txnData = response.data.response.txnInfo;
                    $scope.currentDataHash = blockData.data_hash;
                    $scope.previousDataHash = blockData.previous_hash;
                    $scope.txnId = txnData.row.txhash;
                    $scope.txn_creator = txnData.row.creator_msp_id;
                    $scope.digitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);
                    $scope.total_blocks = channelData.channels[0].blocks;
                    $scope.current_block_no = channelData.channels[0].blocks;
                    $scope.total_txns = channelData.channels[0].transactions;
                    $scope.channel_genesis_hash = channelData.channels[0].channel_genesis_hash;
                    $scope.chaincode = chaincodeData.chaincode[0].chaincodename;
                    $scope.peers = [
                        {
                            peerName: 'peer0.university.cts.com'
                            , organization: 'university'
                            , mspId: 'Org1MSP'
                            , portNo: '7051'
            }
                        , {
                            peerName: 'peer0.awardingbody.cts.com'
                            , organization: 'awardingbody'
                            , mspId: 'Org2MSP'
                            , portNo: '8051'
            }
                        , {
                            peerName: 'peer0.coordinator.cts.com'
                            , organization: 'coordinator'
                            , mspId: 'Org3MSP'
                            , portNo: '9051'
            }
          ];
                    $scope.nodes = $scope.peers.length;
                    if ($scope.digitalIdData.txnMsg == 'Applicant data successfully inserted into blockchain.') {
                        $scope.applicantDetails = true;
                        $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        $scope.txnMsg = 'Applicant data inserted into blockchain with student Id as ' + $scope.digitalIdData.digitalId;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Internal Assessment details added to the applicant record.') {
                        var assessmentDetails = $scope.digitalIdData.internalAssessmentDetails[$scope.digitalIdData.internalAssessmentDetails.length - 1];
                        $scope.assessmentDetails = true;
                        $scope.applicantDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        $scope.txnMsg = 'Internal Assessment details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.internalAssessmentRegistrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'University details added to the applicant record.') {
                        $scope.universityDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                        $scope.txnMsg = 'University details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Final diploma exam registartion id added to the applicant record.') {
                        $scope.semesterDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.networkDetails = false;
                        var universityDetails = $scope.digitalIdData.diplomaDetails;
                        $scope.txnMsg = 'Final exam registration id has been generated as '+universityDetails.diplomaRegistartionId+' and added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Final diploma score details added to the applicant record.') {
                        $scope.finalDegreeCertDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        var finalDegreeDetails = $scope.digitalIdData.diplomaDetails;
                        $scope.txnMsg = 'Final exam transcript has been added to applicant data with digitalId ' + $scope.digitalIdData.digitalId+', where the total score for him was '+finalDegreeDetails.diplomaTotalScore;
                    }
                    else {
                        $scope.networkDetails = true;
                        $scope.txnMsg = 'Network configuration took place.';
                    }
                }
                else alert(response.data.message);
            });
        };
        // On Click Of Back Arrow Will Show Previous Block Data
        $scope.Back = function () {
            $('#loading').show();
            $scope.current_block_no_count = $scope.current_block_no - 1;
            if ($scope.current_block_no >= 1) {
                var data = {
                    blockNo: $scope.current_block_no_count - 1
                    , channelHash: $scope.channel_genesis_hash
                };
                $http({
                    method: 'POST'
                    , url: '/explorerBlockData'
                    , data: data
                }).then(function successCallback(response) {
                    $('#loading').hide();
                    var blockData = response.data.response.blockInfo;
                    var txnData = response.data.response.txnInfo;
                    $scope.current_block_no = $scope.current_block_no_count;
                    $scope.currentDataHash = blockData.data_hash;
                    $scope.previousDataHash = blockData.previous_hash;
                    $scope.txnId = txnData.row.txhash;
                    $scope.txn_creator = txnData.row.creator_msp_id;
                    $scope.digitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);
                    if ($scope.digitalIdData.txnMsg == 'Applicant data successfully inserted into blockchain.') {
                        $scope.applicantDetails = true;
                        $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        $scope.txnMsg = 'Applicant data inserted into blockchain with student Id as ' + $scope.digitalIdData.digitalId;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Internal Assessment details added to the applicant record.') {
                        var assessmentDetails = $scope.digitalIdData.internalAssessmentDetails[$scope.digitalIdData.internalAssessmentDetails.length - 1];
                        $scope.assessmentDetails = true;
                        $scope.applicantDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        $scope.txnMsg = 'Internal Assessment details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.internalAssessmentRegistrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'University details added to the applicant record.') {
                        $scope.universityDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                        $scope.txnMsg = 'University details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Final diploma exam registartion id added to the applicant record.') {
                        $scope.semesterDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.networkDetails = false;
                        var universityDetails = $scope.digitalIdData.diplomaDetails;
                        $scope.txnMsg = 'Final exam registration id has been generated as '+universityDetails.diplomaRegistartionId+' and added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Final diploma score details added to the applicant record.') {
                        $scope.finalDegreeCertDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        var finalDegreeDetails = $scope.digitalIdData.diplomaDetails;
                        $scope.txnMsg = 'Final exam transcript has been added to applicant data with digitalId ' + $scope.digitalIdData.digitalId+', where the total score for him was '+finalDegreeDetails.diplomaTotalScore;
                    }
                    else {
                        $scope.networkDetails = true;
                        $scope.txnMsg = 'Network configuration took place.';
                    }
                });
            }
            else {
                $('#loading').hide();
                alert('This is the first block in the network, going back beyond this is not possible.');
            }
        };
        // On Click Of Forward Arrow Will Show Next Block Data
        $scope.Forward = function () {
            $('#loading').show();
            $scope.current_block_no_count = $scope.current_block_no + 1;
            if ($scope.current_block_no_count < $scope.total_blocks) {
                var data = {
                    blockNo: $scope.current_block_no_count
                    , channelHash: $scope.channel_genesis_hash
                };
                $http({
                    method: 'POST'
                    , url: '/explorerBlockData'
                    , data: data
                }).then(function successCallback(response) {
                    $('#loading').hide();
                    var blockData = response.data.response.blockInfo;
                    var txnData = response.data.response.txnInfo;
                    $scope.current_block_no = $scope.current_block_no_count;
                    $scope.currentDataHash = blockData.data_hash;
                    $scope.previousDataHash = blockData.previous_hash;
                    $scope.txnId = txnData.row.txhash;
                    $scope.txn_creator = txnData.row.creator_msp_id;
                    $scope.digitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);
                    if ($scope.digitalIdData.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                        $scope.applicantDetails = true;
                        $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        $scope.txnMsg = 'Applicant data inserted into blockchain with digital Id as ' + $scope.digitalIdData.digitalId;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Assessment details added to the applicant record.') {
                        var assessmentDetails = $scope.digitalIdData.assessmentDetails[$scope.digitalIdData.assessmentDetails.length - 1];
                        $scope.assessmentDetails = true;
                        $scope.applicantDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        $scope.txnMsg = 'Transcript details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.registrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'University details added for the applicant record.') {
                        $scope.universityDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                        $scope.txnMsg = 'University details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Semester certificates added to the applicant record.') {
                        $scope.semesterDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.networkDetails = false;
                        var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                        var semesterDetails = universityDetails.semesterDetails[universityDetails.semesterDetails.length - 1];
                        $scope.txnMsg = 'Semester ' + semesterDetails.semesterNo + ' certificate details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                    }
                    else if ($scope.digitalIdData.txnMsg == 'Final Degree certificate added to the applicant record.') {
                        $scope.finalDegreeCertDetails = true;
                        $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.semesterDetails = $scope.networkDetails = false;
                        var finalDegreeDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                        $scope.txnMsg = 'Final degree certificate added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                    }
                    else {
                        $scope.networkDetails = true;
                        $scope.txnMsg = 'Network configuration took place.';
                    }
                });
            }
            else {
                $('#loading').hide();
                alert('This is the last block in the network, going forward beyond this is not possible.');
            }
        };
        // On click Of Get Details and selection checkbox data
        $scope.find = function () {
            $('#loading').show();
            var data = {
                selectedOpt: $scope.selectedOpt
                , inputValue: $scope.inputValue
            };
            if (data.selectedOpt != undefined && data.inputValue != undefined) {
                if (data.selectedOpt == 'Block') {
                    var blockNo = {
                        blockNo: data.inputValue - 1
                        , channelHash: $scope.channel_genesis_hash
                    };
                    if (blockNo.blockNo > 0 && blockNo.blockNo < $scope.total_blocks) {
                        $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockFinalDegreeCertDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                        $http({
                            method: 'POST'
                            , url: '/explorerBlockData'
                            , data: blockNo
                        }).then(function successCallback(response) {
                            $('#loading').hide();
                            $('#blockModal').modal('show');
                            var blockData = response.data.response.blockInfo;
                            var txnData = response.data.response.txnInfo;
                            $scope.blockCurrentDataHash = blockData.data_hash;
                            $scope.blockPreviousDataHash = blockData.previous_hash;
                            $scope.blockTxnId = txnData.row.txhash;
                            $scope.block_txn_creator = txnData.row.creator_msp_id;
                            $scope.blockDigitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);
                            if ($scope.blockDigitalIdData.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                                $scope.blockApplicantDetails = true;
                                $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockFinalDegreeCertDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                                $scope.blockTxnMsg = 'Applicant data inserted into blockchain with digital Id as ' + $scope.blockDigitalIdData.digitalId;
                            }
                            else if ($scope.blockDigitalIdData.txnMsg == 'Assessment details added to the applicant record.') {
                                var assessmentDetails = $scope.blockDigitalIdData.assessmentDetails[$scope.blockDigitalIdData.assessmentDetails.length - 1];
                                $scope.blockAssessmentDetails = true;
                                $scope.blockApplicantDetails = $scope.blockUniversityDetails = $scope.blockFinalDegreeCertDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                                $scope.blockTxnMsg = 'Transcript details added to applicant data with digitalId ' + $scope.blockDigitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.registrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                            }
                            else if ($scope.blockDigitalIdData.txnMsg == 'University details added for the applicant record.') {
                                $scope.blockUniversityDetails = true;
                                $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockFinalDegreeCertDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                                var universityDetails = $scope.blockDigitalIdData.universityDetails[$scope.blockDigitalIdData.universityDetails.length - 1];
                                $scope.blockTxnMsg = 'University details added to applicant data with digitalId ' + $scope.blockDigitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                            }
                            else if ($scope.blockDigitalIdData.txnMsg == 'Semester certificates added to the applicant record.') {
                                $scope.blockSemesterDetails = true;
                                $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockFinalDegreeCertDetails = $scope.blockNetworkDetails = false;
                                var universityDetails = $scope.blockDigitalIdData.universityDetails[$scope.blockDigitalIdData.universityDetails.length - 1];
                                var semesterDetails = universityDetails.semesterDetails[universityDetails.semesterDetails.length - 1];
                                $scope.blockTxnMsg = 'Semester ' + semesterDetails.semesterNo + ' certificate details added to applicant data with digitalId ' + $scope.blockDigitalIdData.digitalId;
                            }
                            else if ($scope.blockDigitalIdData.txnMsg == 'Final Degree certificate added to the applicant record.') {
                                $scope.blockFinalDegreeCertDetails = true;
                                $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                                var blockFinalDegreeDetails = $scope.blockDigitalIdData.universityDetails[$scope.blockDigitalIdData.universityDetails.length - 1];
                                $scope.blockTxnMsg = 'Final degree certificate added to applicant data with digitalId ' + $scope.blockDigitalIdData.digitalId;
                            }
                            else {
                                $scope.blockNetworkDetails = true;
                                $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockSemesterDetails = $scope.blockFinalDegreeCertDetails = false;
                                $scope.blockTxnMsg = 'Network configuration took place.';
                            }
                        });
                    }
                }
                else {
                    var txnNo = {
                        txnId: data.inputValue
                        , channelHash: $scope.channel_genesis_hash
                    };
                    $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnFinalDegreeCertDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                    $http({
                        method: 'POST'
                        , url: '/explorerTxnData'
                        , data: txnNo
                    }).then(function successCallback(response) {
                        $('#loading').hide();
                        $('#txnModal').modal('show');
                        var txnData = response.data.response.txnInfo;
                        $scope.payload_hash = txnData.row.payload_proposal_hash;
                        $scope.create_timestamp = txnData.row.createdt;
                        $scope.txnTxnId = txnData.row.txhash;
                        $scope.txn_txn_creator = txnData.row.creator_msp_id;
                        $scope.txnDigitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);
                        if ($scope.txnDigitalIdData.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                            $scope.txnApplicantDetails = true;
                            $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnFinalDegreeCertDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                            $scope.txnTxnMsg = 'Applicant data inserted into blockchain with digital Id as ' + $scope.txnDigitalIdData.digitalId;
                        }
                        else if ($scope.txnDigitalIdData.txnMsg == 'Assessment details added to the applicant record.') {
                            var assessmentDetails = $scope.txnDigitalIdData.assessmentDetails[$scope.txnDigitalIdData.assessmentDetails.length - 1];
                            $scope.txnAssessmentDetails = true;
                            $scope.txnApplicantDetails = $scope.txnUniversityDetails = $scope.txnFinalDegreeCertDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                            $scope.txnTxnMsg = 'Transcript details added to applicant data with digitalId ' + $scope.txnDigitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.registrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                        }
                        else if ($scope.txnDigitalIdData.txnMsg == 'University details added for the applicant record.') {
                            $scope.txnUniversityDetails = true;
                            $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnFinalDegreeCertDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                            var universityDetails = $scope.txnDigitalIdData.universityDetails[$scope.txnDigitalIdData.universityDetails.length - 1];
                            $scope.txnTxnMsg = 'University details added to applicant data with digitalId ' + $scope.txnDigitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                        }
                        else if ($scope.txnDigitalIdData.txnMsg == 'Semester certificates added to the applicant record.') {
                            $scope.txnSemesterDetails = true;
                            $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnFinalDegreeCertDetails = $scope.txnNetworkDetails = false;
                            var universityDetails = $scope.txnDigitalIdData.universityDetails[$scope.txnDigitalIdData.universityDetails.length - 1];
                            var semesterDetails = universityDetails.semesterDetails[universityDetails.semesterDetails.length - 1];
                            $scope.txnTxnMsg = 'Semester ' + semesterDetails.semesterNo + ' certificate details added to applicant data with digitalId ' + $scope.txnDigitalIdData.digitalId;
                        }
                        else if ($scope.txnDigitalIdData.txnMsg == 'Final Degree certificate added to the applicant record.') {
                            $scope.txnFinalDegreeCertDetails = true;
                            $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                            var blockFinalDegreeDetails = $scope.txnDigitalIdData.universityDetails[$scope.txnDigitalIdData.universityDetails.length - 1];
                            $scope.txnTxnMsg = 'Final degree certificate added to applicant data with digitalId ' + $scope.txnDigitalIdData.digitalId;
                        }
                        else {
                            $scope.txnNetworkDetails = true;
                            $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnSemesterDetails = $scope.txnFinalDegreeCertDetails = false;
                            $scope.txnTxnMsg = 'Network configuration took place.';
                        }
                    });
                }
            }
            else {
                alert('Please select the checkbox and fill appropiate value in the input box to continue searching details !');
            }
        };
  }
]);
/* University Success Controller */
myApp.controller('universitySuccess', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.closeTab = function () {
            window.close();
        };
  }
]);
/* Digital Id Success Controller */
myApp.controller('digitalIdSuccess', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.closeTab = function () {
            window.close();
        };
  }
]);
/* Skill Set Success Controller */
myApp.controller('skillSetSuccess', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.closeTab = function () {
            window.close();
        };
  }
]);
/* Assessment Success Controller */
myApp.controller('assessmentSuccess', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.closeTab = function () {
            window.top.close();
        };
  }
]);
/* Assessment Not Success Controller */
myApp.controller('assessmentNotSuccess', [
  '$scope'
  , 'fileUpload'
  , '$http'
  , '$filter'
  , '$window'
  , function ($scope, fileUpload, $http, $filter, $window) {
        $scope.closeTab = function () {
            window.top.close();
        };
  }
]);