var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var axios = require('axios'); 
var port = process.env.PORT || process.env.VCAP_APP_PORT || '8080';
var username = 'org1';
var password = 'sHvN1FwNUf2LrQnALU8CBN4_HS2WCZ1OAh3MOIR4IJc5wg8jWP9V-gACoiNFjQJB';
var auth = "Basic " + new Buffer(username + ":" + password).toString("base64");
var app = express();
var headers = {headers : { 'Authorization': auth } };
var body = { 'peer_names': [ 'org1-peer1' ] };
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use('/', express.static(__dirname + '/'));

// viewed at http://localhost:8080
app.get('/', function(req, res) {
    console.log("Open blockData.html page");
    res.sendFile(path.join(__dirname + '/Explorer.html'));
});

app.post('/blockChainData', function(req, res) {
	var url = 'https://blockchain-starter.ng.bluemix.net/api/v1/networks/n86b2e7d346474627a9fe5f2cf562cc28/channels/defaultchannel';
	getNumberOfBlocks(url, body, headers).then(function(data) {
		var currentBlockNumber = data.response;
		var channelData = data.data;
		if(data.success){
			var blockurl = 'https://blockchain-starter.ng.bluemix.net/api/v1/networks/n86b2e7d346474627a9fe5f2cf562cc28/channels/defaultchannel/blocks/'+currentBlockNumber;
			getBlockDetails(blockurl, body, headers).then(function(data) {
				if(data.success){
					res.json ({success : true, message:"Success", channelData: channelData, current_block_data: data.response, responseCode: 200});
				}else{
					res.json ({success : false, message:"Issue fetching current block data"});
				}
			})
		}else{
			res.json ({success : false, message:"Issue fetching number of blocks"});
		}
	})
});

app.post('/blockData', function(req, res) {
    var blockNo = req.body.blockNo;
	var url = 'https://blockchain-starter.ng.bluemix.net/api/v1/networks/n86b2e7d346474627a9fe5f2cf562cc28/channels/defaultchannel/blocks/'+blockNo;
	getBlockDetails(url, body, headers).then(function(data) {
	if(data.success){
		res.json ({success : true, message:"Success", current_block_data: data.response, responseCode: 200});
	}else
		res.json ({success : false, message:"Issue fetching consignment details for the user"});
	})
});

app.post('/txnData', function(req, res) {	
    var txnNo = req.body.txnNo;
	var url = 'http://ec2-52-206-196-6.compute-1.amazonaws.com:3001/api/system/historian/'+txnNo;
	getTxnClass(url, body, headers).then(function(data) {
		var txnClass = data.classType;
		if(data.success && (txnClass == "AddAssignee" || txnClass == "AddLandRecord" || txnClass == "AddOwner" || txnClass == "UpdateLandDetails")){
			var dataurl = 'http://ec2-52-206-196-6.compute-1.amazonaws.com:3001/api/org.bhoomi.landrecords.' + txnClass + '?filter[where][transactionId]=' + txnNo;
			getTxnDetails(dataurl, headers).then(function(data) {
				if(data.success){
					res.json ({success : true, message:"Success", txn_class: txnClass, txnData: data.response, responseCode: 200});
				}else{
					res.json ({success : false, message:"Issue fetching current block data"});
				}
			})
		}else{
			res.json ({success : false, message:"Issue fetching number of blocks", txn_class: txnClass});
		}
	})
});

var getNumberOfBlocks = async (url, body, headers) => {
	try{
		var blocks = await axios.post(url, body, headers);
		var lastBlock = (blocks.data.peer['org1-peer1']).height.low - 1;
		console.log("Data fetched succesfully");
		return ({success : true, message:"Data fetched succesfully", response:lastBlock, data: blocks.data});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var getBlockDetails = async (url, body, headers) => {
	try{
		var blockData = await axios.post(url, body, headers);
		console.log("Data fetched succesfully");
		return ({success : true, message:"Data fetched succesfully", response:blockData.data});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var getTxnDetails = async (url, headers) => {
	try{
		var txnData = await axios.get(url, headers);
		console.log("Data fetched succesfully");
		return ({success : true, message:"Data fetched succesfully", response:txnData.data});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var getTxnClass = async (url, headers) => {
	try{
		var txnData = await axios.get(url, headers);
		var txnClass = txnData.data.transactionType;
		txnClass = txnClass.substring(txnClass.lastIndexOf(".") + 1);
		console.log("Data fetched succesfully");
		return ({success : true, message:"Data fetched succesfully", classType:txnClass});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

app.listen(port);