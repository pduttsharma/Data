var app = angular.module('myApp', []);
app.controller('blockData', function($scope, $http) {

    //Intial Page Load Will Show Current Block Data
    $scope.initialLoad = function() {
        $scope.owner = false;
        $scope.property = false;
        $scope.network = false;
        $scope.back = false;
        $scope.forward = false;
        $('#loading').show();
        $http({
            method: 'POST',
            url: '/blockChainData'
        }).then(function successCallback(response) {
            $('#loading').hide();
            $scope.forward = true;
            console.log(response);
            var currentBlockNo = response.data.channelData.peer['org1-peer1'];
            currentBlockNo = currentBlockNo.height.low;
            $scope.current_block_no = currentBlockNo;
            $scope.total_blocks = currentBlockNo;
            var msg = {
                aadharNo: "aadhar number",
                transactionId: "Txn Id : ",
                pid: "pid",
                colon: " : ",
                currentBlock: "BLOCK # ",
                blockNo: $scope.current_block_no
            }
            $scope.msg = msg;
            var txnData = response.data.current_block_data.parsed.txs;
            if (txnData.length > 0) {
                for (var i = 0; i < txnData.length; i++) {
                    var txnId = txnData[i].tx_id;
                    var channel_update = txnData[i].channel_update;
                    if (channel_update) {
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                    } else {
                        console.log(txnData[i].write_set.length);
                        if (txnData[i].write_set.length > 0) {
                            for (var m = 0; m < txnData[i].write_set.length; m++) {
                                var write_set = txnData[i].write_set[m];
                                var value = JSON.parse(write_set.value);
                                if(value['$class']){
                                    var txn_class = value['$class'];
                                    txn_class = txn_class.substring(txn_class.lastIndexOf(".") + 1);
                                    if (txn_class == "UpdateLandDetails" && value['landrecord']) {
                                        $scope.owner = true;
                                        $scope.property = true;
                                        var pid = value.landrecord;
                                        pid = pid.substring(pid.lastIndexOf("#") + 1);
                                        var landDetails = {
                                            pid: pid,
                                            txnId: txnId,
                                            msg: "Land record details updated with "
                                        }
                                        $scope.currentLandDetails = landDetails;

                                        var aadharNo = value.newOwner;
                                        aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                                        var ownerDetails = {
                                            aadharNo: aadharNo,
                                            txnId: txnId,
                                            msg: "Owner updated to this land with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    } else if (txn_class == "AddOwner" && value['owner']) {
                                        $scope.owner = true;
                                        var ownerDetails = {
                                            aadharNo: value.owner.aadharNo,
                                            txnId: txnId,
                                            msg: "Owner added with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    } else if (txn_class == "AddLandRecord" && value['landrecord']) {
                                        $scope.peer = "org1-peer1";
                                        $scope.property = true;
                                        var landDetails = {
                                            pid: value.landrecord.pid,
                                            txnId: txnId,
                                            msg: "Land record inserted with "
                                        }
                                        $scope.currentLandDetails = landDetails;
                                    } else if (txn_class == "AddAssignee" && value['owner']) {
                                        $scope.owner = true;
                                        var ownerDetails = {
                                            aadharNo: value.owner.aadharNo,
                                            txnId: txnId,
                                            msg: "Owner assigned to this land with "
                                        }
                                        $scope.currentOwnerDetails = ownerDetails;
                                    }
                                }
                            }
                        } else {
                            $scope.network = true;
                            var network = {
                                msg: "Network/Channel Update"
                            }
                            $scope.network = network;
                        }
                    }
                }if(!$scope.owner && !$scope.property){
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                  }
            } else {
                $scope.network = true;
                var network = {
                    msg: "Network/Channel Update"
                }
                $scope.network = network;
            }
        });
    }

    // On Click Of Back Arrow Will Show Previous Block Data
    $scope.Back = function() {
        $scope.owner = false;
        $scope.property = false;
        $scope.network = false;
        $scope.back = false;
        $scope.forward = false;
        $('#loading').show();
        $scope.current_block_no = ($scope.current_block_no - 1);
        if ($scope.current_block_no >= 0) {
            var blockNo = {
                blockNo: $scope.current_block_no - 1
            }
            $http({
                method: 'POST',
                url: '/blockData',
                data: blockNo
            }).then(function successCallback(response) {
                $('#loading').hide();
                if ($scope.current_block_no <= 1) {
                    $scope.back = true;
                }
                var msg = {
                    aadharNo: "aadhar number",
                    transactionId: "Txn Id : ",
                    pid: "pid",
                    colon: " : ",
                    currentBlock: "BLOCK # ",
                    blockNo: $scope.current_block_no
                }
                $scope.msg = msg;
                console.log(response);
                var txnData = response.data.current_block_data.parsed.txs;
                if (txnData.length > 0) {
                    for (var i = 0; i < txnData.length; i++) {
                        var txnId = txnData[i].tx_id;
                        var channel_update = txnData[i].channel_update;
                        if (channel_update) {
                            $scope.network = true;
                            var network = {
                                msg: "Network/Channel Update"
                            }
                            $scope.network = network;
                        } else {
                            console.log(txnData[i].write_set.length);
                            if (txnData[i].write_set.length > 0) {
                                for (var m = 0; m < txnData[i].write_set.length; m++) {
                                    var write_set = txnData[i].write_set[m];
                                    var value = JSON.parse(write_set.value);
                                    if(value['$class']){
                                        var txn_class = value['$class'];
                                        txn_class = txn_class.substring(txn_class.lastIndexOf(".") + 1);
                                        if (txn_class == "UpdateLandDetails" && value['landrecord']) {
                                            $scope.owner = true;
                                            $scope.property = true;
                                            var pid = value.landrecord;
                                            pid = pid.substring(pid.lastIndexOf("#") + 1);
                                            var landDetails = {
                                                pid: pid,
                                                txnId: txnId,
                                                msg: "Land record details updated with "
                                            }
                                            $scope.currentLandDetails = landDetails;

                                            var aadharNo = value.newOwner;
                                            aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                                            var ownerDetails = {
                                                aadharNo: aadharNo,
                                                txnId: txnId,
                                                msg: "Owner updated to this land with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        } else if (txn_class == "AddOwner" && value['owner']) {
                                            $scope.owner = true;
                                            var ownerDetails = {
                                                aadharNo: value.owner.aadharNo,
                                                txnId: txnId,
                                                msg: "Owner added with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        } else if (txn_class == "AddLandRecord" && value['landrecord']) {
                                            $scope.property = true;
                                            var landDetails = {
                                                pid: value.landrecord.pid,
                                                txnId: txnId,
                                                msg: "Land record inserted with "
                                            }
                                            $scope.currentLandDetails = landDetails;
                                        } else if (txn_class == "AddAssignee" && value['owner']) {
                                            $scope.owner = true;
                                            var ownerDetails = {
                                                aadharNo: value.owner.aadharNo,
                                                txnId: txnId,
                                                msg: "Owner assigned to this land with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        }
                                    }
                                }

                            } else {
                                $scope.network = true;
                                var network = {
                                    msg: "Network/Channel Update"
                                }
                                $scope.network = network;
                            }
                        }
                    }if(!$scope.owner && !$scope.property){
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                  }
                } else {
                    $scope.network = true;
                    var network = {
                        msg: "Network/Channel Update"
                    }
                    $scope.network = network;
                }
            });
        }
    }

    // On Click Will Show Data Of Block Added After This Block(if any)
    $scope.Forward = function() {
        $scope.owner = false;
        $scope.property = false;
        $scope.network = false;
        $scope.back = false;
        $scope.forward = false;
        $('#loading').show();
        $scope.current_block_no = ($scope.current_block_no + 1);
        if ($scope.current_block_no <= $scope.total_blocks) {
            var blockNo = {
                blockNo: $scope.current_block_no - 1
            }
            $http({
                method: 'POST',
                url: '/blockData',
                data: blockNo
            }).then(function successCallback(response) {
                $('#loading').hide();
                if ($scope.current_block_no >= $scope.total_blocks) {
                    $scope.forward = true;
                }
                var msg = {
                    aadharNo: "aadhar number",
                    transactionId: "Txn Id : ",
                    pid: "pid",
                    colon: " : ",
                    currentBlock: "BLOCK # ",
                    blockNo: $scope.current_block_no
                }
                $scope.msg = msg;
                console.log(response);
                var txnData = response.data.current_block_data.parsed.txs;
                if (txnData.length > 0) {
                    for (var i = 0; i < txnData.length; i++) {
                        var txnId = txnData[i].tx_id;
                        var channel_update = txnData[i].channel_update;
                        if (channel_update) {
                            $scope.network = true;
                            var network = {
                                msg: "Network/Channel Update"
                            }
                            $scope.network = network;
                        } else {
                            console.log(txnData[i].write_set.length);
                            if (txnData[i].write_set.length > 0) {
                                for (var m = 0; m < txnData[i].write_set.length; m++) {
                                    var write_set = txnData[i].write_set[m];
                                    var value = JSON.parse(write_set.value);
                                    if(value['$class']){
                                        var txn_class = value['$class'];
                                        txn_class = txn_class.substring(txn_class.lastIndexOf(".") + 1);
                                        if (txn_class == "UpdateLandDetails" && value['landrecord']) {
                                            $scope.owner = true;
                                            $scope.property = true;
                                            var pid = value.landrecord;
                                            pid = pid.substring(pid.lastIndexOf("#") + 1);
                                            var landDetails = {
                                                pid: pid,
                                                txnId: txnId,
                                                msg: "Land record details updated with "
                                            }
                                            $scope.currentLandDetails = landDetails;

                                            var aadharNo = value.newOwner;
                                            aadharNo = aadharNo.substring(aadharNo.lastIndexOf("#") + 1);
                                            var ownerDetails = {
                                                aadharNo: aadharNo,
                                                txnId: txnId,
                                                msg: "Owner updated to this land with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        } else if (txn_class == "AddOwner" && value['owner']) {
                                            $scope.owner = true;
                                            var ownerDetails = {
                                                aadharNo: value.owner.aadharNo,
                                                txnId: txnId,
                                                msg: "Owner added with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        } else if (txn_class == "AddLandRecord" && value['landrecord']) {
                                            $scope.property = true;
                                            var landDetails = {
                                                pid: value.landrecord.pid,
                                                txnId: txnId,
                                                msg: "Land record inserted with "
                                            }
                                            $scope.currentLandDetails = landDetails;
                                        } else if (txn_class == "AddAssignee" && value['owner']) {
                                            $scope.owner = true;
                                            var ownerDetails = {
                                                aadharNo: value.owner.aadharNo,
                                                txnId: txnId,
                                                msg: "Owner assigned to this land with "
                                            }
                                            $scope.currentOwnerDetails = ownerDetails;
                                        }
                                    }
                                }

                            } else {
                                $scope.network = true;
                                var network = {
                                    msg: "Network/Channel Update"
                                }
                                $scope.network = network;
                            }
                        }
                    }if(!$scope.owner && !$scope.property){
                        $scope.network = true;
                        var network = {
                            msg: "Network/Channel Update"
                        }
                        $scope.network = network;
                  }
                } else {
                    $scope.network = true;
                    var network = {
                        msg: "Network/Channel Update"
                    }
                    $scope.network = network;
                }
            });
        }
    }
});
