'use strict';
const shim = require('fabric-shim');
const util = require('util');

let Chaincode = class {
    // ================================================================================================================
   // The Init method is called when the Smart Contract 'digitalOnbaording' is instantiated by the blockchain network
  // ==================================================================================================================
  async Init(stub) {
    console.info('=========== Instantiated digitalOnbaording chaincode ===========');
    let payload = await initLedger(stub);
    return shim.success(payload);
  }

    // ================================================================================================================
   // The Invoke method is called as a result of an application request to run the Smart Contract 'digitalOnbaording'
  // ==================================================================================================================
  async Invoke(stub) {
    let ret = stub.getFunctionAndParameters();
    console.info(ret);

    let method = this[ret.fcn];
    try {
      let payload ;
        if(method == "initLedger"){
            payload = await initLedger(stub);           
        }else if(method == "queryStudentDetails"){
            payload = await queryStudentDetails(stub, args);
        }else if(method == "createStudentRecord"){
            payload = await createStudentRecord(stub, args);
        }else if(method == "updateUniveristyDetails"){
            payload = await updateUniveristyDetails(stub, args);
        }else if(method == "addDocument"){
            payload = await addDocument(stub, args);
        }else if(method == "updateDocument"){
            payload = await updateDocument(stub, args);
        }else if(method == "addUniversityDetails"){
            payload = await addUniveristyDetails(stub, args);
        }else if(method == "queryAllDetailsForAId"){
            payload = await queryAllDetailsForAId(stub, args);
        }else if(method == "queryAllRecords"){
            payload = await queryAllRecords(stub);
        }else{
            console.error('no function of name:' + ret.fcn + ' found');
            throw new Error('Received unknown function ' + ret.fcn + ' invocation');
        }
      return shim.success(payload);
    } catch (err) {
      console.log(err);
      return shim.error(err);
    }
  }

  // =================================================
 //  Query Ledger For Student Details with digitalId
// ===================================================
  async queryStudentDetails(stub, args) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting digitalId ex: 123456');
    }
    let digitalId = args[0];

    let studentAsBytes = await stub.getState(digitalId);
    if (!studentAsBytes || studentAsBytes.toString().length <= 0) {
      throw new Error(digitalId + ' does not exist: ');
    }
    console.log(studentAsBytes.toString());
    return studentAsBytes;
  }

  // ==========================================
 //  Query Ledger For All Txns with digitalId
// ============================================
  async queryAllDetailsForAId(stub, args) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting digitalId ex: 123456');
    }
    let digitalId = args[0];

    let studentAsBytes = await stub.getHistoryForKey(digitalId);
    if (!studentAsBytes || studentAsBytes.toString().length <= 0) {
      throw new Error(digitalId + ' does not exist: ');
    }
    console.log(studentAsBytes.toString());
    return studentAsBytes;
  }

  // =====================================
 //  Query Ledger For All Student Records
// =======================================
  async queryAllRecords(stub) {
    const startKey = '0';
    const endKey = '9999999999999999';

    const iterator = await stub.getStateByRange(startKey, endKey);

    const allResults = [];
    while (true) {
        const res = await iterator.next();

        if (res.value && res.value.value.toString()) {
            console.log(res.value.value.toString('utf8'));

            const Key = res.value.key;
            let Record;
            try {
                Record = JSON.parse(res.value.value.toString('utf8'));
            } catch (err) {
                console.log(err);
                Record = res.value.value.toString('utf8');
            }
            allResults.push({ Key, Record });
        }
        if (res.done) {
            console.log('end of data');
            await iterator.close();
            console.info(allResults);
            return JSON.stringify(allResults);
        }
    }
  }

  // =================================================
 //  Init Ledger To Instantiate Chaincode On Network
// ===================================================
  async initLedger(stub) {
    console.info('============= START : Initialize Ledger ===========');
    let documentInfo = [];
    let univeristyInfo = [];

    documentInfo.push({
      imageName: 'Id Proof',
      imageData: 'Test'
    });

    univeristyInfo.push({
        univeristyName : 'ABC',
        univeristyAddress : 'DEF',
        univeristyId : 'GHI',
        courseAppliedFor : 'JKL',
        appliedDegreeType : 'MNO',
        courseStartDate : 'PQR',
        courseEndDate : 'STU'
    });

    let studentDetails = {
        digitalId : '123',
        fullName : 'STU',
        emailId : 'STU',
        mobileNumber : 'STU',
        gender : 'M',
        address : 'STU',
        univeristyDetails : univeristyInfo,
        document : documentInfo,
        txnMsg : 'Init',
        createTimestamp : 'STU', 
        updateTimestamp : 'STU',
        lastUpdatedUserId : 'STU',
        lastUpdatedUserRole : 'STU'
    };
 
    let studentAsBytes = await stub.putState(studentDetails.digitalId, Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Initialize Ledger ===========');
    return studentAsBytes;
  }

  // =======================================
 //  Add Student Details Record Into Ledger
// =========================================
  async createStudentRecord(stub, args) {
    console.info('============= START : Create Student Records ===========');
    if (args.length != 13) {
      throw new Error('Incorrect number of arguments. Expecting 13');
    }

    let studentDetails = {
        digitalId : args[0],
        fullName : args[1],
        emailId : args[2],
        mobileNumber : args[3],
        gender : args[4],
        address : args[5],
        univeristyDetails : args[6],
        document : args[7],
        txnMsg : args[8],
        createTimestamp : args[9], 
        updateTimestamp : args[10],
        lastUpdatedUserId : args[11],
        lastUpdatedUserRole : args[12]
    };

    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Create Student Record ===========');
    return studentAsBytes;
  }

  // =====================================================
 //  Add Univeristy Details To Student Record Into Ledger
// =======================================================
  async addUniveristyDetails(stub, args) {
    console.info('============= START : Add New Univeristy ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let studentAsBytes = await stub.getState(args[0]);
    let studentDetails = JSON.parse(studentAsBytes);
    studentDetails.univeristyDetails.push(args[1]);

    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Add New Univeristy ===========');
    return studentAsBytes;
  }

  // ========================================================
 //  Update Univeristy Details In Student Record Into Ledger
// ==========================================================
  async updateUniveristyDetails(stub, args) {
    console.info('============= START : Update Univeristy Details ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let studentAsBytes = await stub.getState(args[0]);
    let studentDetails = JSON.parse(studentAsBytes);
    if(studentDetails.univeristyDetails.length > 0){
        for(let i =0; i<studentDetails.univeristyDetails.length ; i++){
            if(studentDetails.univeristyDetails[i].univeristyId == args[1].univeristyId){
                studentDetails.univeristyDetails[i].courseEndDate = args[1].courseEndDate;
            }
        }
    }

    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Update Univeristy Details ===========');
    return studentAsBytes;
  }

  // ================================================
 //  Add New Documents To Student Record Into Ledger
// ==================================================
  async addDocument(stub, args) {
    console.info('============= START : Add New Document ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let studentAsBytes = await stub.getState(args[0]);
    let studentDetails = JSON.parse(studentAsBytes);
    studentDetails.document.push(args[1]);

    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Add New Document ===========');
    return studentAsBytes;
  }


  // ==================================================================
 //  Update Previously Uploaded Document In Student Record Into Ledger
// ====================================================================
  async updateDocument(stub, args) {
    console.info('============= START : Update Previously Uploaded Document ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let studentAsBytes = await stub.getState(args[0]);
    let studentDetails = JSON.parse(studentAsBytes);
    if(studentDetails.document.length > 0){
        for(let i =0; i<studentDetails.document.length ; i++){
            if(studentDetails.document[i].imageName == args[1].imageName){
                studentDetails.document[i].imageData = args[1].imageData;
            }
        }
    }
    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Update Previously Uploaded Document ===========');
    return studentAsBytes;
  }
};

shim.start(new Chaincode());'use strict';
const shim = require('fabric-shim');
const util = require('util');

let Chaincode = class {
    // ================================================================================================================
   // The Init method is called when the Smart Contract 'digitalOnbaording' is instantiated by the blockchain network
  // ==================================================================================================================
  async Init(stub) {
    console.info('=========== Instantiated digitalOnbaording chaincode ===========');
    let payload = await initLedger(stub);
    return shim.success(payload);
  }

    // ================================================================================================================
   // The Invoke method is called as a result of an application request to run the Smart Contract 'digitalOnbaording'
  // ==================================================================================================================
  async Invoke(stub) {
    let ret = stub.getFunctionAndParameters();
    console.info(ret);

    let method = this[ret.fcn];
    try {
      let payload ;
        if(method == "initLedger"){
            payload = await initLedger(stub);           
        }else if(method == "queryStudentDetails"){
            payload = await queryStudentDetails(stub, args);
        }else if(method == "createStudentRecord"){
            payload = await createStudentRecord(stub, args);
        }else if(method == "updateUniveristyDetails"){
            payload = await updateUniveristyDetails(stub, args);
        }else if(method == "addDocument"){
            payload = await addDocument(stub, args);
        }else if(method == "updateDocument"){
            payload = await updateDocument(stub, args);
        }else if(method == "addUniversityDetails"){
            payload = await addUniveristyDetails(stub, args);
        }else if(method == "queryAllDetailsForAId"){
            payload = await queryAllDetailsForAId(stub, args);
        }else if(method == "queryAllRecords"){
            payload = await queryAllRecords(stub);
        }else{
            console.error('no function of name:' + ret.fcn + ' found');
            throw new Error('Received unknown function ' + ret.fcn + ' invocation');
        }
      return shim.success(payload);
    } catch (err) {
      console.log(err);
      return shim.error(err);
    }
  }

  // =================================================
 //  Query Ledger For Student Details with digitalId
// ===================================================
  async queryStudentDetails(stub, args) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting digitalId ex: 123456');
    }
    let digitalId = args[0];

    let studentAsBytes = await stub.getState(digitalId);
    if (!studentAsBytes || studentAsBytes.toString().length <= 0) {
      throw new Error(digitalId + ' does not exist: ');
    }
    console.log(studentAsBytes.toString());
    return studentAsBytes;
  }

  // ==========================================
 //  Query Ledger For All Txns with digitalId
// ============================================
  async queryAllDetailsForAId(stub, args) {
    if (args.length != 1) {
      throw new Error('Incorrect number of arguments. Expecting digitalId ex: 123456');
    }
    let digitalId = args[0];

    let studentAsBytes = await stub.getHistoryForKey(digitalId);
    if (!studentAsBytes || studentAsBytes.toString().length <= 0) {
      throw new Error(digitalId + ' does not exist: ');
    }
    console.log(studentAsBytes.toString());
    return studentAsBytes;
  }

  // =====================================
 //  Query Ledger For All Student Records
// =======================================
  async queryAllRecords(stub) {
    const startKey = '0';
    const endKey = '9999999999999999';

    const iterator = await stub.getStateByRange(startKey, endKey);

    const allResults = [];
    while (true) {
        const res = await iterator.next();

        if (res.value && res.value.value.toString()) {
            console.log(res.value.value.toString('utf8'));

            const Key = res.value.key;
            let Record;
            try {
                Record = JSON.parse(res.value.value.toString('utf8'));
            } catch (err) {
                console.log(err);
                Record = res.value.value.toString('utf8');
            }
            allResults.push({ Key, Record });
        }
        if (res.done) {
            console.log('end of data');
            await iterator.close();
            console.info(allResults);
            return JSON.stringify(allResults);
        }
    }
  }

  // =================================================
 //  Init Ledger To Instantiate Chaincode On Network
// ===================================================
  async initLedger(stub) {
    console.info('============= START : Initialize Ledger ===========');
    let documentInfo = [];
    let univeristyInfo = [];

    documentInfo.push({
      imageName: 'Id Proof',
      imageData: 'Test'
    });

    univeristyInfo.push({
        univeristyName : 'ABC',
        univeristyAddress : 'DEF',
        univeristyId : 'GHI',
        courseAppliedFor : 'JKL',
        appliedDegreeType : 'MNO',
        courseStartDate : 'PQR',
        courseEndDate : 'STU'
    });

    let studentDetails = {
        digitalId : '123',
        fullName : 'STU',
        emailId : 'STU',
        mobileNumber : 'STU',
        gender : 'M',
        address : 'STU',
        univeristyDetails : univeristyInfo,
        document : documentInfo,
        txnMsg : 'Init',
        createTimestamp : 'STU', 
        updateTimestamp : 'STU',
        lastUpdatedUserId : 'STU',
        lastUpdatedUserRole : 'STU'
    };
 
    let studentAsBytes = await stub.putState(studentDetails.digitalId, Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Initialize Ledger ===========');
    return studentAsBytes;
  }

  // =======================================
 //  Add Student Details Record Into Ledger
// =========================================
  async createStudentRecord(stub, args) {
    console.info('============= START : Create Student Records ===========');
    if (args.length != 13) {
      throw new Error('Incorrect number of arguments. Expecting 13');
    }

    let studentDetails = {
        digitalId : args[0],
        fullName : args[1],
        emailId : args[2],
        mobileNumber : args[3],
        gender : args[4],
        address : args[5],
        univeristyDetails : args[6],
        document : args[7],
        txnMsg : args[8],
        createTimestamp : args[9], 
        updateTimestamp : args[10],
        lastUpdatedUserId : args[11],
        lastUpdatedUserRole : args[12]
    };

    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Create Student Record ===========');
    return studentAsBytes;
  }

  // =====================================================
 //  Add Univeristy Details To Student Record Into Ledger
// =======================================================
  async addUniveristyDetails(stub, args) {
    console.info('============= START : Add New Univeristy ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let studentAsBytes = await stub.getState(args[0]);
    let studentDetails = JSON.parse(studentAsBytes);
    studentDetails.univeristyDetails.push(args[1]);

    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Add New Univeristy ===========');
    return studentAsBytes;
  }

  // ========================================================
 //  Update Univeristy Details In Student Record Into Ledger
// ==========================================================
  async updateUniveristyDetails(stub, args) {
    console.info('============= START : Update Univeristy Details ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let studentAsBytes = await stub.getState(args[0]);
    let studentDetails = JSON.parse(studentAsBytes);
    if(studentDetails.univeristyDetails.length > 0){
        for(let i =0; i<studentDetails.univeristyDetails.length ; i++){
            if(studentDetails.univeristyDetails[i].univeristyId == args[1].univeristyId){
                studentDetails.univeristyDetails[i].courseEndDate = args[1].courseEndDate;
            }
        }
    }

    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Update Univeristy Details ===========');
    return studentAsBytes;
  }

  // ================================================
 //  Add New Documents To Student Record Into Ledger
// ==================================================
  async addDocument(stub, args) {
    console.info('============= START : Add New Document ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let studentAsBytes = await stub.getState(args[0]);
    let studentDetails = JSON.parse(studentAsBytes);
    studentDetails.document.push(args[1]);

    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Add New Document ===========');
    return studentAsBytes;
  }


  // ==================================================================
 //  Update Previously Uploaded Document In Student Record Into Ledger
// ====================================================================
  async updateDocument(stub, args) {
    console.info('============= START : Update Previously Uploaded Document ===========');
    if (args.length != 2) {
      throw new Error('Incorrect number of arguments. Expecting 2');
    }

    let studentAsBytes = await stub.getState(args[0]);
    let studentDetails = JSON.parse(studentAsBytes);
    if(studentDetails.document.length > 0){
        for(let i =0; i<studentDetails.document.length ; i++){
            if(studentDetails.document[i].imageName == args[1].imageName){
                studentDetails.document[i].imageData = args[1].imageData;
            }
        }
    }
    let studentAsBytes = await stub.putState(args[0], Buffer.from(JSON.stringify(studentDetails)));
    console.info('============= END : Update Previously Uploaded Document ===========');
    return studentAsBytes;
  }
};

shim.start(new Chaincode());
