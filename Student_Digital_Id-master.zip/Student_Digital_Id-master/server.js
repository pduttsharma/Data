var express = require('express');
var path = require('path');
var fs = require('fs');
var bodyParser = require('body-parser');
var axios = require('axios');
var port = process.env.PORT || process.env.VCAP_APP_PORT || '8080';
var nano = require('nano')('http://ec2-52-206-196-6.compute-1.amazonaws.com:' + port);
var app = express();
var multer = require('multer');
var multiparty = require('multiparty');
var nodemailer = require('nodemailer');
var Cloudant = require('@cloudant/cloudant');
var path = require('path');
var swaggerUi = require('swagger-ui-express');
var swaggerJSDoc = require('swagger-jsdoc');
var smtpTransport = require('nodemailer-smtp-transport');
var {
    FileSystemWallet,
    Gateway
} = require('fabric-network');
var ccpPath = path.resolve(__dirname, 'connection.json');
var ccpJSON = fs.readFileSync(ccpPath, 'utf8');
var ccp = JSON.parse(ccpJSON);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
var upload = multer({
    dest: __dirname + '/upload'
});
var type = upload.single('file');
var options = {
    customCss: '.swagger-ui .topbar { display: none }'
};
var swaggerSpec = swaggerJSDoc({
    swaggerDefinition: {
        info: {
            description: 'Student ID API Catalog',
            version: '0.0.1',
            title: 'Student Id API',
            termsOfService: 'http://swagger.io/terms/',
            contact: {
                email: 'prem.dutt@cognizant.com'
            }
        },
        host: 'localhost:' + port,
        basePath: '/',
    },
    apis: ['server.js']
});
app.use('/', express.static(__dirname + '/'));
app.use('/', express.static(__dirname + '/images'));
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, options));
/* Cloudant credentials */
var cloudantUserName = '63ded591-69b0-479d-95ff-270c54c2260d-bluemix';
var cloudantPassword = '1a3df5bb6eb0ec4ef859f4123dd6f2e0f7aaf74dbde359da2642fbf75f1f8796';
var cloudant_url = 'https://' + cloudantUserName + ':' + cloudantPassword + '@' + cloudantUserName + '.cloudant.com'; // Set this to your own account
var cloudant = Cloudant(cloudant_url);
/* Cloudant db details */
var dbForLogin = cloudant.db.use('digital_id_login_details');
var dbForApplicantData = cloudant.db.use('digital_id_applicant_data');
var dbForApplicantDocs = cloudant.db.use('digital_id_applicant_documents');
/* Cloudant indexing */
var nationalId = {
    name: 'nationalId',
    type: 'json',
    index: {
        fields: ['nationalId']
    }
};
dbForApplicantData.index(nationalId, function (er, response) {
    if (er) console.log('Error creating index on national Id : ' + er);
    else console.log('Index creation result on national Id : ' + response.result);
});

var digitalIdStatus = {
    name: 'digitalIdStatus',
    type: 'json',
    index: {
        fields: ['digitalIdStatus']
    }
};
dbForApplicantData.index(digitalIdStatus, function (er, response) {
    if (er) console.log('Error creating index on digital id status : ' + er);
    else console.log('Index creation result on digital id status : ' + response.result);
});

var finalDiplomaRegistrationByCoordinator = {
    name: 'finalDiplomaRegistrationByCoordinator',
    type: 'json',
    index: {
        fields: ['finalDiplomaRegistrationByCoordinator']
    }
};
dbForApplicantData.index(finalDiplomaRegistrationByCoordinator, function (er, response) {
    if (er) console.log('Error creating index on final diploma registration by co-ordinator status : ' + er);
    else console.log('Index creation result on final diploma registration by co-ordinator status : ' + response.result);
});

var diplomaScoreUpdated = {
    name: 'diplomaScoreUpdated',
    type: 'json',
    index: {
        fields: ['diplomaScoreUpdated']
    }
};
dbForApplicantData.index(diplomaScoreUpdated, function (er, response) {
    if (er) console.log('Error creating index on diploma score updated status : ' + er);
    else console.log('Index creation result on diploma score updated status : ' + response.result);
});
/* Starting page when server starts */
app.get('/', function (req, res) {
    console.log('Open index.html page');
    res.sendFile(path.join(__dirname + '/index.html'));
});
/* Verify admin login data from DB */
app.post('/verifyLogin', function (req, res) {
    console.log('Inside Express api check for login');
    console.log('Received login details : ' + JSON.stringify(req.body));
    verifyCredentialsFromCloudant(req.body.username, req.body.password).then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'User name verified with password successfully !'
            });
        } else res.json({
            success: false,
            message: 'User name not found !'
        });
    });
});
/* Add digital Id data to DB */
app.post('/addDigitalDataToDB', type, function (req, res) {
    console.log('Inside Express api to insert data for applicant data to db as well as id proof document');
    var applicantData = JSON.parse(JSON.stringify(req.body.data));
    applicantData = JSON.parse(applicantData);
    fs.readFile(__dirname + '/upload/' + req.file.filename, function (err, response) {
        insertCloudantData(applicantData).then(function (data) {
            if (data.success) {
                insertDocInCloudant(response, req.file, applicantData.digitalIdInfo.idProof).then(function (data) {
                    if (data.success) {
                        fs.unlink(__dirname + '/upload/' + req.file.filename, function (err) {
                            if (!err) console.log('File deleted !');
                            else console.log('Issue deleting File');
                        });
                        res.json({
                            success: true,
                            message: 'Applicant data and document inserted successfully !'
                        });
                    } else res.json({
                        success: false,
                        message: 'Issue inserting applicant document !'
                    });
                });
            } else res.json({
                success: false,
                message: 'Issue inserting applicant data !'
            });
        });
    });
});
/* Add applicant image to document DB */
app.post('/addApplicantPicToDocumentDB', type, function (req, res) {
    console.log('Inside Express api to insert applicant pic as document');
    var applicantData = JSON.parse(JSON.stringify(req.body.data));
    applicantData = JSON.parse(applicantData);
    fs.readFile(__dirname + '/upload/' + req.file.filename, function (err, response) {
		insertDocInCloudant(response, req.file, applicantData.digitalIdInfo.applicantImg).then(function (data) {
			if (data.success) {
				fs.unlink(__dirname + '/upload/' + req.file.filename, function (err) {
					if (!err) console.log('File deleted !');
					else console.log('Issue deleting File');
				});
				res.json({
					success: true,
					message: 'Applicant data and document inserted successfully !'
				});
			} else res.json({
				success: false,
				message: 'Issue inserting applicant document !'
			});
		});
    });
});
/* Get all digital Ids with digital Id status as 'PENDING' */
app.get('/getDigitalIdRequests', function (req, res) {
    console.log('Inside Express api check to get all applicants details for digital Id');
    digitalIdWithPendingStatus().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result.docs
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
/* Get all digital Ids with Internal Assessment Score Evaluation By Awarding Body */
app.get('/getInternalAssessmentScoreEvaluationByAwardingBody', function (req, res) {
    console.log('Inside Express api check to get all applicants details for digital Id for internal assessment score evaluation by awarding body');
    digitalIdForInternalAssessmentScoreByAwardingBody().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
/* Get all digital Ids with final diploma registration by co-ordinator status as 'APPROVED' */
app.get('/getDiplomaRegistrationIdRequestsForAwardingBody', function (req, res) {
    console.log('Inside Express api check to get all applicants details to with approved diploma registration id requests by co-ordinator');
    digitalIdWithDiplomaIdRequestsForAwardingBody().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
/* Get all digital Ids with diploma score updated as 'PEDNING' */
app.get('/getDigitalIdToUpdateDiplomaScoreAndTranscript', function (req, res) {
    console.log('Inside Express api check to get all applicants details to with approved diploma registration id requests by co-ordinator');
    digitalIdWithDiplomaScoreNotUpdated().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
/* Get all digital Ids with digital Id status as 'APPROVED' to assign skill for internal assessment */
app.get('/getDigitalIdForSkillAssignmentForAssessment', function (req, res) {
    console.log('Inside Express api check to get all applicants details for digital Id with approved status to assign skill for internal assessment');
    digitalIdToAssignSkillForAssessment().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
/* Get all digital Ids with digital Id status as 'APPROVED' to evaluate the score for the internal assessment  */
app.get('/getDigitalIdForInternalAssessmentScore', function (req, res) {
    console.log('Inside Express api check to get all applicants details for digital Id with approved status to assign skill for internal assessment');
    digitalIdToEvaluateScoreForInternalAssessment().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
/* Get all digital Ids with digital Id status as 'APPROVED' and final diploma registration by coordinator status as 'PENDING'  */
app.get('/getDiplomaRegistrationIdRequestsForCoordinator', function (req, res) {
    console.log('Inside Express api check to get all applicants details for digital Id with approved status and final diploma registration by coordinator status as pending');
    digitalIdDiplomaRegistrationRequestsForCoordinator().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
/* Add final degree transcript related to digital Id to DB */
app.post('/addFinalDegreeTranscript', type, function (req, res) {
    console.log('Inside Express api to insert data for applicant');
    var applicantData = JSON.parse(JSON.stringify(req.body.data));
    applicantData = JSON.parse(applicantData);
    fs.readFile(__dirname + '/upload/' + req.file.filename, function (err, response) {
        updateCloudantData(applicantData, 'addSemesterDetails', 'university').then(function (data) {
            if (data.success) {
                insertDocInCloudant(response, req.file, documentDetails).then(function (data) {
                    if (data.success) {
                        fs.unlink(__dirname + '/upload/' + req.file.filename, function (err) {
                            if (!err) console.log('File deleted !');
                            else console.log('Issue deleting File');
                        });
                        res.json({
                            success: true,
                            message: 'Applicant data and document inserted successfully !'
                        });
                    } else res.json({
                        success: false,
                        message: 'Issue inserting applicant document !'
                    });
                });
            } else res.json({
                success: false,
                message: 'Issue inserting applicant data !'
            });
        });
    });
});
/* Get all digital Ids with final diploma registration by co-ordinator status as 'PENDING' */
app.get('/getUniversityPublishDetails', function (req, res) {
    console.log('Inside Express api check to get all applicants details for course complete as false');
    digitalIdWithPendingCourseCompletionStatus().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});

/* Get all digital Ids with university application status as 'PENDING' */
app.get('/getUniversityApplicantRequests', function (req, res) {
    console.log('Inside Express api check to get all applicants details for university applications');
    digitalIdWithPendingUniversityAdmissionStatus().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get selected _id details from DB
app.post('/getDigitalIdDataFromCloudant', function (req, res) {
    console.log('Inside Express api check to get digital Id data : ' + req.body._id);
    getDigitalIdDataFromCloudant(req.body._id).then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Applicant data found successfully ! ',
                result: data.response.docs
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get selected _id details from DB
app.post('/getDigitalIdData', function (req, res) {
    console.log(req.body);
    console.log('Inside Express api check to get digital Id data : ' + req.body._id);
    getDigitalIdData(req.body._id).then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Applicant data found successfully ! ',
                result: data.response.docs,
                txnIds: data.txnIds
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Update digital Id applicant details to DB
app.post('/updateDigitalIdData', function (req, res) {
    console.log('Inside Express api check to update digital Id data ! ');
    var applicantData = JSON.parse(JSON.stringify(req.body.data));
    var technicalSkills = [{
        skillset: 'Computer Science',
        answers: 'a,d,c,c,a',
        assignmentCode: '5cc4477f7ed4f'
    }, {
        skillset: 'Mathematics',
        answers: 'a,b,b,c,a',
        assignmentCode: '5cc4478a451c0'
    }];
    if (req.body.chaincodeFunction === 'addSkillSet' && req.body.user === 'applicant') {
        for (var i = 0; i < applicantData.digitalIdInfo.internalAssessmentDetails.length; i++) {
            if (applicantData.digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId === applicantData.internalAssessmentRegistrationId) {
                var selectedSkillSet = applicantData.digitalIdInfo.internalAssessmentDetails[i].selectedSkill;
                for (var j = 0; j < technicalSkills.length; j++) {
                    if (technicalSkills[j].skillset === selectedSkillSet) {
                        applicantData.digitalIdInfo.internalAssessmentDetails[i].assessmentCorrectAnswer = technicalSkills[j].answers;
                        applicantData.digitalIdInfo.internalAssessmentDetails[i].assessmentCode = technicalSkills[j].assignmentCode;
                    }
                }
            }
        }
    }
    updateCloudantData(applicantData, req.body.chaincodeFunction, req.body.user).then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Applicant data updated successfully ! ',
                result: data.response
            });
        } else res.json({
            success: false,
            message: 'Applicant data updation issue !'
        });
    });
});
// Get registration id from digital Id applicant details from DB
app.post('/getRegistrationId', function (req, res) {
    console.log('Inside Express api check to update digital Id data ! ');
    getDigitalIdData(req.body._id).then(function (data) {
        if (data.success && data.response.docs.length > 0) {
            var assessmentDetails = data.response.docs[0].digitalIdInfo.internalAssessmentDetails;
            var registrationId = "";
            for (var i = 0; i < assessmentDetails.length; i++) {
                if (assessmentDetails[i].assessmentUserAnswer === '' && assessmentDetails[i].assessmentScore === '') {
                    registrationId = assessmentDetails[i].registrationId;
                }
            }
            res.json({
                success: true,
                message: 'Applicant data found successfully ! ',
                result: registrationId
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Add assessment details to digital Id applicant to DB
app.post('/submitAssessmentData', function (req, res) {
    console.log('Inside Express api check to update digital Id data ! ');
    var name = Date.now();
    getDigitalIdData(req.body.digitalId).then(function (data) {
        if (data.success) {
            var applicantData = data.response.docs[0];
            var assessmentDetails = applicantData.digitalIdInfo.internalAssessmentDetails;
            for (var i = 0; i < assessmentDetails.length; i++) {
                if (assessmentDetails[i].internalAssessmentRegistrationId === req.body.internalAssessmentRegistrationId && assessmentDetails[i].assessmentUserAnswer === '') {
                    assessmentDetails[i].assessmentUserAnswer = req.body.answer.toString();
                    applicantData.digitalIdInfo.assessmentDetails = assessmentDetails;
                    updateCloudantData(applicantData, req.body.chaincodeFunction, req.body.user).then(function (data) {
                        if (data.success) {
                            res.json({
                                success: true,
                                message: 'Applicant data updated successfully !'
                            });
                        } else res.json({
                            success: false,
                            message: 'Applicant data updation issue !'
                        });
                    });
                } else {
                    res.json({
                        success: false,
                        message: 'You cannot submit again as you have already submitted your answers, please wait for your transcript !'
                    });
                }
            }
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get selected _id details from Block Chain
app.post('/getDataFromBlockChain', function (req, res) {
    console.log('Inside Express api check to get digital Id data : ' + req.body._id);
    getDataFromLedger(req.body._id).then(function (data) {
        if (data.success) res.json({
            success: true,
            message: 'Data fetched successfully !',
            response: data
        });
        else res.json({
            success: false,
            message: 'Data fetching issue from ledger !'
        });
    });
});
//Get explorer on load data
app.post('/explorerLoadData', function (req, res) {
    console.log('Inside express api to get on load data for explorer');
    getChannelData().then(function (data) {
        if (data.success) res.json({
            success: true,
            message: 'Data fetched successfully !',
            response: data
        });
        else res.json({
            success: false,
            message: 'Data fetching issue from swagger-ui !'
        });
    });
});
//Get explorer on load data
app.post('/explorerBlockData', function (req, res) {
    console.log('Inside express api to get on selected block data for explorer');
    getBlockData(req.body.channelHash, req.body.blockNo).then(function (data) {
        if (data.success) res.json({
            success: true,
            message: 'Data fetched successfully !',
            response: data
        });
        else res.json({
            success: false,
            message: 'Data fetching issue from swagger-ui !'
        });
    });
});
//Get explorer on load data
app.post('/explorerTxnData', function (req, res) {
    console.log('Inside express api to get on txn data for explorer');
    getTxnData(req.body.channelHash, req.body.txnId).then(function (data) {
        if (data.success) res.json({
            success: true,
            message: 'Data fetched successfully !',
            response: data
        });
        else res.json({
            success: false,
            message: 'Data fetching issue from swagger-ui !'
        });
    });
});
//Fetch specific digitalId record from cloudant DB
var getDataFromLedger = async (digitalId) => {
    try {
        var allTxnsForId = await query('mychannel', 'digitalId', 'queryAllDetailsForADigitalId', digitalId, 'university');
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log('Applicant data found successfully ! ');
        return ({
            success: true,
            message: 'Applicant data found successfully ! ',
            digitalIdData: digitalIdData,
            txnIds: allTxnsForId
        });
    } catch (err) {
        console.log('Applicant data not present/DB issue ! ' + err);
        return ({
            success: false,
            message: 'Applicant data not present/DB issue !'
        });
    }
}
//Fetch specific digitalId record from cloudant DB
var getDigitalIdData = async (digitalId) => {
    console.log(digitalId);
    try {
        var response = await dbForApplicantData.find({
            selector: {
                _id: digitalId
            }
        });
        console.log('Data from cloudant :' + response);
        var allTxnsForId = await query('mychannel', 'digitalId', 'queryAllDetailsForADigitalId', digitalId, 'university');
        console.log('Data from blockchain :' + allTxnsForId);
        console.log('Applicant data found successfully ! ');
        return ({
            success: true,
            message: 'Applicant data found successfully ! ',
            response: response,
            txnIds: allTxnsForId
        });
    } catch (err) {
        console.log('Applicant data not present/DB issue ! ' + err);
        return ({
            success: false,
            message: 'Applicant data not present/DB issue !'
        });
    }
}

//Fetch specific digitalId record from cloudant DB
var getDigitalIdDataFromCloudant = async (digitalId) => {
    try {
        var response = await dbForApplicantData.find({
            selector: {
                _id: digitalId
            }
        });
        console.log('Applicant data found successfully ! ');
        return ({
            success: true,
            message: 'Applicant data found successfully ! ',
            response: response,
        });
    } catch (err) {
        console.log('Applicant data not present/DB issue ! ' + err);
        return ({
            success: false,
            message: 'Applicant data not present/DB issue !'
        });
    }
}

// Update existence record in cloudant DB
var updateCloudantData = async (data, chaincodeFunction, user) => {
    var invokeResponse = '';
    try {
        if (data.digitalIdStatus === 'Approved' && user === 'university' && chaincodeFunction === 'addStudentRecord') {
            console.log("Student details inserted into ledger !");
            var url = 'http://localhost:8080/student_portal.html';
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'RE : Student Id Request';
            var mailBody = 'The student identity request has been approved. Your student id is :<b>' + data.digitalIdInfo.digitalId + '</b>.';
            invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        } else if (data.digitalIdStatus === 'Approved' && user === 'applicant' && chaincodeFunction === 'addSkillSet') {
            console.log("Sending assessment link to applicant !");
            var assessmentCode = '';
            for (var i = 0; i < data.digitalIdInfo.internalAssessmentDetails.length; i++) {
                if (data.internalAssessmentRegistrationId === data.digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId) 
                assessmentCode = data.digitalIdInfo.internalAssessmentDetails[i].assessmentCode;
            }
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'RE : Internal Assessment';
            var url = 'http://localhost:8080/' + assessmentCode + '.html';
            var mailBody = 'Please take the internal examination with registration id : <b>' + data.internalAssessmentRegistrationId + '</b> and try submitting the assessment asap for further processing.</br><a href="' + url + '">Click To Proceed</a>';
            invokeResponse = 'No need for ledger data insertion.';
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        } else if (data.digitalIdStatus === 'Approved' && user === 'university' && chaincodeFunction === 'addInternalAssessmentDetails') {
            var score = '';
            for (var i = 0; i < data.digitalIdInfo.internalAssessmentDetails.length; i++) {
                if (data.internalAssessmentRegistrationId === data.digitalIdInfo.internalAssessmentDetails[i].internalAssessmentRegistrationId)
                 score = data.digitalIdInfo.internalAssessmentDetails[i].assessmentScore;
            }
            console.log("Updating assessment details into ledger !");
            var url = 'http://ec2-52-206-196-6.compute-1.amazonaws.com:8080/student_portal.html';
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'RE : Internal Assessment Score';
            var mailBody = 'Internal evaluation for the assessment has been done and you have scored ' + score + '.';
            invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        } else if (data.digitalIdStatus === 'Approved' && user === 'university' && chaincodeFunction === 'addFinalDiplomaExamRegistrationId') {
            console.log("Adding final diaploma registration id into ledger !");
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'RE : Diploma Registration Id Generated';
            var mailBody = 'Your final exam registration id has been generated successfully as '+data.digitalIdInfo.diplomaDetails.diplomaRegistartionId+'. Exam details will be sent to you in a seperate mail.';
            invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        } else if (data.digitalIdStatus === 'Approved' && user === 'university' && chaincodeFunction === 'addFinalDiplomaScoreDetails') {
            console.log('Total Score'+data.digitalIdInfo.diplomaDetails.diplomaTotalScore);
            console.log("Adding transcript details and scores into ledger !");
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'RE: Transcript Details';
            var mailBody = 'Your final exam transcript details have been added with your profile. You can use this unique student id to apply to an university.';
            invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        }  else if (data.digitalIdStatus === 'Approved' && user === 'university' && chaincodeFunction === 'addUniveristyDetails') {
            console.log("Adding university details into ledger !");
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'RE : University Details';
            var mailBody = 'Your university application has been approved, further details will be communicated seperately to you in a mail.';
            invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        } 
        var response = await dbForApplicantData.insert(data);
        console.log('Applicant data updated successfully ! ');
        return ({
            success: true,
            message: 'Applicant data updated successfully ! ',
            response: invokeResponse
        });
    } catch (err) {
        console.log('Applicant data updation issue ! ' + err);
        return ({
            success: false,
            message: 'Applicant data updation issue !'
        });
    }
}
/* Fetch all digital Ids with pending digitalId status from cloudant DB */
var digitalIdWithPendingStatus = async () => {
    try {
        var response = await dbForApplicantData.find({
            selector: {
                digitalIdStatus: 'Pending'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            return ({
                success: true,
                message: 'Data found !',
                result: response
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
/* Fetch all digital Ids with approved digitalId status from cloudant DB for internal assessment score evaluation by awarding body */
var digitalIdForInternalAssessmentScoreByAwardingBody = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                digitalIdStatus: 'Approved'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.internalAssessmentDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.internalAssessmentDetails[j].assessmentScore != '' && response.docs[i].digitalIdInfo.internalAssessmentDetails[j].assessmentStatus != 'Approved') 
							finaldigitalIds.push(response.docs[i]);
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Fetch all digital Ids with pending skillSetStatus status from cloudant DB
var digitalIdWithPendingSkillSetStatus = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                skillSetStatus: 'Pending'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].universityAdmissionStatus === 'Pending' && response.docs[i].transcriptSent === 'Pending') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.assessmentDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.assessmentDetails[j].assessmentUserAnswer === '') finaldigitalIds.push(response.docs[i]);
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Fetch all digital Ids with pending transcript status from cloudant DB
var digitalIdWithPendingTranscriptStatus = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                transcriptSent: 'Pending'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].skillSetStatus === 'Approved' && response.docs[i].universityAdmissionStatus === 'Pending') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.assessmentDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.assessmentDetails[j].assessmentUserAnswer != '' && response.docs[i].digitalIdInfo.assessmentDetails[j].assessmentScore === '') finaldigitalIds.push(response.docs[i]);
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
/* Fetch all digital Ids with pending universityAdmission status from cloudant DB */
var digitalIdWithPendingUniversityAdmissionStatus = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                digitalIdStatus: 'Approved'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].transcriptSent === 'Approved')
					finaldigitalIds.push(response.docs[i]);
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
/* Fetch all digital Ids with pending final diploma registration by co-ordinator status from cloudant DB */
var digitalIdWithDiplomaIdRequestsForAwardingBody = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                finalDiplomaRegistrationByCoordinator: 'Completed'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].finalDiplomaRegistrationByApplicant === 'Completed') 
                    finaldigitalIds.push(response.docs[i]);
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
/* Fetch all digital Ids with pending diploma score status from cloudant DB */
var digitalIdWithDiplomaScoreNotUpdated = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                diplomaScoreUpdated: 'Pending'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].finalDiplomaRegistrationByCoordinator === 'Completed' && response.docs[i].digitalIdInfo.diplomaDetails.diplomaRegistartionId != '' ) 
                    finaldigitalIds.push(response.docs[i]);
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
/* Fetch all digital Ids with approved digital id status to assign skill for internal assessment from cloudant DB */
var digitalIdToAssignSkillForAssessment = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                digitalIdStatus: 'Approved'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].finalDiplomaRegistrationByApplicant === 'Pending' && response.docs[i].digitalIdInfo.internalAssessmentDetails.length > 0){
                    for(var j=0; j<response.docs[i].digitalIdInfo.internalAssessmentDetails.length; j++){
						if(response.docs[i].digitalIdInfo.internalAssessmentDetails[j].assessmentStatus == 'Completed')
							finaldigitalIds.push(response.docs[i]);
					}
				}else if(response.docs[i].digitalIdInfo.internalAssessmentDetails.length === 0){
                    finaldigitalIds.push(response.docs[i]);    
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
/* Fetch all digital Ids with approved digital id status to evaluate score of internal assessment */
var digitalIdToEvaluateScoreForInternalAssessment = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                digitalIdStatus: 'Approved'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].finalDiplomaRegistrationByApplicant === 'Pending' && response.docs[i].finalDiplomaRegistrationByCoordinator === 'Pending'){
                    for(var j=0; j<response.docs[i].digitalIdInfo.internalAssessmentDetails.length; j++){
						if(response.docs[i].digitalIdInfo.internalAssessmentDetails[j].assessmentStatus == 'Pending' && response.docs[i].digitalIdInfo.internalAssessmentDetails[j].assessmentUserAnswer != '')
							finaldigitalIds.push(response.docs[i]);
					}
				}
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
/* Fetch all digital Ids with approved digital id status and pending final diploma registration by co-ordinator status */
var digitalIdDiplomaRegistrationRequestsForCoordinator = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                digitalIdStatus: 'Approved'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].finalDiplomaRegistrationByCoordinator === 'Pending' && response.docs[i].finalDiplomaRegistrationByApplicant === 'Completed')
					finaldigitalIds.push(response.docs[i]);
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Fetch all digital Ids with pending course ccompletion status from cloudant DB
var digitalIdWithPendingCourseCompletionStatus = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                universityAdmissionStatus: 'Approved'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].skillSetStatus === 'Approved' && response.docs[i].transcriptSent === 'Approved') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.universityDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.universityDetails[j].courseStartDate != '' && response.docs[i].digitalIdInfo.universityDetails[j].courseEndDate === '' && !response.docs[i].digitalIdInfo.universityDetails[j].degreeCompleteStatus && response.docs[i].digitalIdInfo.universityDetails[j].semesterDetails.length === 4)
                            finaldigitalIds.push(response.docs[i]);
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Verify admin login credentials from cloudant DB
var verifyCredentialsFromCloudant = async (username, password) => {
    try {
        var response = await dbForLogin.get(username);
        console.log('Data found in db for the requested username');
        if (response.agentPassword === password) {
            console.log('User verification successful');
            return ({
                success: true,
                message: 'User Authentication Successful !'
            });
        } else {
            console.log('Invalid User name/Password ');
            return ({
                success: false,
                message: 'Invalid User name/Password !'
            });
        }
    } catch (err) {
        console.log('Data not found in db for the requested username !' + err);
        return ({
            success: false,
            message: 'Data not found in db for the requested username !'
        });
    }
}
/* Async Function To Insert data/record in cloudant DB */
var insertCloudantData = async (data) => {
    try {
        var response = await dbForApplicantData.find({
            selector: {
                nationalId: data.nationalId
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('National Id already exists in DB !');
            return ({
                success: false,
                message: 'National Id already exists in DB !'
            });
        } else {
            console.log('National Id does not exists in DB !');
            var data = await dbForApplicantData.insert(data);
            console.log('Applicant Data Inserted !');
            return ({
                success: true,
                message: 'Applicant Data Inserted Successfully !'
            });
        }
    } catch (err) {
        console.log('Issue fetching/inserting data from DB ! ' + err);
        return ({
            success: false,
            message: 'Issue fetching/inserting data from DB !'
        });
    }
}
/* Async Function To Insert Document in cloudant DB */
var insertDocInCloudant = async (data, file, docData) => {
    try {
        var response = await dbForApplicantDocs.insert(docData);
        console.log('Document related data inserted successfully !');
        var body = await dbForApplicantDocs.attachment.insert(response.id, file.originalname, data, file.mimetype, {
            rev: response.rev
        });
        console.log('Document inserted successfully !');
        return ({
            success: true,
            message: 'Document uploaded successfully !'
        });
    } catch (err) {
        console.log('Document related data insertion issue ! ' + err);
        return ({
            success: false,
            message: 'Document related data insertion issue !'
        });
    }
}
/* Async Function To Trigger mail to user/applicant */
var triggerEmail = async (receiverEmailId, subject, mailBody) => {
    var transporter = nodemailer.createTransport(smtpTransport({
        service: 'gmail',
        host: 'smtp.gmail.com',
        auth: {
            user: 'studentdigitalid@gmail.com',
            pass: 'ctsadmin'
        }
    }));
    const mailOptions = {
        from: 'studentdigitalid@gmail.com',
        to: receiverEmailId,
        subject: subject,
        html: mailBody
    };
    try {
        var response = await transporter.sendMail(mailOptions);
        console.log('Mail triggered successfully to applicant !');
        return ({
            success: true,
            message: 'Mail triggered successfully to applicant !'
        });
    } catch (err) {
        console.log('Issues triggering mail to applicant ! ' + err);
        return ({
            success: false,
            message: 'Issues triggering mail to applicant ! '
        });
    }
}
/* Async Function To Invoke Hyperledger Fabric Chaincode */
var invoke = async (chaincodeId, channelName, userDoingTxn, functionName, arguments) => {
    try {
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);
        const userExists = await wallet.exists(userDoingTxn);
        if (!userExists) {
            console.log('An identity for the user' + userDoingTxn + 'does not exist in the wallet');
            return ({
                success: false,
                message: 'User not registered ! '
            });
        }
        const gateway = new Gateway();
        await gateway.connect(ccp, {
            wallet,
            identity: userDoingTxn,
            discovery: {
                enabled: false
            }
        });
        const network = await gateway.getNetwork(channelName);
        const contract = network.getContract(chaincodeId);
        const result = await contract.submitTransaction(functionName, JSON.stringify(arguments));
        await gateway.disconnect();
        console.log(`Transaction has been evaluated, result is: ${result.toString()}`);
        return ({
            success: true,
            message: 'Txn submitted successfully ! ',
            response: result.toString()
        });
    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        return ({
            success: false,
            message: 'Failed to submit transaction ! '
        });
    }
}
/* Async Function To Query Hyperledger Fabric Chaincode */
var query = async (channelName, chaincodeId, functionName, arguments, userDoingTxn) => {
    try {
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);
        const userExists = await wallet.exists(userDoingTxn);
        if (!userExists) {
            console.log('An identity for the user' + userDoingTxn + 'does not exist in the wallet');
            return ({
                success: false,
                message: 'User not registered ! '
            });
        }
        const gateway = new Gateway();
        await gateway.connect(ccp, {
            wallet,
            identity: userDoingTxn,
            discovery: {
                enabled: false
            }
        });
        const network = await gateway.getNetwork(channelName);
        const contract = network.getContract(chaincodeId);
        const result = await contract.evaluateTransaction(functionName, arguments);
        console.log(`Transaction has been evaluated, result is: ${result.toString()}`);
        return ({
            success: true,
            message: 'Queried successfully ! ',
            response: result.toString()
        });
    } catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        return ({
            success: false,
            response: 'No applicant present with this digital id ! '
        });
    }
}
/* Async Function To Get explorer on-load basic data */
var getChannelData = async () => {
    try {
        var channelData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/channels/info');
        var channel_genesis_hash = channelData.data.channels[0].channel_genesis_hash;
        var blocks = channelData.data.channels[0].blocks;
        var currentBlockData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/block/' + channel_genesis_hash + '/' + (blocks - 1));
        var txnId = currentBlockData.data.transactions[0].payload.header.channel_header.tx_id;
        var txnData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/transaction/' + channel_genesis_hash + '/' + txnId);
        var chaincodeData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/chaincode/' + channel_genesis_hash);

        console.log("Data fetched succesfully");
        return ({
            success: true,
            message: "Data fetched succesfully",
            channelInfo: channelData.data,
            blockInfo: currentBlockData.data,
            txnInfo: txnData.data,
            chaincodeInfo: chaincodeData.data
        });
    } catch (error) {
        console.log("Basic explorer load data not fetched !");
        console.log(error);
        return ({
            success: false,
            message: "Basic explorer load data not fetched !"
        });
    }
}
/* Async Function To Get block specific data */
var getBlockData = async (channel_genesis_hash, blockNumber) => {
    try {
        var currentBlockData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/block/' + channel_genesis_hash + '/' + blockNumber);
        var txnId = currentBlockData.data.transactions[0].payload.header.channel_header.tx_id;
        var txnData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/transaction/' + channel_genesis_hash + '/' + txnId);
        console.log("Data fetched succesfully");
        return ({
            success: true,
            message: "Data fetched succesfully",
            blockInfo: currentBlockData.data,
            txnInfo: txnData.data
        });
    } catch (error) {
        console.log("Block data not fetched !");
        return ({
            success: false,
            message: "Block data not fetched !"
        });
    }
}
/* Async Function To Get block specific data */
var getTxnData = async (channel_genesis_hash, txnId) => {
    try {
        var currentTxnData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/block/' + channel_genesis_hash + '/' + txnId);
        console.log("Data fetched succesfully");
        return ({
            success: true,
            message: "Data fetched succesfully",
            txnInfo: currentTxnData.data
        });
    } catch (error) {
        console.log("Txn data not fetched !");
        return ({
            success: false,
            message: "Txn data not fetched !"
        });
    }
}
/**********************
 * SWAGGER UI DEFINITION
 **********************/
/**
 * @swagger
 * /studentId:
 *   get:
 *     tags:
 *     - student_id_data
 *     summary: Get applicant data on the basis of student Id
 *     description: Get applicant data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: studentId
 *         description: Fetch applicant data using unique student id
 *         in: query
 *         required: true
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the applicant details
 *         schema:
 *           type: object
 */
app.get('/studentId', function (req, res) {
    console.log(req.query);
    var digitalId = req.query.studentId;
    getDigitalIdDataSwagger(digitalId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                payload: JSON.parse(data.response)
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /studentId:
 *   post:
 *     tags:
 *     - student_id_data
 *     summary: Post applicant data by generating an unique id as studentId to blockchain
 *     description: Endpoint for posting a verified applicant data to the blockchain
 *     consumes:
 *       - multipart/form-data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fullName
 *         description: Applicant name
 *         in: query
 *         required: true
 *         type: string
 *       - name: nationalId
 *         description: Applicant national id
 *         in: query
 *         required: true
 *         type: string
 *       - name: emailId
 *         description: Applicant email id
 *         in: query
 *         required: true
 *         type: string
 *       - name: countrycode
 *         description: Applicant country code
 *         in: query
 *         required: true
 *         type: string
 *       - name: mobileNumber
 *         description: Applicant mobile number
 *         in: query
 *         required: true
 *         type: string
 *       - name: gender
 *         description: Applicant gender(Male/Female)
 *         in: query
 *         required: true
 *         type: string
 *       - name: address
 *         description: Applicant address
 *         in: query
 *         required: true
 *         type: string
 *       - name: dateOfBirth
 *         description: Applicant date of birth(dd/mm/yyyy)
 *         in: query
 *         required: true
 *         type: string
 *       - name: documentDetails
 *         description: Applicant id proof
 *         in: formData
 *         required: true
 *         type: file
 *     responses:
 *       200:
 *         description: A single JSON object containing the transaction id
 *         schema:
 *           type: object
 */
app.post('/digitalId', function (req, res) {
    var uniqueId = Date.now();
    var digitalIdData = {
        digitalId: uniqueId + '',
        fullName: req.query.fullName,
        emailId: req.query.emailId,
        countrycode: req.query.countrycode,
        ssn: req.query.ssn,
        mobileNumber: req.query.mobileNumber,
        gender: req.query.gender,
        address: req.query.address,
        createTimestamp: uniqueId,
        dateOfBirth: req.query.dateOfBirth,
        documentDetails: '',
        universityDetails: [],
        assessmentDetails: [],
        txnMsg: ""
    }
    var form = new multiparty.Form();
    var file = '';
    var imageType = '';
    form.parse(req, function (err, fields, files) {
        file = files.documentDetails[0];
        imageType = 'image/' + file.originalFilename.split('.')[1];
        fs.readFile(file.path, function (err, response) {
            var document = {
                _id: uniqueId + '-IdProof',
                docName: file.originalFilename,
                docType: "Identification Proof",
                digitalId: uniqueId + ''
            };
            digitalIdData.documentDetails = document;
            postDigitalIdData(response, file, digitalIdData, imageType).then(function (data) {
                if (data.success) {
                    res.json({
                        code: 200,
                        txn_Id: data.response,
                        digital_Id: digitalIdData.digitalId
                    })
                } else res.json({
                    code: 500,
                    message: data.message
                });
            });
        });
    });
});
/**
 * @swagger
 * /transcript:
 *   get:
 *     tags:
 *     - transcript_data
 *     summary: Get applicant transcript data on the basis of student Id and registration Id
 *     description: Get transcript data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: studentId
 *         description: Student id of the applicant
 *         in: query
 *         required: true
 *         type: string
 *       - name: registrationId
 *         description: Registration id for the transcript
 *         in: query
 *         required: false
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the transcript details of the applicant
 *         schema:
 *           type: object
 */
app.get('/transcript', function (req, res) {
    var digitalId = req.query.digitalId;
    var registrationId = req.query.registrationId;
    getTranscriptData(digitalId, registrationId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                payload: data.response
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /transcript:
 *   post:
 *     tags:
 *     - transcript_data
 *     summary: Add transcript data to already existing studentId to blockchain
 *     description: Endpoint for posting transcript data to a valid applicant with the mentioned student Id to the blockchain
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: studentId
 *         description: Applicant student id
 *         in: query
 *         required: true
 *         type: string
 *       - name: skillSet
 *         description: Applicant selected skill set(NODE_JS, JAVA, PYTHON or BIG_DATA)
 *         in: query
 *         required: true
 *         type: string
 *       - name: assessmentScore
 *         description: Applicant assessment score
 *         in: query
 *         required: true
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the transaction id
 *         schema:
 *           type: object
 */
app.post('/transcript', function (req, res) {
    var digitalId = req.query.digitalId;
    var uniqueId = Date.now();
    var assessmentDetails = {
        registrationId: uniqueId + '',
        assessmentUserAnswer: '',
        assessmentCorrectAnswer: '',
        assessmentScore: req.query.assessmentScore,
        digitalId: req.query.digitalId,
        assessmentCode: '',
        skillSet: req.query.skillSet,
        transcriptSent: 'Approved'
    }
    var technicalSkills = [{
        skillset: 'NODE_JS',
        answers: 'a,d,c,c,a',
        assignmentCode: '5cc4478a451c0'
    }, {
        skillset: 'JAVA',
        answers: 'a,b,b,c,a',
        assignmentCode: '5cc4477f7ed4f'
    }, {
        skillset: 'PYTHON',
        answers: 'b,d,b,d,c',
        assignmentCode: '5cc44761701c6'
    }, {
        skillset: 'BIG_DATA',
        answers: 'd,b,a,a,c',
        assignmentCode: '5cc44771dfca0'
    }];
    for (var i = 0; i < technicalSkills.length; i++) {
        if (technicalSkills[i].skillSet === assessmentDetails.skillSet) {
            assessmentDetails.assessmentCode = technicalSkills[i].assignmentCode;
            assessmentDetails.assessmentCorrectAnswer = technicalSkills[i].answers;
        }
    }
    postTranscriptData(assessmentDetails, digitalId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                txn_Id: data.response,
                registrationId: assessmentDetails.registrationId
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /university:
 *   get:
 *     tags:
 *     - university_data
 *     summary: Get applicant univeristy data on the basis of student Id
 *     description: Get transcript data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: studentId
 *         description: Student id of the applicant
 *         in: query
 *         required: true
 *         type: string
 *       - name: registrationId
 *         description: Registration id for the transcript
 *         in: query
 *         required: false
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the univeristy details of the applicant
 *         schema:
 *           type: object
 */
app.get('/university', function (req, res) {
    var digitalId = req.query.digitalId;
    var registrationId = req.query.registrationId;
    getUniversityData(digitalId, registrationId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                payload: data.response
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /university:
 *   post:
 *     tags:
 *     - university_data
 *     summary: Add university data to already existing studentId to blockchain
 *     description: Endpoint for posting university data to a valid applicant with the mentioned digital Id to the blockchain
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: studentId
 *         description: Applicant digital id
 *         in: query
 *         required: true
 *         type: string
 *       - name: universityName
 *         description: Applicant selected university name(University College London, University of Chicago, Imperial College London, Massachusetts Institute of Technology)
 *         in: query
 *         required: true
 *         type: string
 *       - name: courseAppliedFor
 *         description: Applicant selected course in university(Ancient History, Computer Science, Microservices)
 *         in: query
 *         required: true
 *         type: string
 *       - name: appliedDegreeType
 *         description: Applicant selected degree type in university(UG, PG)
 *         in: query
 *         required: true
 *         type: string
 *       - name: registrationId
 *         description: Applicant transcript registration id
 *         in: query
 *         required: true
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the transaction id
 *         schema:
 *           type: object
 */
app.post('/university', function (req, res) {
    var universityData = {
        universityName: req.query.universityName,
        universityAddress: '',
        universityId: '',
        courseAppliedFor: req.query.courseAppliedFor,
        appliedDegreeType: req.query.appliedDegreeType,
        courseStartDate: '',
        courseEndDate: '',
        degreeCompleteStatus: false,
        digitalId: req.query.digitalId,
        registrationId: req.query.registrationId,
        universityDocument: '',
        semesterDetails: []
    }
    var universityInfo = [{
        universityName: "University College London",
        universityAddress: "United Kingdom",
        universityId: "U-1"
    }, {
        universityName: "University of Chicago",
        universityAddress: "United States",
        universityId: "U-2"
    }, {
        universityName: "Imperial College London",
        universityAddress: "United Kingdom",
        universityId: "U-3"
    }, {
        universityName: "Massachusetts Institute of Technology",
        universityAddress: "United States",
        universityId: "U-4"
    }];
    for (var i = 0; i < universityInfo.length; i++) {
        if (universityInfo[i].universityName === universityData.universityName) {
            universityData.universityAddress = universityInfo[i].universityAddress;
            universityData.universityId = universityInfo[i].universityId;
            universityData.courseStartDate = Date.now() + '';
        }
    }
    postUniversityData(universityData, req.query.digitalId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                txn_Id: data.response
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**************************

* SWAGGER ASYNC FUNCTIONS

**************************/
var getDigitalIdDataSwagger = async (digitalId) => {
    console.log(digitalId);
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) return ({
            success: true,
            message: "Data fetched successfully",
            response: digitalIdData.response
        });
        else return ({
            success: false,
            message: response
        });
    } catch (error) {
        console.log("Applicant data not fetched !");
        return ({
            success: false,
            message: "Applicant data not fetched !"
        });
    }
}
var postDigitalIdData = async (bufferData, file, digitalIdData, imageType) => {
    try {
        var response = await dbForApplicantDocs.insert(digitalIdData.documentDetails);
        console.log('Document related data inserted successfully !');
        var body = await dbForApplicantDocs.attachment.insert(response.id, file.originalFilename, bufferData, imageType, {
            rev: response.rev
        });
        console.log('Document inserted successfully !');
        var insertData = await invoke('digitalId', 'mychannel', 'university', 'createStudentRecord', digitalIdData);
        console.log('Data inserted into blockchain succesfully !');
        var mail = await triggerEmail(digitalIdData.emailId, 'Reg: Digital Id Request', 'Your digital id request has been approved. Your digital id is :' + digitalIdData.digitalId);
        console.log('Mail sent succesfully to the applicant !')
        return ({
            success: true,
            response: insertData.response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
var getTranscriptData = async (digitalId, registrationId) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            var transcriptInfo = digitalIdInfo.assessmentDetails;
            var transcriptData = [];
            if (registrationId != undefined) {
                for (var i = 0; i < transcriptInfo.length; i++) {
                    if (transcriptInfo[i].registrationId === registrationId)
                        transcriptData.push(transcriptInfo[i]);
                }
                return ({
                    success: true,
                    message: "Data fetched successfully",
                    response: transcriptData
                });
            } else return ({
                success: true,
                message: "Data fetched successfully",
                response: transcriptInfo
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (error) {
        console.log("Applicant data not fetched !");
        return ({
            success: false,
            message: "Applicant data not fetched !"
        });
    }
}
var postTranscriptData = async (transcriptData, digitalId) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            digitalIdInfo.assessmentDetails.push(transcriptData);
            var insertData = await invoke('digitalId', 'mychannel', 'university', 'addAssessmentDetails', digitalIdInfo);
            console.log('Data inserted into blockchain succesfully !' + insertData);
            var mail = await triggerEmail(digitalIdInfo.emailId, 'Reg: Transcript Details', 'Your assessment details have been approved. Your registration id is :' + transcriptData.registrationId);
            console.log('Mail sent succesfully to the applicant !')
            return ({
                success: true,
                response: insertData.response
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
var getUniversityData = async (digitalId, registrationId) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            var universityInfo = digitalIdInfo.universityDetails;
            var universityData = [];
            if (registrationId != undefined) {
                for (var i = 0; i < universityInfo.length; i++) {
                    if (universityInfo[i].registrationId === registrationId) universityData.push(universityInfo[i]);
                }
                return ({
                    success: true,
                    message: "Data fetched successfully",
                    response: universityData
                });
            } else return ({
                success: true,
                message: "Data fetched successfully",
                response: universityInfo
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (error) {
        console.log("Applicant data not fetched !");
        return ({
            success: false,
            message: "Applicant data not fetched !"
        });
    }
}
var postUniversityData = async (universityData, digitalId) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            digitalIdInfo.universityDetails.push(universityData);
            var insertData = await invoke('digitalId', 'mychannel', 'university', 'addUniveristyDetails', digitalIdInfo);
            console.log('Data inserted into blockchain succesfully !' + insertData);
            var mail = await triggerEmail(digitalIdInfo.emailId, 'Reg: University Details', 'University details has been added against your profile as selected');
            console.log('Mail sent succesfully to the applicant !')
            return ({
                success: true,
                response: insertData.response
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
var postSemesterCerts = async (bufferData, file, digitalId, registrationId, semesterData, document, imageType) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            for (var i = 0; i < digitalIdInfo.universityDetails.length; i++) {
                if (digitalIdInfo.universityDetails[i].registrationId === registrationId) {
                    if (digitalIdInfo.universityDetails[i].semesterDetails.length >= 4) return ({
                        success: false,
                        message: 'All semester certificates have been already uploaded for the applicant !'
                    });
                    else if (digitalIdInfo.universityDetails[i].semesterDetails.length === 0) {
                        semesterData.semesterDoc = document;
                        digitalIdInfo.universityDetails[i].semesterDetails.push(semesterData);
                    } else {
                        for (var j = 0; j < digitalIdInfo.universityDetails[i].semesterDetails.length; j++) {
                            if (digitalIdInfo.universityDetails[i].semesterDetails[j].semesterNo === '1') {
                                semesterData.semesterNo = '2';
                                document._id = digitalId + '-SemesterCert-' + semesterData.semesterNo;
                                semesterData.semesterDoc = document;
                            } else if (digitalIdInfo.universityDetails[i].semesterDetails[j].semesterNo === '2') {
                                semesterData.semesterNo = '3';
                                document._id = digitalId + '-SemesterCert-' + semesterData.semesterNo;
                                semesterData.semesterDoc = document;
                            } else if (digitalIdInfo.universityDetails[i].semesterDetails[j].semesterNo === '3') {
                                semesterData.semesterNo = '4';
                                document._id = digitalId + '-SemesterCert-' + semesterData.semesterNo;
                                semesterData.semesterDoc = document;
                            }
                        }
                        digitalIdInfo.universityDetails[i].semesterDetails.push(semesterData);
                    }
                }
            }
            var response = await dbForApplicantDocs.insert(document);
            console.log('Document related data inserted successfully !');
            var body = await dbForApplicantDocs.attachment.insert(response.id, file.originalFilename, bufferData, imageType, {
                rev: response.rev
            });
            console.log('Document inserted successfully !');
            var insertData = await invoke('digitalId', 'mychannel', 'university', 'addSemesterDetails', digitalIdInfo);
            console.log('Data inserted into blockchain succesfully !');
            var mail = await triggerEmail(digitalIdInfo.emailId, 'Reg: Semester Certs Addition', 'Your semester certs have been updated with your profile.');
            console.log('Mail sent succesfully to the applicant !')
            return ({
                success: true,
                response: insertData.response
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
var postFinalDegreeEndCerts = async (bufferData, file, digitalId, registrationId, document, imageType) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            for (var i = 0; i < digitalIdInfo.universityDetails.length; i++) {
                if (digitalIdInfo.universityDetails[i].registrationId === registrationId) {
                    digitalIdInfo.universityDetails[i].courseEndDate = Date.now() + '';
                    digitalIdInfo.universityDetails[i].universityDocument = document;
                    digitalIdInfo.universityDetails[i].degreeCompleteStatus = true;
                }
            }
            var response = await dbForApplicantDocs.insert(document);
            console.log('Document related data inserted successfully !');
            var body = await dbForApplicantDocs.attachment.insert(response.id, file.originalFilename, bufferData, imageType, {
                rev: response.rev
            });
            console.log('Document inserted successfully !');
            var insertData = await invoke('digitalId', 'mychannel', 'university', 'addFinalDegreeDetails', digitalIdInfo);
            console.log('Data inserted into blockchain succesfully !');
            var mail = await triggerEmail(digitalIdInfo.emailId, 'Reg: Final Degree Cert Addition', 'Your final degree certificate has been updated with your profile.');
            console.log('Mail sent succesfully to the applicant !')
            return ({
                success: true,
                response: insertData.response
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
app.listen(port);
