/* Angular Module Definition */
var myApp = angular.module("myModule", ['ngTable']);

/* File Upload Directive */
myApp.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

/* File Upload Service */
myApp.service('fileUpload', ['$http', function ($http) {
    this.uploadFileAndFieldsToUrl = function (file, data, uploadUrl) {
        var fd = new FormData();
        fd.append('file', file);
        fd.append('data', JSON.stringify(data));
        $http({
            method: 'POST',
            url: uploadUrl,
            data: fd,
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined
            }
        }).then(function successCallback(response) {
            if (response.data.success == true && uploadUrl === '/addDigitalDataToDB') {
                window.location.href = '/digital_id_success.html';
            } else if (response.data.success == true && (uploadUrl === '/addCertsRelatedToDigitalIdToDB' || uploadUrl === '/addSemesterWiseCerts')) {
                window.location.href = '/university_admin.html';
            } else {
                alert(response.data.message);
            }
        });
    }
}]);

/* Main Portal Controller */
myApp.controller('mainPortal', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.studentPortal = function () {
        window.open('/student_portal.html', '_blank');
    }

    $scope.consortiumPortal = function () {
        window.open('/consortium_admin_login.html', '_blank');
    }

    $scope.skillAssessmentPortal = function () {
        window.open('/assessment_admin_login.html', '_blank');
    }

    $scope.universityPortal = function () {
        window.open('/university_admin_login.html', '_blank');
    }

    $scope.portFolioView = function () {
        window.open('/port_folio_view.html', '_blank');
    }

    $scope.studentExplorer = function () {
        window.open('/explorer.html', '_blank');
    }

}]);

/* Student Portal Controller */
myApp.controller('studentPortal', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.applyDigitalId = function () {
        window.location.href = '/apply_digital_id.html';
    }

    $scope.addSkillSets = function () {
        window.location.href = '/add_skill_sets.html';
    }

    $scope.applyUniversity = function () {
        window.location.href = '/apply_university.html';
    }

}]);

/* Apply For Digital Id Controller */
myApp.controller('applyDigitalId', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {
    $scope.isDisabled = false;

    var uniqueId = Date.now();

    $scope.Back = function () {
        $window.location.href = '/student_portal.html';
    }

    $scope.Logout = function () {
        window.close();
    }

    var document = {
        _id: uniqueId + '-IdProof',
        docName: "",
        docType: "Identification Proof",
        digitalId: uniqueId + ''
    }

    var digitalIdData = {
        digitalId: uniqueId + '',
        fullName: "",
        emailId: "",
        countrycode: "",
        ssn: "",
        mobileNumber: "",
        gender: "",
        address: "",
        createTimestamp: uniqueId,
        dateOfBirth: "",
        documentDetails: document,
        universityDetails: [],
        assessmentDetails: [],
        txnMsg: ""
    };

    var applicantData = {
        _id: uniqueId + '',
        digitalIdInfo: digitalIdData,
        registrationId: '',
        digitalIdStatus: 'Pending',
        universityAdmissionStatus: 'Pending',
        skillSetStatus: 'Pending',
        transcriptSent: 'Pending',
        ssn: "",
        message: "",
    };

    $scope.applicantData = applicantData;

    $scope.$watch('myFile', function (newFileObj) {
        if (newFileObj)
            $scope.filename = newFileObj.name;
    });

    $scope.genderTypes = ["Male", "Female"];

    $scope.submitDigitalIdData = function () {
        $scope.isDisabled = true;
        var file = $scope.myFile;
        $scope.applicantData.digitalIdInfo.documentDetails.docName = file.name;
        $scope.applicantData.ssn = $scope.applicantData.digitalIdInfo.ssn;
        $scope.applicantData.message = "Record inserted successfully in Cloudant DB.";
        var uploadUrl = "/addDigitalDataToDB";
        fileUpload.uploadFileAndFieldsToUrl(file, $scope.applicantData, uploadUrl);
    }
}]);


/* Apply For Skill Set Assessment Controller */
myApp.controller('addSkillSets', ['$scope', 'fileUpload', '$http', '$filter', '$window', '$sce', function ($scope, fileUpload, $http, $filter, $window, $sce) {
    $scope.isDisabled = false;

    $scope.skillSet = "";

    $scope.on = function () {
        document.getElementById("overlay").style.display = "block";
    }

    $scope.technicalSkills = ["NODE_JS", "JAVA", "PYTHON", "BIG_DATA"];

    $scope.off = function () {
        document.getElementById("overlay").style.display = "none";
    }

    $scope.Back = function () {
        $window.location.href = '/student_portal.html';
    }

    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.loadDigitalIdData = function () {
        var data = {
            _id: $scope.digitalId
        }

        $http({
            method: 'POST',
            url: '/getDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true && response.data.result[0].digitalIdStatus == 'Approved' && response.data.result[0].skillSetStatus == 'Pending') {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
                $scope.off();
            } else {
                alert("You have already applied for skill sets.");
                window.close();
            }
        });
    }

    $scope.updateDigitalIdData = function () {
        $scope.isDisabled = true;
        var uniqueId = Date.now();
        var assessmentDetails = {
            registrationId: uniqueId + '',
            assessmentUserAnswer: '',
            assessmentCorrectAnswer: '',
            assessmentScore: '',
            digitalId: $scope.digitalIdData.digitalIdInfo.digitalId,
            assessmentCode: '',
            skillSet: $scope.skillSet,
            transcriptSent: 'Pending'
        };
        var message = $scope.digitalIdData.message + " The applicant has added his skillsets successfully.";
        $scope.digitalIdData.message = message;
        $scope.digitalIdData.registrationId = assessmentDetails.registrationId;
        $scope.digitalIdData.digitalIdInfo.assessmentDetails.push(assessmentDetails);

        var data = {
            data: $scope.digitalIdData,
            chaincodeFunction: "addSkillSet",
            user: "applicant"
        }

        $http({
            method: 'POST',
            url: '/updateDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/skill_set_add_success.html';
            } else {
                alert(response.data.message);
            }
        });
    }

}]);


/* Apply For University Controller */
myApp.controller('applyUniversity', ['$scope', 'fileUpload', '$http', '$filter', '$window', '$sce', function ($scope, fileUpload, $http, $filter, $window, $sce) {
    $scope.isDisabled = false;

    $scope.selectedUniversityName = "";

    $scope.courses = ["Ancient History", "Computer Science", "Microservices"];

    $scope.degreeTypes = ["UG", "PG"];

    $scope.Back = function () {
        $window.location.href = '/student_portal.html';
    }

    $scope.on = function () {
        document.getElementById("overlay").style.display = "block";
    }

    $scope.off = function () {
        document.getElementById("overlay").style.display = "none";
    }

    $scope.changeUniversity = function (data) {
        $scope.selectedUniversityAddress = data.universityAddress;
        $scope.selectedUniversityId = data.universityId;
    }

    $scope.universityData = [{
        universityName: "University College London",
        universityAddress: "United Kingdom",
        universityId: "U-1"
 }, {
        universityName: "University of Chicago",
        universityAddress: "United States",
        universityId: "U-2"
 }, {
        universityName: "Imperial College London",
        universityAddress: "United Kingdom",
        universityId: "U-3"
 }, {
        universityName: " Massachusetts Institute of Technology",
        universityAddress: "United States",
        universityId: "U-4"
 }];

    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.loadDigitalIdData = function () {
        var data = {
            _id: $scope.digitalId
        }

        $http({
            method: 'POST',
            url: '/getDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true && response.data.result[0].digitalIdStatus == 'Approved' && response.data.result[0].skillSetStatus == 'Approved') {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                var assessmentDetails = $scope.digitalIdData.digitalIdInfo.assessmentDetails;
                for (var i = 0; i < assessmentDetails.length; i++) {
                    if (assessmentDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                        $scope.skillset = assessmentDetails[i].skillSet;
                        $scope.score = assessmentDetails[i].assessmentScore;
                    }
                }
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
                $scope.off();
            } else {
                alert(response.data.message);
                window.close();
            }
        });
    }

    $scope.addUniversityData = function () {
        $scope.isDisabled = true;
        var universityData = {
            universityName: $scope.selectedUniversityName.universityName,
            universityAddress: $scope.selectedUniversityAddress,
            universityId: $scope.selectedUniversityId,
            courseAppliedFor: $scope.selectedCourse,
            appliedDegreeType: $scope.selectedDegreeType,
            courseStartDate: '',
            courseEndDate: '',
            degreeCompleteStatus: false,
            digitalId: $scope.digitalIdData.digitalIdInfo.digitalId,
            registrationId: $scope.digitalIdData.registrationId,
            universityDocument: '',
            semesterDetails: []
        };
        var message = $scope.digitalIdData.message + " The applicant has added his university choices.";
        $scope.digitalIdData.message = message;
        $scope.digitalIdData.digitalIdInfo.universityDetails.push(universityData);

        var data = {
            data: $scope.digitalIdData,
            chaincodeFunction: "addUniversity",
            user: "applicant"
        }

        $http({
            method: 'POST',
            url: '/updateDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/university_success.html';
            } else {
                alert(response.data.message);
            }
        });
    }
}]);

/* Assessment Controller */
myApp.controller('assessment', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {
    $scope.isDisabled = false;

    $scope.on = function () {
        $('#myModal').modal('show');
        document.getElementById("overlay").style.display = "block";
    }

    $scope.off = function () {
        document.getElementById("overlay").style.display = "none";
    }

    $scope.proceed = function () {
        $('#myModal').modal('hide');
        document.getElementById("overlay").style.display = "block";
    }

    $scope.dontProceed = function () {
        $window.location.href = '/assessment_no_choice.html';
    }

    $scope.getRegistrationId = function () {

        var data = {
            _id: $scope.digitalId,
            functionName: "queryStudentDetails",
            user: "assessment",
            toBeFetchedFrom: "cloudant"
        }

        $http({
            method: 'POST',
            url: '/getRegistrationId',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.registrationId = response.data.result;
                $scope.off();
            } else {
                alert(response.data.message);
            }
        });
    }
    $scope.submitAssessment = function () {
        $scope.isDisabled = true;
        var userAnsers = $scope.answer1 + "," + $scope.answer2 + "," + $scope.answer3 + "," + $scope.answer4 + "," + $scope.answer5;
        var data = {
            digitalId: $scope.digitalId,
            registrationId: $scope.registrationId,
            chaincodeFunction: "submitAssessment",
            user: "applicant",
            answer: userAnsers
        }

        $http({
            method: 'POST',
            url: '/submitAssessmentData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/assessment_success.html';
            } else {
                alert(response.data.message);
                window.close();
            }
        });

    }

}]);

/* Consortium Admin Login Controller */
myApp.controller('consortiumAdminLogin', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.verifyLogin = function () {

        var data = {
            username: $scope.username,
            password: $scope.password
        }

        $http({
            method: 'POST',
            url: '/verifyLogin',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                window.location.href = '/consortium_admin.html';
            } else {
                alert(response.data.message);
            }
        });
    }

}]);

/* University Admin Login Controller */
myApp.controller('universityAdminLogin', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.verifyLogin = function () {

        var data = {
            username: $scope.username,
            password: $scope.password
        }

        $http({
            method: 'POST',
            url: '/verifyLogin',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                window.location.href = '/university_admin.html';
            } else {
                alert(response.data.message);
            }
        });
    }

}]);

/* Assessment Admin Login Controller */
myApp.controller('assessmentAdminLogin', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.verifyLogin = function () {

        var data = {
            username: $scope.username,
            password: $scope.password
        }

        $http({
            method: 'POST',
            url: '/verifyLogin',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                window.location.href = '/assessment_admin.html';
            } else {
                alert(response.data.message);
            }
        });
    }

}]);

/* University Success Controller */
myApp.controller('universityAdmin', ['$scope', '$http', '$window', 'NgTableParams', function ($scope, $http, $window, NgTableParams) {

    $scope.getUniversityApplicantRequests = function () {
        $http({
            method: 'GET',
            url: '/getUniversityApplicantRequests'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                var list = [];
                for (var i = 0; i < response.data.result.length; i++) {
                    var map = new Object();
                    var registrationId = response.data.result[i].registrationId;
                    map['name'] = response.data.result[i].digitalIdInfo.fullName;
                    for (var j = 0; j < response.data.result[i].digitalIdInfo.universityDetails.length; j++) {
                        if (registrationId == response.data.result[i].digitalIdInfo.universityDetails[j].registrationId) {
                            map['universityName'] = response.data.result[i].digitalIdInfo.universityDetails[j].universityName;
                            map['digitalId'] = response.data.result[i].digitalIdInfo.universityDetails[j].digitalId;
                            map['courseAppliedFor'] = response.data.result[i].digitalIdInfo.universityDetails[j].courseAppliedFor;
                            map['appliedDegreeType'] = response.data.result[i].digitalIdInfo.universityDetails[j].appliedDegreeType;
                            list.push(map);
                        }
                    }
                }
                $scope.tableData = list;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.getIdToAddSemesterCert = function () {
        $http({
            method: 'GET',
            url: '/getUniversitySemApplicantRequests'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                var list = [];
                for (var i = 0; i < response.data.result.length; i++) {
                    var map = new Object();
                    var registrationId = response.data.result[i].registrationId;
                    map['name'] = response.data.result[i].digitalIdInfo.fullName;
                    for (var j = 0; j < response.data.result[i].digitalIdInfo.universityDetails.length; j++) {
                        if (registrationId == response.data.result[i].digitalIdInfo.universityDetails[j].registrationId) {
                            map['universityName'] = response.data.result[i].digitalIdInfo.universityDetails[j].universityName;
                            map['digitalId'] = response.data.result[i].digitalIdInfo.universityDetails[j].digitalId;
                            map['courseAppliedFor'] = response.data.result[i].digitalIdInfo.universityDetails[j].courseAppliedFor;
                            map['appliedDegreeType'] = response.data.result[i].digitalIdInfo.universityDetails[j].appliedDegreeType;
                            map['length'] = response.data.result[i].digitalIdInfo.universityDetails[j].semesterDetails.length;
                            list.push(map);
                        }
                    }
                }
                $scope.tableData = list;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.getUniversityPublishDetails = function () {
        $http({
            method: 'GET',
            url: '/getUniversityPublishDetails'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                var list = [];
                for (var i = 0; i < response.data.result.length; i++) {
                    var map = new Object();
                    var registrationId = response.data.result[i].registrationId;
                    map['name'] = response.data.result[i].digitalIdInfo.fullName;
                    for (var j = 0; j < response.data.result[i].digitalIdInfo.universityDetails.length; j++) {
                        if (registrationId == response.data.result[i].digitalIdInfo.universityDetails[j].registrationId && !response.data.result[i].digitalIdInfo.universityDetails[j].degreeCompleteStatus) {
                            map['universityName'] = response.data.result[i].digitalIdInfo.universityDetails[j].universityName;
                            map['digitalId'] = response.data.result[i].digitalIdInfo.universityDetails[j].digitalId;
                            map['courseAppliedFor'] = response.data.result[i].digitalIdInfo.universityDetails[j].courseAppliedFor;
                            map['appliedDegreeType'] = response.data.result[i].digitalIdInfo.universityDetails[j].appliedDegreeType;
                            list.push(map);
                        }
                    }
                }
                $scope.tableData = list;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert(response.data.message);
            }
        });
    }
    $scope.publishDataForDigitalId = function (digitalId) {
        $window.sessionStorage.setItem("_id", digitalId);
        $window.location.href = '/university_add_certs.html';
    }

    $scope.selectedDigitalId = function (digitalId) {
        $window.sessionStorage.setItem("_id", digitalId);
        $window.location.href = '/university_read_only.html';
    }

    $scope.selectedSemDigitalId = function (digitalId) {
        $window.sessionStorage.setItem("_id", digitalId);
        $window.location.href = '/university_add_semester_certs.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Consortium Admin DigitalId Requests Form Controller */
myApp.controller('consortiumAdmin', ['$scope', '$http', '$window', 'NgTableParams', function ($scope, $http, $window, NgTableParams) {

    $scope.getDigitalIdRequests = function () {
        $http({
            method: 'GET',
            url: '/getDigitalIdRequests'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.tableData = response.data.result;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.selectedDigitalId = function (digitalId) {
        $window.sessionStorage.setItem("_id", digitalId);
        $window.location.href = '/digital_id_read_only.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Assessment Admin Skill Set Requests Form Controller */
myApp.controller('assessmentAdmin', ['$scope', '$http', '$window', 'NgTableParams', function ($scope, $http, $window, NgTableParams) {

    $scope.getDigitalIdRequestsForAssessment = function () {
        $http({
            method: 'GET',
            url: '/getDigitalIdRequestsForAssessment'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                var list = [];
                for (var i = 0; i < response.data.result.length; i++) {
                    var map = new Object();
                    var registrationId = response.data.result[i].registrationId;
                    map['name'] = response.data.result[i].digitalIdInfo.fullName;
                    for (var j = 0; j < response.data.result[i].digitalIdInfo.assessmentDetails.length; j++) {
                        if (registrationId == response.data.result[i].digitalIdInfo.assessmentDetails[j].registrationId) {
                            map['registrationId'] = response.data.result[i].digitalIdInfo.assessmentDetails[j].registrationId;
                            map['digitalId'] = response.data.result[i].digitalIdInfo.assessmentDetails[j].digitalId;
                            map['skillSet'] = response.data.result[i].digitalIdInfo.assessmentDetails[j].skillSet;
                            list.push(map);
                        }
                    }
                }
                $scope.tableData = list;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.getDigitalIdWithPendingTranscriptStatus = function () {
        $http({
            method: 'GET',
            url: '/getDigitalIdWithPendingTranscriptStatus'
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                var list = [];
                for (var i = 0; i < response.data.result.length; i++) {
                    var map = new Object();
                    var registrationId = response.data.result[i].registrationId;
                    map['name'] = response.data.result[i].digitalIdInfo.fullName;
                    map['emailId'] = response.data.result[i].digitalIdInfo.emailId;
                    for (var j = 0; j < response.data.result[i].digitalIdInfo.assessmentDetails.length; j++) {
                        if (registrationId == response.data.result[i].digitalIdInfo.assessmentDetails[j].registrationId) {
                            map['registrationId'] = response.data.result[i].digitalIdInfo.assessmentDetails[j].registrationId;
                            map['digitalId'] = response.data.result[i].digitalIdInfo.assessmentDetails[j].digitalId;
                            map['skillSet'] = response.data.result[i].digitalIdInfo.assessmentDetails[j].skillSet;
                            map['assessmentCode'] = response.data.result[i].digitalIdInfo.assessmentDetails[j].assessmentCode;
                            list.push(map);
                        }
                    }
                }
                $scope.tableData = list;
                $scope.tableParams = new NgTableParams({
                    count: 4
                }, {
                    counts: [],
                    dataset: $scope.tableData
                });
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.selectedDigitalId = function (digitalId) {
        $window.sessionStorage.setItem("_id", digitalId);
        $window.location.href = '/add_skill_sets_read_only.html';
    }

    $scope.selectedRegsitrationId = function (data) {
        $window.sessionStorage.setItem("_id", data.digitalId);
        $window.location.href = '/' + data.assessmentCode + '_readonly.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Digital Id Read Only Form Controller */
myApp.controller('digitalIdReadOnlyForm', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {
    $scope.isDisabled = false;

    var data = {
        _id: $window.sessionStorage.getItem("_id")
    }

    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.loadDigitalIdData = function () {
        $http({
            method: 'POST',
            url: '/getDigitalIdDataFromCloudant',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.updateDigitalIdData = function (buttonValue) {
        $scope.isDisabled = true;
        var message = $scope.digitalIdData.message + " The digital id request has been " + buttonValue + ".";
        $scope.digitalIdData.message = message;

        if (buttonValue == "Approved")
            $scope.digitalIdData.digitalIdStatus = "Approved";

        if (buttonValue == "Rejected")
            $scope.digitalIdData.digitalIdStatus = "Rejected";

        var data = {
            data: $scope.digitalIdData,
            chaincodeFunction: "createStudentRecord",
            user: "university"
        }

        $http({
            method: 'POST',
            url: '/updateDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/consortium_admin.html';
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.Back = function () {
        $window.location.href = '/consortium_admin.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Add Certs Form Controller */
myApp.controller('addCerts', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {
    $scope.isDisabled = false;

    var data = {
        _id: $window.sessionStorage.getItem("_id")
    }

    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.openSemImg = function (data) {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = data.docName;
        var cloudantUniqueIdForDoc = data._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.loadDigitalIdData = function () {
        $http({
            method: 'POST',
            url: '/getDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                var assessmentDetails = $scope.digitalIdData.digitalIdInfo.assessmentDetails;
                for (var i = 0; i < assessmentDetails.length; i++) {
                    if (assessmentDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                        $scope.skillset = assessmentDetails[i].skillSet;
                        $scope.score = assessmentDetails[i].assessmentScore;
                    }
                }
                var universityDetails = $scope.digitalIdData.digitalIdInfo.universityDetails;
                for (var i = 0; i < universityDetails.length; i++) {
                    if (universityDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                        $scope.universityName = universityDetails[i].universityName;
                        $scope.universityAddress = universityDetails[i].universityAddress;
                        $scope.universityId = universityDetails[i].universityId;
                        $scope.courseAppliedFor = universityDetails[i].courseAppliedFor;
                        $scope.appliedDegreeType = universityDetails[i].appliedDegreeType;
                        $scope.semesterInfo = universityDetails[i].semesterDetails;
                    }
                }
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.$watch('myFile', function (newFileObj) {
        if (newFileObj)
            $scope.filename = newFileObj.name;
    });

    $scope.updateDigitalIdData = function () {
        $scope.isDisabled = true;
        var document = {
            _id: $scope.digitalIdData._id + '-Certificate',
            docName: "",
            docType: "Course Completion Certificate",
            digitalId: $scope.digitalIdData._id + ''
        }
        var file = $scope.myFile;
        document.docName = file.name;
        var message = $scope.digitalIdData.message + " The applicants certificate details have been published.";
        $scope.digitalIdData.message = message;
        for (var i = 0; i < $scope.digitalIdData.digitalIdInfo.universityDetails.length; i++) {
            if ($scope.digitalIdData.digitalIdInfo.universityDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                $scope.digitalIdData.digitalIdInfo.universityDetails[i].courseEndDate = $scope.courseEndDate;
                $scope.digitalIdData.digitalIdInfo.universityDetails[i].universityDocument = document;
                $scope.digitalIdData.digitalIdInfo.universityDetails[i].degreeCompleteStatus = true;
            }
        }
        var uploadUrl = "/addCertsRelatedToDigitalIdToDB";
        fileUpload.uploadFileAndFieldsToUrl(file, $scope.digitalIdData, uploadUrl);
    }

    $scope.Back = function () {
        $window.location.href = '/university_admin.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Add Semester Wise Certs Form Controller */
myApp.controller('addSemCerts', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {
    $scope.isDisabled = false;
    $scope.first = true;
    $scope.second = false;
    $scope.third = false;
    $scope.fourth = false;
    $scope.first_readonly = false;
    $scope.second_readonly = false;
    $scope.third_readonly = false;
    $scope.fourth_readonly = false;

    var data = {
        _id: $window.sessionStorage.getItem("_id")
    }

    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.openSemImg = function (data) {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = data.docName;
        var cloudantUniqueIdForDoc = data._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.loadDigitalIdData = function () {
        $http({
            method: 'POST',
            url: '/getDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                var assessmentDetails = $scope.digitalIdData.digitalIdInfo.assessmentDetails;
                for (var i = 0; i < assessmentDetails.length; i++) {
                    if (assessmentDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                        $scope.skillset = assessmentDetails[i].skillSet;
                        $scope.score = assessmentDetails[i].assessmentScore;
                    }
                }
                var universityDetails = $scope.digitalIdData.digitalIdInfo.universityDetails;
                for (var i = 0; i < universityDetails.length; i++) {
                    if (universityDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                        $scope.universityName = universityDetails[i].universityName;
                        $scope.universityAddress = universityDetails[i].universityAddress;
                        $scope.universityId = universityDetails[i].universityId;
                        $scope.courseAppliedFor = universityDetails[i].courseAppliedFor;
                        $scope.appliedDegreeType = universityDetails[i].appliedDegreeType;
                        $scope.semesterInfo = universityDetails[i].semesterDetails;
                    }
                }
                if ($scope.semesterInfo.length == 0) {
                    $scope.first = true;
                    $scope.second = $scope.third = $scope.fourth = $scope.first_readonly = $scope.second_readonly = $scope.third_readonly = $scope.fourth_readonly = false;
                } else if ($scope.semesterInfo.length == 1) {
                    $scope.first_readonly = $scope.second = true;
                    $scope.first = $scope.third = $scope.fourth = $scope.second_readonly = $scope.third_readonly = $scope.fourth_readonly = false;
                } else if ($scope.semesterInfo.length == 2) {
                    $scope.first_readonly = $scope.second_readonly = $scope.third = true;
                    $scope.first = $scope.second = $scope.fourth = $scope.third_readonly = $scope.fourth_readonly = false;
                } else if ($scope.semesterInfo.length == 3) {
                    $scope.first_readonly = $scope.second_readonly = $scope.third_readonly = $scope.fourth = true;
                    $scope.first = $scope.second = $scope.third = $scope.fourth_readonly = false;
                }
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.$watch('myFile', function (newFileObj) {
        if (newFileObj)
            $scope.filename = newFileObj.name;
    });

    $scope.updateDigitalIdData = function () {
        $scope.isDisabled = true;
        var document = {
            _id: "",
            docName: "",
            docType: "Semester Completion Certificate",
            digitalId: $scope.digitalIdData._id + ''
        }
        var semesterData = "";
        if ($scope.semesterInfo.length === 0) {
            semesterData = {
                semesterNo: '1',
                semesterDoc: document
            };
        } else if ($scope.semesterInfo.length === 1) {
            semesterData = {
                semesterNo: '2',
                semesterDoc: document
            };
        } else if ($scope.semesterInfo.length === 2) {
            semesterData = {
                semesterNo: '3',
                semesterDoc: document
            };
        } else if ($scope.semesterInfo.length === 3) {
            semesterData = {
                semesterNo: '4',
                semesterDoc: document
            };
        }
        var file = $scope.myFile;
        semesterData.semesterDoc.docName = file.name;
        semesterData.semesterDoc._id = $scope.digitalIdData._id + '-' + semesterData.semesterNo + '-Certificate'
        var message = $scope.digitalIdData.message + " The applicants certificate details have been published.";
        $scope.digitalIdData.message = message;
        for (var i = 0; i < $scope.digitalIdData.digitalIdInfo.universityDetails.length; i++) {
            if ($scope.digitalIdData.digitalIdInfo.universityDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                $scope.digitalIdData.digitalIdInfo.universityDetails[i].semesterDetails.push(semesterData);
            }
        }
        var uploadUrl = "/addSemesterWiseCerts";
        fileUpload.uploadFileAndFieldsToUrl(file, $scope.digitalIdData, uploadUrl);
    }

    $scope.Back = function () {
        $window.location.href = '/university_admin.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Skill Set Read Only Form Controller */
myApp.controller('skillSetReadOnlyForm', ['$scope', 'fileUpload', '$http', '$filter', '$window', '$sce', function ($scope, fileUpload, $http, $filter, $window, $sce) {
    $scope.isDisabled = false;

    var data = {
        _id: $window.sessionStorage.getItem("_id")
    }

    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.loadDigitalIdData = function () {
        $http({
            method: 'POST',
            url: '/getDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                var assessmentDetails = $scope.digitalIdData.digitalIdInfo.assessmentDetails;
                for (var i = 0; i < assessmentDetails.length; i++) {
                    if (assessmentDetails[i].assessmentScore == "" && assessmentDetails[i].assessmentUserAnswer == "") {
                        $scope.skillset = assessmentDetails[i].skillSet;
                    }
                }
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.updateDigitalIdData = function (buttonValue) {
        $scope.isDisabled = true;
        var message = $scope.digitalIdData.message + " The skill set based as per your profile has been " + buttonValue + ".";
        $scope.digitalIdData.message = message;

        if (buttonValue == "Approved")
            $scope.digitalIdData.skillSetStatus = "Approved";

        if (buttonValue == "Rejected")
            $scope.digitalIdData.skillSetStatus = "Rejected";

        var data = {
            data: $scope.digitalIdData,
            chaincodeFunction: "sendAssessmentDetails",
            user: "assessment"
        }

        $http({
            method: 'POST',
            url: '/updateDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/assessment_admin.html';
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.Back = function () {
        $window.location.href = '/assessment_admin.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Digital Id Read Only Form Controller */
myApp.controller('universityReadOnlyForm', ['$scope', 'fileUpload', '$http', '$filter', '$window', '$sce', function ($scope, fileUpload, $http, $filter, $window, $sce) {
    $scope.isDisabled = false;

    var data = {
        _id: $window.sessionStorage.getItem("_id")
    }

    $scope.openImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.digitalIdData.digitalIdInfo.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.digitalIdData.digitalIdInfo.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.loadDigitalIdData = function () {
        $http({
            method: 'POST',
            url: '/getDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.digitalIdData = response.data.result[0];
                $scope.dob = new Date(response.data.result[0].digitalIdInfo.dateOfBirth);
                var assessmentDetails = $scope.digitalIdData.digitalIdInfo.assessmentDetails;
                for (var i = 0; i < assessmentDetails.length; i++) {
                    if (assessmentDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                        $scope.skillset = assessmentDetails[i].skillSet;
                        $scope.score = assessmentDetails[i].assessmentScore;
                    }
                }
                var universityDetails = $scope.digitalIdData.digitalIdInfo.universityDetails;
                for (var i = 0; i < universityDetails.length; i++) {
                    if (universityDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                        $scope.universityName = universityDetails[i].universityName;
                        $scope.universityAddress = universityDetails[i].universityAddress;
                        $scope.universityId = universityDetails[i].universityId;
                        $scope.courseAppliedFor = universityDetails[i].courseAppliedFor;
                        $scope.appliedDegreeType = universityDetails[i].appliedDegreeType;
                    }
                }
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.updateDigitalIdData = function (buttonValue) {
        $scope.isDisabled = true;
        var message = $scope.digitalIdData.message + " The university admission request has been " + buttonValue + ".";
        $scope.digitalIdData.message = message;

        if (buttonValue == "Approved") {
            $scope.digitalIdData.universityAdmissionStatus = "Approved";
            for (var i = 0; i < $scope.digitalIdData.digitalIdInfo.universityDetails.length; i++) {
                if ($scope.digitalIdData.digitalIdInfo.universityDetails[i].registrationId == $scope.digitalIdData.registrationId) {
                    $scope.digitalIdData.digitalIdInfo.universityDetails[i].courseStartDate = Date.now() + '';
                }
            }
        }

        if (buttonValue == "Rejected")
            $scope.digitalIdData.digitalIdStatus = "Rejected";

        var data = {
            data: $scope.digitalIdData,
            chaincodeFunction: "addUniveristyDetails",
            user: "university"
        }

        $http({
            method: 'POST',
            url: '/updateDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/university_admin.html';
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.Back = function () {
        $window.location.href = '/university_admin.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Assessment Read Only Controller */
myApp.controller('assessmentReadOnly', ['$scope', 'fileUpload', '$http', '$filter', '$window', '$sce', function ($scope, fileUpload, $http, $filter, $window, $sce) {

    $scope.isDisabled = false;

    var data = {
        _id: $window.sessionStorage.getItem("_id")
    }

    $scope.loadDigitalIdData = function () {
        $http({
            method: 'POST',
            url: '/getDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.digitalIdData = response.data.result[0];
                $scope.allTxnIds = JSON.parse(response.data.txnIds.response);
                $scope.list = [];
                for (var i = 0; i < $scope.allTxnIds.length; i++) {
                    var map = new Object();
                    map['txnId'] = $scope.allTxnIds[i].tx_id;
                    map['txnMsg'] = $scope.allTxnIds[i].Record.txnMsg;
                    $scope.list.push(map);
                }
                var digitalIdData = response.data.result[0].digitalIdInfo.assessmentDetails;
                for (var i = 0; i < digitalIdData.length; i++) {
                    if (digitalIdData[i].assessmentScore == "") {
                        $scope.digitalId = digitalIdData[i].digitalId;
                        $scope.registrationId = digitalIdData[i].registrationId;
                        var answers = digitalIdData[i].assessmentUserAnswer.split(",");
                        $scope.answer1 = answers[0];
                        $scope.answer2 = answers[1];
                        $scope.answer3 = answers[2];
                        $scope.answer4 = answers[3];
                        $scope.answer5 = answers[4];
                    }
                }
            } else {
                alert(response.data.message);
            }
        });
    }


    $scope.getScore = function () {
        var assessmentData = $scope.digitalIdData.digitalIdInfo.assessmentDetails;
        var score = 0;
        for (var i = 0; i < assessmentData.length; i++) {
            if (assessmentData[i].assessmentScore == "" && assessmentData[i].registrationId == $scope.registrationId) {
                var userAnswers = assessmentData[i].assessmentUserAnswer.split(",");
                var correctAnswers = assessmentData[i].assessmentCorrectAnswer.split(",");
                for (var i = 0; i < correctAnswers.length; i++) {
                    if (userAnswers[i] != "" && userAnswers[i] == correctAnswers[i])
                        score++;
                }
            }
        }
        $scope.score = '75%';
    }

    $scope.submitResult = function () {
        $scope.isDisabled = true;
        var message = $scope.digitalIdData.message + " The score has been evaluated and sent as transcript to applicant .";
        $scope.digitalIdData.message = message;
        $scope.digitalIdData.transcriptSent = 'Approved';
        for (var i = 0; i < $scope.digitalIdData.digitalIdInfo.assessmentDetails.length; i++) {
            if ($scope.digitalIdData.digitalIdInfo.assessmentDetails[i].assessmentScore == "" && $scope.digitalIdData.digitalIdInfo.assessmentDetails[i].registrationId == $scope.registrationId) {
                $scope.digitalIdData.digitalIdInfo.assessmentDetails[i].assessmentScore = $scope.score;
                $scope.digitalIdData.digitalIdInfo.assessmentDetails[i].transcriptSent = 'Approved';
            }
        }

        var data = {
            data: $scope.digitalIdData,
            chaincodeFunction: "addAssessmentDetails",
            user: "university"
        }

        $http({
            method: 'POST',
            url: '/updateDigitalIdData',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $window.location.href = '/assessment_admin.html';
            } else {
                alert(response.data.message);
            }
        });
    }

    $scope.Back = function () {
        $window.location.href = '/assessment_admin.html';
    }

    $scope.Logout = function () {
        window.close();
    }

}]);

/* Port Folio View Controller */
myApp.controller('portFolioView', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.on = function () {
        document.getElementById("overlay").style.display = "block";
    }

    $scope.off = function () {
        document.getElementById("overlay").style.display = "none";
    }

    $scope.openIdImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.allDocs.idProof.documentDetails.docName;
        var cloudantUniqueIdForDoc = $scope.allDocs.idProof.documentDetails._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.openUnivImg = function () {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = $scope.allDocs.finalDegreeDoc.universityDocument.docName;
        var cloudantUniqueIdForDoc = $scope.allDocs.finalDegreeDoc.universityDocument._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.openSemesterImg = function (data) {
        var cloudantURL = "https://97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix:ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b@97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix.cloudant.com";
        var cloudantDocDB = "digital_id_applicant_documents";
        var documentName = data.semesterDoc.docName;
        var cloudantUniqueIdForDoc = data.semesterDoc._id;
        window.open(cloudantURL + '/' + cloudantDocDB + '/' + cloudantUniqueIdForDoc + '/' + documentName, '_blank');;
    }

    $scope.getDataFromBlockChain = function () {
        var data = {
            _id: $scope.digitalId
        }

        $http({
            method: 'POST',
            url: '/getDataFromBlockChain',
            data: data
        }).then(function successCallback(response) {
            if (response.data.success == true) {
                $scope.off();
                var digitalIdData = JSON.parse(response.data.response.digitalIdData.response);
                var txnDetails = JSON.parse(response.data.response.txnIds.response);
                var basicApplicantInfo = {
                    digitalId: digitalIdData.digitalId,
                    ssn: digitalIdData.ssn,
                    dateOfBirth: new Date(digitalIdData.dateOfBirth),
                    gender: digitalIdData.gender,
                    address: digitalIdData.address,
                    emailId: digitalIdData.emailId,
                    countrycode: digitalIdData.countrycode,
                    mobileNumber: digitalIdData.mobileNumber,
                    fullName: digitalIdData.fullName,
                    txnId: ''
                };
                var universityDoc = {
                    universityDocument: '',
                    txnId: ''
                };
                var idProof = {
                    documentDetails: digitalIdData.documentDetails,
                    txnId: ''
                };
                var allDocs = {
                    idProof: idProof,
                    semesterDocs: [],
                    finalDegreeDoc: ''
                };
                var assessmentDetails = [];
                var universityDetails = [];

                //Applicant Details
                for (var i = 0; i < txnDetails.length; i++) {
                    if (txnDetails[i].Record.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                        basicApplicantInfo.txnId = txnDetails[i].tx_id;
                        allDocs.idProof.txnId = txnDetails[i].tx_id;
                    }
                }
                $scope.basicInfo = basicApplicantInfo;

                //Transcript Details
                for (var i = 0; i < digitalIdData.assessmentDetails.length; i++) {
                    var registrationId = digitalIdData.assessmentDetails[i].registrationId;
                    for (var j = 0; j < txnDetails.length; j++) {
                        if (txnDetails[j].Record.txnMsg == 'Assessment details added to the applicant record.') {
                            var digitalTxnData = txnDetails[j].Record;
                            for (var k = 0; k < digitalTxnData.assessmentDetails.length; k++) {
                                var txnRegistrationId = digitalTxnData.assessmentDetails[k].registrationId;
                                if (registrationId == txnRegistrationId) {
                                    var assessmentInfo = {
                                        registrationId: digitalTxnData.assessmentDetails[k].registrationId,
                                        assessmentUserAnswer: digitalTxnData.assessmentDetails[k].assessmentUserAnswer,
                                        assessmentCorrectAnswer: digitalTxnData.assessmentDetails[k].assessmentCorrectAnswer,
                                        assessmentScore: digitalTxnData.assessmentDetails[k].assessmentScore,
                                        digitalId: digitalTxnData.assessmentDetails[k].digitalId,
                                        assessmentCode: digitalTxnData.assessmentDetails[k].assessmentCode,
                                        skillSet: digitalTxnData.assessmentDetails[k].skillSet,
                                        transcriptSent: digitalTxnData.assessmentDetails[k].transcriptSent,
                                        txnId: txnDetails[j].tx_id
                                    };
                                    assessmentDetails.push(assessmentInfo);
                                }
                            }
                        }
                    }
                }
                $scope.assessmentDetails = assessmentDetails;

                //University Details
                for (var i = 0; i < digitalIdData.universityDetails.length; i++) {
                    var registrationId = digitalIdData.universityDetails[i].registrationId;
                    for (var j = 0; j < txnDetails.length; j++) {
                        if (txnDetails[j].Record.txnMsg == 'University details added for the applicant record.') {
                            var digitalTxnData = txnDetails[j].Record;
                            for (var k = 0; k < digitalTxnData.universityDetails.length; k++) {
                                var txnRegistrationId = digitalTxnData.universityDetails[k].registrationId;
                                if (registrationId == txnRegistrationId) {
                                    var universityInfo = {
                                        universityName: digitalTxnData.universityDetails[k].universityName,
                                        universityAddress: digitalTxnData.universityDetails[k].universityAddress,
                                        universityId: digitalTxnData.universityDetails[k].universityId,
                                        courseAppliedFor: digitalTxnData.universityDetails[k].courseAppliedFor,
                                        appliedDegreeType: digitalTxnData.universityDetails[k].appliedDegreeType,
                                        courseStartDate: digitalTxnData.universityDetails[k].courseStartDate,
                                        courseEndDate: digitalTxnData.universityDetails[k].courseEndDate,
                                        degreeCompleteStatus: digitalTxnData.universityDetails[k].degreeCompleteStatus,
                                        digitalId: digitalTxnData.universityDetails[k].digitalId,
                                        registrationId: digitalTxnData.universityDetails[k].registrationId,
                                        txnId: txnDetails[j].tx_id
                                    };
                                    universityDetails.push(universityInfo);
                                }
                            }
                        }
                        if (txnDetails[j].Record.txnMsg == 'Final Degree certificate added to the applicant record.') {
                            var digitalTxnData = txnDetails[j].Record;
                            for (var k = 0; k < digitalTxnData.universityDetails.length; k++) {
                                var txnRegistrationId = digitalTxnData.universityDetails[k].registrationId;
                                if (registrationId == txnRegistrationId) {
                                    universityDoc.universityDocument = digitalTxnData.universityDetails[k].universityDocument;
                                    universityDoc.txnId = txnDetails[j].tx_id;
                                }
                            }
                        }
                        if (txnDetails[j].Record.txnMsg == 'Semester certificates added to the applicant record.') {
                            var digitalTxnData = txnDetails[j].Record;
                            for (var k = 0; k < digitalTxnData.universityDetails.length; k++) {
                                var txnRegistrationId = digitalTxnData.universityDetails[k].registrationId;
                                if (registrationId == txnRegistrationId) {
                                    universityDoc.universityDocument = digitalTxnData.universityDetails[k].universityDocument;
                                    var semesterData = digitalTxnData.universityDetails[k].semesterDetails[digitalTxnData.universityDetails[k].semesterDetails.length - 1];
                                    var semesterInfo = {
                                        semDoc: semesterData,
                                        txnId: txnDetails[j].tx_id
                                    };
                                    allDocs.semesterDocs.push(semesterInfo);
                                }
                            }
                        }
                    }
                }
                $scope.universityDetails = universityDetails;
                allDocs.finalDegreeDoc = universityDoc;
                $scope.allDocs = allDocs;

            }
        });
    }
}]);

/* Student Digital Id Explorer */
myApp.controller('explorerApp', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    //Intial Page Load Will Show Current Block Data
    $scope.initialLoad = function () {
        $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
        $('#loading').show();
        $http({
            method: 'POST',
            url: '/explorerLoadData'
        }).then(function successCallback(response) {
            if (response.data.success) {
                $('#loading').hide();
                $scope.forward = true;
                var channelData = response.data.response.channelInfo;
                var blockData = response.data.response.blockInfo;
                var chaincodeData = response.data.response.chaincodeInfo;
                var txnData = response.data.response.txnInfo;
                $scope.currentDataHash = blockData.data_hash;
                $scope.previousDataHash = blockData.previous_hash;
                $scope.txnId = txnData.row.txhash;
                $scope.txn_creator = txnData.row.creator_msp_id;
                $scope.digitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);
                $scope.total_blocks = channelData.channels[0].blocks;
                $scope.current_block_no = channelData.channels[0].blocks;
                $scope.total_txns = channelData.channels[0].transactions;
                $scope.channel_genesis_hash = channelData.channels[0].channel_genesis_hash;
                $scope.chaincode = chaincodeData.chaincode[0].chaincodename;
                $scope.peers = [{
                        peerName: "peer0.university.cts.com",
                        organization: "university",
                        mspId: "Org1MSP",
                        portNo: "7051"
                    },
                    {
                        peerName: "peer0.consortium.cts.com",
                        organization: "consortium",
                        mspId: "Org2MSP",
                        portNo: "8051"
                    },
                    {
                        peerName: "peer0.assessment.cts.com",
                        organization: "assessment",
                        mspId: "Org3MSP",
                        portNo: "9051"
                    }];
                $scope.nodes = $scope.peers.length;
                if ($scope.digitalIdData.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                    $scope.applicantDetails = true;
                    $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    $scope.txnMsg = 'Applicant data inserted into blockchain with digital Id as ' + $scope.digitalIdData.digitalId;
                } else if ($scope.digitalIdData.txnMsg == 'Assessment details added to the applicant record.') {
                    var assessmentDetails = $scope.digitalIdData.assessmentDetails[$scope.digitalIdData.assessmentDetails.length - 1];
                    $scope.assessmentDetails = true;
                    $scope.applicantDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    $scope.txnMsg = 'Transcript details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.registrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                } else if ($scope.digitalIdData.txnMsg == 'University details added for the applicant record.') {
                    $scope.universityDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    $scope.txnMsg = 'University details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                } else if ($scope.digitalIdData.txnMsg == 'Semester certificates added to the applicant record.') {
                    $scope.semesterDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.networkDetails = false;
                    var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    var semesterDetails = universityDetails.semesterDetails[universityDetails.semesterDetails.length - 1];
                    $scope.txnMsg = 'Semester ' + semesterDetails.semesterNo + ' certificate details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                } else if ($scope.digitalIdData.txnMsg == 'Final Degree certificate added to the applicant record.') {
                    $scope.finalDegreeCertDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    var finalDegreeDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    $scope.txnMsg = 'Final degree certificate added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                } else {
                    $scope.networkDetails = true;
                    $scope.txnMsg = 'Network configuration took place.';
                }
            } else
                alert(response.data.message);
        });
    }

    // On Click Of Back Arrow Will Show Previous Block Data
    $scope.Back = function () {
        $('#loading').show();
        $scope.current_block_no_count = ($scope.current_block_no - 1);
        if ($scope.current_block_no >= 1) {
            var data = {
                blockNo: $scope.current_block_no_count - 1,
                channelHash: $scope.channel_genesis_hash
            }
            $http({
                method: 'POST',
                url: '/explorerBlockData',
                data: data
            }).then(function successCallback(response) {
                $('#loading').hide();
                var blockData = response.data.response.blockInfo;
                var txnData = response.data.response.txnInfo;
                $scope.current_block_no = $scope.current_block_no_count;
                $scope.currentDataHash = blockData.data_hash;
                $scope.previousDataHash = blockData.previous_hash;
                $scope.txnId = txnData.row.txhash;
                $scope.txn_creator = txnData.row.creator_msp_id;
                $scope.digitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);

                if ($scope.digitalIdData.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                    $scope.applicantDetails = true;
                    $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    $scope.txnMsg = 'Applicant data inserted into blockchain with digital Id as ' + $scope.digitalIdData.digitalId;
                } else if ($scope.digitalIdData.txnMsg == 'Assessment details added to the applicant record.') {
                    var assessmentDetails = $scope.digitalIdData.assessmentDetails[$scope.digitalIdData.assessmentDetails.length - 1];
                    $scope.assessmentDetails = true;
                    $scope.applicantDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    $scope.txnMsg = 'Transcript details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.registrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                } else if ($scope.digitalIdData.txnMsg == 'University details added for the applicant record.') {
                    $scope.universityDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    $scope.txnMsg = 'University details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                } else if ($scope.digitalIdData.txnMsg == 'Semester certificates added to the applicant record.') {
                    $scope.semesterDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.networkDetails = false;
                    var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    var semesterDetails = universityDetails.semesterDetails[universityDetails.semesterDetails.length - 1];
                    $scope.txnMsg = 'Semester ' + semesterDetails.semesterNo + ' certificate details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                } else if ($scope.digitalIdData.txnMsg == 'Final Degree certificate added to the applicant record.') {
                    $scope.finalDegreeCertDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    var finalDegreeDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    $scope.txnMsg = 'Final degree certificate added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                } else {
                    $scope.networkDetails = true;
                    $scope.txnMsg = 'Network configuration took place.';
                }
            });
        } else {
            $('#loading').hide();
            alert('This is the first block in the network, going back beyond this is not possible.');
        }
    }

    // On Click Of Forward Arrow Will Show Next Block Data
    $scope.Forward = function () {
        $('#loading').show();
        $scope.current_block_no_count = $scope.current_block_no + 1;
        if ($scope.current_block_no_count < $scope.total_blocks) {
            var data = {
                blockNo: $scope.current_block_no_count,
                channelHash: $scope.channel_genesis_hash
            }
            $http({
                method: 'POST',
                url: '/explorerBlockData',
                data: data
            }).then(function successCallback(response) {
                $('#loading').hide();
                var blockData = response.data.response.blockInfo;
                var txnData = response.data.response.txnInfo;
                $scope.current_block_no = $scope.current_block_no_count;
                $scope.currentDataHash = blockData.data_hash;
                $scope.previousDataHash = blockData.previous_hash;
                $scope.txnId = txnData.row.txhash;
                $scope.txn_creator = txnData.row.creator_msp_id;
                $scope.digitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);

                if ($scope.digitalIdData.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                    $scope.applicantDetails = true;
                    $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    $scope.txnMsg = 'Applicant data inserted into blockchain with digital Id as ' + $scope.digitalIdData.digitalId;
                } else if ($scope.digitalIdData.txnMsg == 'Assessment details added to the applicant record.') {
                    var assessmentDetails = $scope.digitalIdData.assessmentDetails[$scope.digitalIdData.assessmentDetails.length - 1];
                    $scope.assessmentDetails = true;
                    $scope.applicantDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    $scope.txnMsg = 'Transcript details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.registrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                } else if ($scope.digitalIdData.txnMsg == 'University details added for the applicant record.') {
                    $scope.universityDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.finalDegreeCertDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    $scope.txnMsg = 'University details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                } else if ($scope.digitalIdData.txnMsg == 'Semester certificates added to the applicant record.') {
                    $scope.semesterDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.finalDegreeCertDetails = $scope.networkDetails = false;
                    var universityDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    var semesterDetails = universityDetails.semesterDetails[universityDetails.semesterDetails.length - 1];
                    $scope.txnMsg = 'Semester ' + semesterDetails.semesterNo + ' certificate details added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                } else if ($scope.digitalIdData.txnMsg == 'Final Degree certificate added to the applicant record.') {
                    $scope.finalDegreeCertDetails = true;
                    $scope.applicantDetails = $scope.assessmentDetails = $scope.universityDetails = $scope.semesterDetails = $scope.networkDetails = false;
                    var finalDegreeDetails = $scope.digitalIdData.universityDetails[$scope.digitalIdData.universityDetails.length - 1];
                    $scope.txnMsg = 'Final degree certificate added to applicant data with digitalId ' + $scope.digitalIdData.digitalId;
                } else {
                    $scope.networkDetails = true;
                    $scope.txnMsg = 'Network configuration took place.';
                }
            });
        } else {
            $('#loading').hide();
            alert('This is the last block in the network, going forward beyond this is not possible.');
        }
    }

    // On click Of Get Details and selection checkbox data
    $scope.find = function () {
        $('#loading').show();
        var data = {
            selectedOpt: $scope.selectedOpt,
            inputValue: $scope.inputValue
        };
        if (data.selectedOpt != undefined && data.inputValue != undefined) {
            if (data.selectedOpt == "Block") {
                var blockNo = {
                    blockNo: data.inputValue - 1,
                    channelHash: $scope.channel_genesis_hash
                }
                if (blockNo.blockNo > 0 && blockNo.blockNo < $scope.total_blocks) {
                    $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockFinalDegreeCertDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                    $http({
                        method: 'POST',
                        url: '/explorerBlockData',
                        data: blockNo
                    }).then(function successCallback(response) {
                        $('#loading').hide();
                        $('#blockModal').modal('show');
                        var blockData = response.data.response.blockInfo;
                        var txnData = response.data.response.txnInfo;
                        $scope.blockCurrentDataHash = blockData.data_hash;
                        $scope.blockPreviousDataHash = blockData.previous_hash;
                        $scope.blockTxnId = txnData.row.txhash;
                        $scope.block_txn_creator = txnData.row.creator_msp_id;
                        $scope.blockDigitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);

                        if ($scope.blockDigitalIdData.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                            $scope.blockApplicantDetails = true;
                            $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockFinalDegreeCertDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                            $scope.blockTxnMsg = 'Applicant data inserted into blockchain with digital Id as ' + $scope.blockDigitalIdData.digitalId;
                        } else if ($scope.blockDigitalIdData.txnMsg == 'Assessment details added to the applicant record.') {
                            var assessmentDetails = $scope.blockDigitalIdData.assessmentDetails[$scope.blockDigitalIdData.assessmentDetails.length - 1];
                            $scope.blockAssessmentDetails = true;
                            $scope.blockApplicantDetails = $scope.blockUniversityDetails = $scope.blockFinalDegreeCertDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                            $scope.blockTxnMsg = 'Transcript details added to applicant data with digitalId ' + $scope.blockDigitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.registrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                        } else if ($scope.blockDigitalIdData.txnMsg == 'University details added for the applicant record.') {
                            $scope.blockUniversityDetails = true;
                            $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockFinalDegreeCertDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                            var universityDetails = $scope.blockDigitalIdData.universityDetails[$scope.blockDigitalIdData.universityDetails.length - 1];
                            $scope.blockTxnMsg = 'University details added to applicant data with digitalId ' + $scope.blockDigitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                        } else if ($scope.blockDigitalIdData.txnMsg == 'Semester certificates added to the applicant record.') {
                            $scope.blockSemesterDetails = true;
                            $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockFinalDegreeCertDetails = $scope.blockNetworkDetails = false;
                            var universityDetails = $scope.blockDigitalIdData.universityDetails[$scope.blockDigitalIdData.universityDetails.length - 1];
                            var semesterDetails = universityDetails.semesterDetails[universityDetails.semesterDetails.length - 1];
                            $scope.blockTxnMsg = 'Semester ' + semesterDetails.semesterNo + ' certificate details added to applicant data with digitalId ' + $scope.blockDigitalIdData.digitalId;
                        } else if ($scope.blockDigitalIdData.txnMsg == 'Final Degree certificate added to the applicant record.') {
                            $scope.blockFinalDegreeCertDetails = true;
                            $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockSemesterDetails = $scope.blockNetworkDetails = false;
                            var blockFinalDegreeDetails = $scope.blockDigitalIdData.universityDetails[$scope.blockDigitalIdData.universityDetails.length - 1];
                            $scope.blockTxnMsg = 'Final degree certificate added to applicant data with digitalId ' + $scope.blockDigitalIdData.digitalId;
                        } else {
                            $scope.blockNetworkDetails = true;
                            $scope.blockApplicantDetails = $scope.blockAssessmentDetails = $scope.blockUniversityDetails = $scope.blockSemesterDetails = $scope.blockFinalDegreeCertDetails = false;
                            $scope.blockTxnMsg = 'Network configuration took place.';
                        }
                    });
                }
            } else {
                var txnNo = {
                    txnId: data.inputValue,
                    channelHash: $scope.channel_genesis_hash
                }
                $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnFinalDegreeCertDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                $http({
                    method: 'POST',
                    url: '/explorerTxnData',
                    data: txnNo
                }).then(function successCallback(response) {
                    $('#loading').hide();
                    $('#txnModal').modal('show');
                    var txnData = response.data.response.txnInfo;
                    $scope.payload_hash = txnData.row.payload_proposal_hash;
                    $scope.create_timestamp = txnData.row.createdt;
                    $scope.txnTxnId = txnData.row.txhash;
                    $scope.txn_txn_creator = txnData.row.creator_msp_id;
                    $scope.txnDigitalIdData = JSON.parse(txnData.row.write_set[0].set[0].value);

                    if ($scope.txnDigitalIdData.txnMsg == 'Applicant data was approved and inserted into blockchain.') {
                        $scope.txnApplicantDetails = true;
                        $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnFinalDegreeCertDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                        $scope.txnTxnMsg = 'Applicant data inserted into blockchain with digital Id as ' + $scope.txnDigitalIdData.digitalId;
                    } else if ($scope.txnDigitalIdData.txnMsg == 'Assessment details added to the applicant record.') {
                        var assessmentDetails = $scope.txnDigitalIdData.assessmentDetails[$scope.txnDigitalIdData.assessmentDetails.length - 1];
                        $scope.txnAssessmentDetails = true;
                        $scope.txnApplicantDetails = $scope.txnUniversityDetails = $scope.txnFinalDegreeCertDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                        $scope.txnTxnMsg = 'Transcript details added to applicant data with digitalId ' + $scope.txnDigitalIdData.digitalId + ' with registrationId as ' + assessmentDetails.registrationId + ' where the applicant score was ' + assessmentDetails.assessmentScore;
                    } else if ($scope.txnDigitalIdData.txnMsg == 'University details added for the applicant record.') {
                        $scope.txnUniversityDetails = true;
                        $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnFinalDegreeCertDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                        var universityDetails = $scope.txnDigitalIdData.universityDetails[$scope.txnDigitalIdData.universityDetails.length - 1];
                        $scope.txnTxnMsg = 'University details added to applicant data with digitalId ' + $scope.txnDigitalIdData.digitalId + ' where the university selected was ' + universityDetails.universityName + ' and the course was ' + universityDetails.courseAppliedFor;
                    } else if ($scope.txnDigitalIdData.txnMsg == 'Semester certificates added to the applicant record.') {
                        $scope.txnSemesterDetails = true;
                        $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnFinalDegreeCertDetails = $scope.txnNetworkDetails = false;
                        var universityDetails = $scope.txnDigitalIdData.universityDetails[$scope.txnDigitalIdData.universityDetails.length - 1];
                        var semesterDetails = universityDetails.semesterDetails[universityDetails.semesterDetails.length - 1];
                        $scope.txnTxnMsg = 'Semester ' + semesterDetails.semesterNo + ' certificate details added to applicant data with digitalId ' + $scope.txnDigitalIdData.digitalId;
                    } else if ($scope.txnDigitalIdData.txnMsg == 'Final Degree certificate added to the applicant record.') {
                        $scope.txnFinalDegreeCertDetails = true;
                        $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnSemesterDetails = $scope.txnNetworkDetails = false;
                        var blockFinalDegreeDetails = $scope.txnDigitalIdData.universityDetails[$scope.txnDigitalIdData.universityDetails.length - 1];
                        $scope.txnTxnMsg = 'Final degree certificate added to applicant data with digitalId ' + $scope.txnDigitalIdData.digitalId;
                    } else {
                        $scope.txnNetworkDetails = true;
                        $scope.txnApplicantDetails = $scope.txnAssessmentDetails = $scope.txnUniversityDetails = $scope.txnSemesterDetails = $scope.txnFinalDegreeCertDetails = false;
                        $scope.txnTxnMsg = 'Network configuration took place.';
                    }
                });
            }
        } else {
            alert('Please select the checkbox and fill appropiate value in the input box to continue searching details !');
        }
    }

}]);

/* University Success Controller */
myApp.controller('universitySuccess', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.closeTab = function () {
        window.close();
    }

}]);

/* Digital Id Success Controller */
myApp.controller('digitalIdSuccess', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.closeTab = function () {
        window.close();
    }

}]);

/* Skill Set Success Controller */
myApp.controller('skillSetSuccess', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.closeTab = function () {
        window.close();
    }

}]);

/* Assessment Success Controller */
myApp.controller('assessmentSuccess', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.closeTab = function () {
        window.top.close();
    }

}]);

/* Assessment Not Success Controller */
myApp.controller('assessmentNotSuccess', ['$scope', 'fileUpload', '$http', '$filter', '$window', function ($scope, fileUpload, $http, $filter, $window) {

    $scope.closeTab = function () {
        window.top.close();
    }

}]);