var express = require('express');
var path = require('path');
var fs = require('fs');
var bodyParser = require('body-parser');
var axios = require('axios');
var port = process.env.PORT || process.env.VCAP_APP_PORT || '8080';
var nano = require('nano')('http://ec2-52-206-196-6.compute-1.amazonaws.com:' + port);
var app = express();
var multer = require('multer');
var multiparty = require('multiparty');
var nodemailer = require('nodemailer');
var Cloudant = require('@cloudant/cloudant');
var path = require('path');
var swaggerUi = require('swagger-ui-express');
var swaggerJSDoc = require('swagger-jsdoc');
var smtpTransport = require('nodemailer-smtp-transport');
var {
    FileSystemWallet,
    Gateway
} = require('fabric-network');
var ccpPath = path.resolve(__dirname, 'connection.json');
var ccpJSON = fs.readFileSync(ccpPath, 'utf8');
var ccp = JSON.parse(ccpJSON);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
var upload = multer({
    dest: __dirname + '/upload'
});
var type = upload.single('file');
var options = {
    customCss: '.swagger-ui .topbar { display: none }'
};
var swaggerSpec = swaggerJSDoc({
    swaggerDefinition: {
        info: {
            description: 'Student Digital ID API Catalog',
            version: '0.0.1',
            title: 'Student Digital Id API',
            termsOfService: 'http://swagger.io/terms/',
            contact: {
                email: 'prem.dutt@cognizant.com'
            }
        },
        host: 'ec2-52-206-196-6.compute-1.amazonaws.com:' + port,
        basePath: '/',
    },
    apis: ['server.js']
});
app.use('/', express.static(__dirname + '/'));
app.use('/', express.static(__dirname + '/images'));
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, options));
var cloudantUserName = '97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix';
var cloudantPassword = 'ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b';
var cloudant_url = 'https://' + cloudantUserName + ':' + cloudantPassword + '@' + cloudantUserName + '.cloudant.com'; // Set this to your own account
var cloudant = Cloudant(cloudant_url);
var dbForLogin = cloudant.db.use('digital_id_login_details');
var dbForApplicantData = cloudant.db.use('digital_id_applicant_data');
var dbForApplicantDocs = cloudant.db.use('digital_id_applicant_documents');
//Starting page when server starts
app.get('/', function (req, res) {
    console.log('Open index.html page');
    res.sendFile(path.join(__dirname + '/index.html'));
});
//Create index on applicant db for digitalIdStatus field if not existing
var digitalIdStatus = {
    name: 'digitalIdStatus',
    type: 'json',
    index: {
        fields: ['digitalIdStatus']
    }
};
dbForApplicantData.index(digitalIdStatus, function (er, response) {
    if (er) console.log('Error creating index on digital id status : ' + er);
    else console.log('Index creation result on digital id status : ' + response.result);
});
//Create index on applicant db for skillSetStatus field if not existing
var skillSetStatus = {
    name: 'skillSetStatus',
    type: 'json',
    index: {
        fields: ['skillSetStatus']
    }
};
dbForApplicantData.index(skillSetStatus, function (er, response) {
    if (er) console.log('Error creating index on skill set status : ' + er);
    else console.log('Index creation result on skill set status : ' + response.result);
});
//Create index on applicant db for universityAdmissionStatus field if not existing
var universityAdmissionStatus = {
    name: 'universityAdmissionStatus',
    type: 'json',
    index: {
        fields: ['universityAdmissionStatus']
    }
};
dbForApplicantData.index(universityAdmissionStatus, function (er, response) {
    if (er) console.log('Error creating index on university admission status : ' + er);
    else console.log('Index creation result on university admission status : ' + response.result);
});
//Create index on applicant db for ssn field if not existing
var ssn = {
    name: 'ssn',
    type: 'json',
    index: {
        fields: ['ssn']
    }
};
dbForApplicantData.index(ssn, function (er, response) {
    if (er) console.log('Error creating index on ssn : ' + er);
    else console.log('Index creation result on ssn : ' + response.result);
});
//Create index on applicant db for digitalId if not existing
var dataDbDigitalId = {
    name: '_id',
    type: 'json',
    index: {
        fields: ['_id']
    }
};
dbForApplicantData.index(dataDbDigitalId, function (er, response) {
    if (er) console.log('Error creating index on digitalId : ' + er);
    else console.log('Index creation result on digitalId : ' + response.result);
});
//Create index on applicant db for transcript if not existing
var transcriptSent = {
    name: 'transcriptSent',
    type: 'json',
    index: {
        fields: ['transcriptSent']
    }
};
dbForApplicantData.index(transcriptSent, function (er, response) {
    if (er) console.log('Error creating index on transcriptSent : ' + er);
    else console.log('Index creation result on transcriptSent : ' + response.result);
});
//Verify admin login data from DB
app.post('/verifyLogin', function (req, res) {
    console.log('Inside Express api check for login');
    console.log('Received login details : ' + JSON.stringify(req.body));
    verifyCredentialsFromCloudant(req.body.username, req.body.password).then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'User name verified with password successfully !'
            });
        } else res.json({
            success: false,
            message: 'User name not found !'
        });
    });
});
//Add digital Id data to DB
app.post('/addDigitalDataToDB', type, function (req, res) {
    console.log('Inside Express api to insert data for applicant');
    var applicantData = JSON.parse(JSON.stringify(req.body.data));
    applicantData = JSON.parse(applicantData);
    fs.readFile(__dirname + '/upload/' + req.file.filename, function (err, response) {
        insertCloudantData(applicantData).then(function (data) {
            if (data.success) {
                insertDocInCloudant(response, req.file, applicantData.digitalIdInfo.documentDetails).then(function (data) {
                    if (data.success) {
                        fs.unlink(__dirname + '/upload/' + req.file.filename, function (err) {
                            if (!err) console.log('File deleted !');
                            else console.log('Issue deleting File');
                        });
                        res.json({
                            success: true,
                            message: 'Applicant data and document inserted successfully !'
                        });
                    } else res.json({
                        success: false,
                        message: 'Issue inserting applicant document !'
                    });
                });
            } else res.json({
                success: false,
                message: 'Issue inserting applicant data !'
            });
        });
    });
});
//Add final degree certs related to digital Id to DB
app.post('/addCertsRelatedToDigitalIdToDB', type, function (req, res) {
    console.log('Inside Express api to insert data for applicant');
    var applicantData = JSON.parse(JSON.stringify(req.body.data));
    applicantData = JSON.parse(applicantData);
    var documentDetails = "";
    for (var i = 0; i < applicantData.digitalIdInfo.universityDetails.length; i++) {
        if (applicantData.registrationId === applicantData.digitalIdInfo.universityDetails[i].registrationId) {
            documentDetails = applicantData.digitalIdInfo.universityDetails[i].universityDocument;
        }
    }
    fs.readFile(__dirname + '/upload/' + req.file.filename, function (err, response) {
        updateCloudantData(applicantData, 'addFinalDegreeDetails', 'university').then(function (data) {
            if (data.success) {
                insertDocInCloudant(response, req.file, documentDetails).then(function (data) {
                    if (data.success) {
                        fs.unlink(__dirname + '/upload/' + req.file.filename, function (err) {
                            if (!err) console.log('File deleted !');
                            else console.log('Issue deleting File');
                        });
                        res.json({
                            success: true,
                            message: 'Applicant data and document inserted successfully !'
                        });
                    } else res.json({
                        success: false,
                        message: 'Issue inserting applicant document !'
                    });
                });
            } else res.json({
                success: false,
                message: 'Issue inserting applicant data !'
            });
        });
    });
});
//Add semester certs related to digital Id to DB
app.post('/addSemesterWiseCerts', type, function (req, res) {
    console.log('Inside Express api to insert data for applicant');
    var applicantData = JSON.parse(JSON.stringify(req.body.data));
    applicantData = JSON.parse(applicantData);
    var documentDetails = "";
    for (var i = 0; i < applicantData.digitalIdInfo.universityDetails.length; i++) {
        if (applicantData.registrationId === applicantData.digitalIdInfo.universityDetails[i].registrationId) {
            for (var j = 0; j < applicantData.digitalIdInfo.universityDetails[i].semesterDetails.length; j++) {
                var semesterInfo = applicantData.digitalIdInfo.universityDetails[i].semesterDetails[applicantData.digitalIdInfo.universityDetails[i].semesterDetails.length - 1];
                documentDetails = semesterInfo.semesterDoc;
            }
        }
    }
    fs.readFile(__dirname + '/upload/' + req.file.filename, function (err, response) {
        updateCloudantData(applicantData, 'addSemesterDetails', 'university').then(function (data) {
            if (data.success) {
                insertDocInCloudant(response, req.file, documentDetails).then(function (data) {
                    if (data.success) {
                        fs.unlink(__dirname + '/upload/' + req.file.filename, function (err) {
                            if (!err) console.log('File deleted !');
                            else console.log('Issue deleting File');
                        });
                        res.json({
                            success: true,
                            message: 'Applicant data and document inserted successfully !'
                        });
                    } else res.json({
                        success: false,
                        message: 'Issue inserting applicant document !'
                    });
                });
            } else res.json({
                success: false,
                message: 'Issue inserting applicant data !'
            });
        });
    });
});
//Get all digital Ids with digital Id status as 'PENDING'
app.get('/getDigitalIdRequests', function (req, res) {
    console.log('Inside Express api check to get all applicants details for digital Id');
    digitalIdWithPendingStatus().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result.docs
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get all digital Ids with skill set status as 'Pending'
app.get('/getDigitalIdRequestsForAssessment', function (req, res) {
    console.log('Inside Express api check to get all applicants details with skillset status pending');
    digitalIdWithPendingSkillSetStatus().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get all digital Ids with university application status as 'PENDING'
app.get('/getUniversityApplicantRequests', function (req, res) {
    console.log('Inside Express api check to get all applicants details for university applications');
    digitalIdWithPendingUniversityAdmissionStatus().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get all digital Ids with university application status as 'PENDING'
app.get('/getUniversitySemApplicantRequests', function (req, res) {
    console.log('Inside Express api check to get all applicants details to add semester certificates');
    digitalIdWithPendingUniversityAdmissionStatusForSemester().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get all digital Ids with transcript sent status as 'Pending'
app.get('/getDigitalIdWithPendingTranscriptStatus', function (req, res) {
    console.log('Inside Express api check to get all applicants details for transcript sent');
    digitalIdWithPendingTranscriptStatus().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get all digital Ids with course complete status as false
app.get('/getUniversityPublishDetails', function (req, res) {
    console.log('Inside Express api check to get all applicants details for course complete as false');
    digitalIdWithPendingCourseCompletionStatus().then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Data found successfully ! ',
                result: data.result
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get selected _id details from DB
app.post('/getDigitalIdDataFromCloudant', function (req, res) {
    console.log('Inside Express api check to get digital Id data : ' + req.body._id);
    getDigitalIdDataFromCloudant(req.body._id).then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Applicant data found successfully ! ',
                result: data.response.docs
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get selected _id details from DB
app.post('/getDigitalIdData', function (req, res) {
    console.log('Inside Express api check to get digital Id data : ' + req.body._id);
    getDigitalIdData(req.body._id).then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Applicant data found successfully ! ',
                result: data.response.docs,
                txnIds: data.txnIds
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Update digital Id applicant details to DB
app.post('/updateDigitalIdData', function (req, res) {
    console.log('Inside Express api check to update digital Id data ! ');
    var applicantData = JSON.parse(JSON.stringify(req.body.data));
    var technicalSkills = [{
        skillset: 'NODE_JS',
        answers: 'a,d,c,c,a',
        assignmentCode: '5cc4478a451c0'
    }, {
        skillset: 'JAVA',
        answers: 'a,b,b,c,a',
        assignmentCode: '5cc4477f7ed4f'
    }, {
        skillset: 'PYTHON',
        answers: 'b,d,b,d,c',
        assignmentCode: '5cc44761701c6'
    }, {
        skillset: 'BIG_DATA',
        answers: 'd,b,a,a,c',
        assignmentCode: '5cc44771dfca0'
    }];
    if (req.body.chaincodeFunction === 'addSkillSet' && req.body.user === 'applicant') {
        for (var i = 0; i < applicantData.digitalIdInfo.assessmentDetails.length; i++) {
            if (applicantData.digitalIdInfo.assessmentDetails[i].registrationId === applicantData.registrationId) {
                var selectedSkillSet = applicantData.digitalIdInfo.assessmentDetails[i].skillSet;
                for (var j = 0; j < technicalSkills.length; j++) {
                    if (technicalSkills[j].skillset === selectedSkillSet) {
                        applicantData.digitalIdInfo.assessmentDetails[i].assessmentCorrectAnswer = technicalSkills[j].answers;
                        applicantData.digitalIdInfo.assessmentDetails[i].assessmentCode = technicalSkills[j].assignmentCode;
                    }
                }
            }
        }
    }
    updateCloudantData(applicantData, req.body.chaincodeFunction, req.body.user).then(function (data) {
        if (data.success) {
            res.json({
                success: true,
                message: 'Applicant data updated successfully ! ',
                result: data.response
            });
        } else res.json({
            success: false,
            message: 'Applicant data updation issue !'
        });
    });
});
//Get registration id from digital Id applicant details from DB
app.post('/getRegistrationId', function (req, res) {
    console.log('Inside Express api check to update digital Id data ! ');
    getDigitalIdData(req.body._id).then(function (data) {
        if (data.success && data.response.docs.length > 0) {
            var assessmentDetails = data.response.docs[0].digitalIdInfo.assessmentDetails;
            var registrationId = "";
            for (var i = 0; i < assessmentDetails.length; i++) {
                if (assessmentDetails[i].assessmentUserAnswer === '' && assessmentDetails[i].assessmentScore === '') {
                    registrationId = assessmentDetails[i].registrationId;
                }
            }
            res.json({
                success: true,
                message: 'Applicant data found successfully ! ',
                result: registrationId
            });
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Add assessment details to digital Id applicant to DB
app.post('/submitAssessmentData', function (req, res) {
    console.log('Inside Express api check to update digital Id data ! ');
    var name = Date.now();
    getDigitalIdData(req.body.digitalId).then(function (data) {
        if (data.success) {
            var applicantData = data.response.docs[0];
            var assessmentDetails = applicantData.digitalIdInfo.assessmentDetails;
            for (var i = 0; i < assessmentDetails.length; i++) {
                if (assessmentDetails[i].registrationId === req.body.registrationId && assessmentDetails[i].assessmentUserAnswer === '') {
                    assessmentDetails[i].assessmentUserAnswer = req.body.answer.toString();
                    applicantData.digitalIdInfo.assessmentDetails = assessmentDetails;
                    updateCloudantData(applicantData, req.body.chaincodeFunction, req.body.user).then(function (data) {
                        if (data.success) {
                            res.json({
                                success: true,
                                message: 'Applicant data updated successfully !'
                            });
                        } else res.json({
                            success: false,
                            message: 'Applicant data updation issue !'
                        });
                    });
                } else {
                    res.json({
                        success: false,
                        message: 'You cannot submit again as you have already submitted your answers, please wait for your transcript !'
                    });
                }
            }
        } else res.json({
            success: false,
            message: 'Cloudant db connectivity issue !'
        });
    });
});
//Get selected _id details from Block Chain
app.post('/getDataFromBlockChain', function (req, res) {
    console.log('Inside Express api check to get digital Id data : ' + req.body._id);
    getDataFromLedger(req.body._id).then(function (data) {
        if (data.success) res.json({
            success: true,
            message: 'Data fetched successfully !',
            response: data
        });
        else res.json({
            success: false,
            message: 'Data fetching issue from ledger !'
        });
    });
});
//Get explorer on load data
app.post('/explorerLoadData', function (req, res) {
    console.log('Inside express api to get on load data for explorer');
    getChannelData().then(function (data) {
        if (data.success) res.json({
            success: true,
            message: 'Data fetched successfully !',
            response: data
        });
        else res.json({
            success: false,
            message: 'Data fetching issue from swagger-ui !'
        });
    });
});
//Get explorer on load data
app.post('/explorerBlockData', function (req, res) {
    console.log('Inside express api to get on selected block data for explorer');
    getBlockData(req.body.channelHash, req.body.blockNo).then(function (data) {
        if (data.success) res.json({
            success: true,
            message: 'Data fetched successfully !',
            response: data
        });
        else res.json({
            success: false,
            message: 'Data fetching issue from swagger-ui !'
        });
    });
});
//Get explorer on load data
app.post('/explorerTxnData', function (req, res) {
    console.log('Inside express api to get on txn data for explorer');
    getTxnData(req.body.channelHash, req.body.txnId).then(function (data) {
        if (data.success) res.json({
            success: true,
            message: 'Data fetched successfully !',
            response: data
        });
        else res.json({
            success: false,
            message: 'Data fetching issue from swagger-ui !'
        });
    });
});
//Fetch specific digitalId record from cloudant DB
var getDataFromLedger = async (digitalId) => {
    try {
        var allTxnsForId = await query('mychannel', 'digitalId', 'queryAllDetailsForADigitalId', digitalId, 'university');
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log('Applicant data found successfully ! ');
        return ({
            success: true,
            message: 'Applicant data found successfully ! ',
            digitalIdData: digitalIdData,
            txnIds: allTxnsForId
        });
    } catch (err) {
        console.log('Applicant data not present/DB issue ! ' + err);
        return ({
            success: false,
            message: 'Applicant data not present/DB issue !'
        });
    }
}
//Fetch specific digitalId record from cloudant DB
var getDigitalIdData = async (digitalId) => {
    console.log(digitalId);
    try {
        var response = await dbForApplicantData.find({
            selector: {
                _id: digitalId
            }
        });
        console.log('Data from cloudant :' + response);
        var allTxnsForId = await query('mychannel', 'digitalId', 'queryAllDetailsForADigitalId', digitalId, 'university');
        console.log('Data from blockchain :' + allTxnsForId);
        console.log('Applicant data found successfully ! ');
        return ({
            success: true,
            message: 'Applicant data found successfully ! ',
            response: response,
            txnIds: allTxnsForId
        });
    } catch (err) {
        console.log('Applicant data not present/DB issue ! ' + err);
        return ({
            success: false,
            message: 'Applicant data not present/DB issue !'
        });
    }
}

//Fetch specific digitalId record from cloudant DB
var getDigitalIdDataFromCloudant = async (digitalId) => {
    try {
        var response = await dbForApplicantData.find({
            selector: {
                _id: digitalId
            }
        });
        console.log('Applicant data found successfully ! ');
        return ({
            success: true,
            message: 'Applicant data found successfully ! ',
            response: response,
        });
    } catch (err) {
        console.log('Applicant data not present/DB issue ! ' + err);
        return ({
            success: false,
            message: 'Applicant data not present/DB issue !'
        });
    }
}

// Update existence record in cloudant DB
var updateCloudantData = async (data, chaincodeFunction, user) => {
    var invokeResponse = '';
    try {
        if (data.digitalIdStatus.toString().trim() === 'Approved' && user.toString().trim() === 'university' && chaincodeFunction.toString().trim() === 'createStudentRecord') {
            console.log("Student details inserted into ledger !");
            var url = 'http://ec2-52-206-196-6.compute-1.amazonaws.com:8080/student_portal.html';
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'Digital Id Request';
            var mailBody = 'The digital id request has been approved. Your digital id is :<b>' + data.digitalIdInfo.digitalId + '</b>. Please proceed further by submitting your skillsets by clicking on below link.<a href="' + url + '">Click To Proceed</a>';
            invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        } else if (data.skillSetStatus.toString().trim() === 'Approved' && user.toString().trim() === 'university' && chaincodeFunction.toString().trim() === 'addAssessmentDetails') {
            var score = '';
            for (var i = 0; i < data.digitalIdInfo.assessmentDetails.length; i++) {
                if (data.registrationId === data.digitalIdInfo.assessmentDetails[i].registrationId) score = data.digitalIdInfo.assessmentDetails[i].assessmentScore;
            }
            console.log("Updating assessment details into ledger !");
            var url = 'http://ec2-52-206-196-6.compute-1.amazonaws.com:8080/student_portal.html';
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'Skill Assessment - Transcript';
            var mailBody = 'Transcript as per the assessment evaluation is that u got a score of ' + score + ' correct answers . Please proceed further by submitting your university choices by clicking on below link.<a href="' + url + '">Click To Proceed</a>';
            invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        } else if (data.skillSetStatus.toString().trim() === 'Approved' && user.toString().trim() === 'assessment' && chaincodeFunction.toString().trim() === 'sendAssessmentDetails') {
            console.log("Sending assessment link to applicant !");
            var assessmentCode = '';
            for (var i = 0; i < data.digitalIdInfo.assessmentDetails.length; i++) {
                if (data.registrationId === data.digitalIdInfo.assessmentDetails[i].registrationId) assessmentCode = data.digitalIdInfo.assessmentDetails[i].assessmentCode;
            }
            var mailSentTo = data.digitalIdInfo.emailId;
            var mailSubject = 'Skill Assessment';
            var url = 'http://ec2-52-206-196-6.compute-1.amazonaws.com:8080/' + assessmentCode + '.html';
            var mailBody = 'Please take the exam which u can check by clicking the below link with registration id : <b>' + data.digitalIdInfo.assessmentDetails[0].registrationId + '</b> and try submitting the assessment asap for further processing.</br><a href="' + url + '">Click To Proceed</a>';
            invokeResponse = 'No need for ledger data insertion.';
            mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
        } else if (data.universityAdmissionStatus.toString().trim() === 'Approved' && user.toString().trim() === 'university' && chaincodeFunction.toString().trim() === 'addUniveristyDetails') {
            for (var i = 0; i < data.digitalIdInfo.universityDetails.length; i++) {
                if (data.registrationId === data.digitalIdInfo.universityDetails[i].registrationId && data.digitalIdInfo.universityDetails[i].courseEndDate === '') {
                    console.log("Adding university details into ledger !");
                    var mailSentTo = data.digitalIdInfo.emailId;
                    var mailSubject = 'University Request';
                    var mailBody = 'Your university application has been approved, further details will be communicated seperately to you in a mail.';
                    invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
                    mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
                }
            }
        } else if (data.universityAdmissionStatus.toString().trim() === 'Approved' && user.toString().trim() === 'university' && chaincodeFunction.toString().trim() === 'addSemesterDetails') {
            for (var i = 0; i < data.digitalIdInfo.universityDetails.length; i++) {
                if (data.registrationId === data.digitalIdInfo.universityDetails[i].registrationId && data.digitalIdInfo.universityDetails[i].courseEndDate === '') {
                    console.log("Adding semester certificates into ledger !");
                    var mailSentTo = data.digitalIdInfo.emailId;
                    var mailSubject = 'Reg: Semster Certificate';
                    var mailBody = 'Your semester details have added with your profile.';
                    invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
                    mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
                }
            }
        } else if (data.universityAdmissionStatus.toString().trim() === 'Approved' && user.toString().trim() === 'university' && chaincodeFunction.toString().trim() === 'addFinalDegreeDetails') {
            for (var i = 0; i < data.digitalIdInfo.universityDetails.length; i++) {
                if (data.registrationId === data.digitalIdInfo.universityDetails[i].registrationId && data.digitalIdInfo.universityDetails[i].courseEndDate != '') {
                    console.log("Adding cert data into ledger !");
                    data.universityAdmissionStatus = 'Pending';
                    data.skillSetStatus = 'Pending';
                    data.transcriptSent = 'Pending';
                    var mailSentTo = data.digitalIdInfo.emailId;
                    var mailSubject = 'University Request';
                    var mailBody = 'As your course has ended, we have added the course completion certificate to your profile.';
                    invokeResponse = await invoke('digitalId', 'mychannel', user, chaincodeFunction, data.digitalIdInfo);
                    mailResponse = await triggerEmail(mailSentTo, mailSubject, mailBody);
                }
            }
        }
        var response = await dbForApplicantData.insert(data);
        console.log('Applicant data updated successfully ! ');
        return ({
            success: true,
            message: 'Applicant data updated successfully ! ',
            response: invokeResponse
        });
    } catch (err) {
        console.log('Applicant data updation issue ! ' + err);
        return ({
            success: false,
            message: 'Applicant data updation issue !'
        });
    }
}
// Fetch all digital Ids with pending digitalId status from cloudant DB
var digitalIdWithPendingStatus = async () => {
    try {
        var response = await dbForApplicantData.find({
            selector: {
                digitalIdStatus: 'Pending'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            return ({
                success: true,
                message: 'Data found !',
                result: response
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Fetch all digital Ids with pending skillSetStatus status from cloudant DB
var digitalIdWithPendingSkillSetStatus = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                skillSetStatus: 'Pending'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].universityAdmissionStatus === 'Pending' && response.docs[i].transcriptSent === 'Pending') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.assessmentDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.assessmentDetails[j].assessmentUserAnswer === '') finaldigitalIds.push(response.docs[i]);
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Fetch all digital Ids with pending transcript status from cloudant DB
var digitalIdWithPendingTranscriptStatus = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                transcriptSent: 'Pending'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].skillSetStatus === 'Approved' && response.docs[i].universityAdmissionStatus === 'Pending') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.assessmentDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.assessmentDetails[j].assessmentUserAnswer != '' && response.docs[i].digitalIdInfo.assessmentDetails[j].assessmentScore === '') finaldigitalIds.push(response.docs[i]);
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Fetch all digital Ids with pending universityAdmission status from cloudant DB
var digitalIdWithPendingUniversityAdmissionStatus = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                universityAdmissionStatus: 'Pending'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].skillSetStatus === 'Approved' && response.docs[i].transcriptSent === 'Approved') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.universityDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.universityDetails[j].courseStartDate === '' && response.docs[i].digitalIdInfo.universityDetails[j].courseEndDate === '') finaldigitalIds.push(response.docs[i]);
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Fetch all digital Ids with pending universityAdmission status from cloudant DB
var digitalIdWithPendingUniversityAdmissionStatusForSemester = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                universityAdmissionStatus: 'Approved'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].skillSetStatus === 'Approved' && response.docs[i].transcriptSent === 'Approved') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.universityDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.universityDetails[j].courseStartDate != '' && response.docs[i].digitalIdInfo.universityDetails[j].courseEndDate === '') {
                            var numberOfSems = response.docs[i].digitalIdInfo.universityDetails[j].semesterDetails.length;
                            if (numberOfSems == 0 || numberOfSems == 1 || numberOfSems == 2 || numberOfSems == 3)
                                finaldigitalIds.push(response.docs[i]);
                        }
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Fetch all digital Ids with pending course ccompletion status from cloudant DB
var digitalIdWithPendingCourseCompletionStatus = async () => {
    var finaldigitalIds = new Array();
    try {
        var response = await dbForApplicantData.find({
            selector: {
                universityAdmissionStatus: 'Approved'
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('Data found !');
            for (var i = 0; i < response.docs.length; i++) {
                if (response.docs[i].digitalIdStatus === 'Approved' && response.docs[i].skillSetStatus === 'Approved' && response.docs[i].transcriptSent === 'Approved') {
                    for (var j = 0; j < response.docs[i].digitalIdInfo.universityDetails.length; j++) {
                        if (response.docs[i].digitalIdInfo.universityDetails[j].courseStartDate != '' && response.docs[i].digitalIdInfo.universityDetails[j].courseEndDate === '' && !response.docs[i].digitalIdInfo.universityDetails[j].degreeCompleteStatus && response.docs[i].digitalIdInfo.universityDetails[j].semesterDetails.length === 4)
                            finaldigitalIds.push(response.docs[i]);
                    }
                }
            }
            return ({
                success: true,
                message: 'Data found !',
                result: finaldigitalIds
            });
        } else {
            console.log('Data not found !');
            return ({
                success: false,
                message: 'Data not found !'
            });
        }
    } catch (err) {
        console.log('Error finding details from db !' + err);
        return ({
            success: false,
            message: 'Error finding details from db !'
        });
    }
}
// Verify admin login credentials from cloudant DB
var verifyCredentialsFromCloudant = async (username, password) => {
    try {
        var response = await dbForLogin.get(username);
        console.log('Data found in db for the requested username');
        if (response.agentPassword === password) {
            console.log('User verification successful');
            return ({
                success: true,
                message: 'User Authentication Successful !'
            });
        } else {
            console.log('Invalid User name/Password ');
            return ({
                success: false,
                message: 'Invalid User name/Password !'
            });
        }
    } catch (err) {
        console.log('Data not found in db for the requested username !' + err);
        return ({
            success: false,
            message: 'Data not found in db for the requested username !'
        });
    }
}
// Insert data/record in cloudant DB
var insertCloudantData = async (data) => {
    try {
        var response = await dbForApplicantData.find({
            selector: {
                ssn: data.ssn
            }
        });
        if (response && response.docs && response.docs.length > 0) {
            console.log('SSN already exists in DB !');
            return ({
                success: false,
                message: 'SSN already exists in DB !'
            });
        } else {
            console.log('SSN does not exists in DB !');
            var data = await dbForApplicantData.insert(data);
            console.log('Applicant Data Inserted !');
            return ({
                success: true,
                message: 'Applicant Data Inserted Successfully !'
            });
        }
    } catch (err) {
        console.log('Issue fetching/inserting data from DB ! ' + err);
        return ({
            success: false,
            message: 'Issue fetching/inserting data from DB !'
        });
    }
}
// Insert Document in cloudant DB
var insertDocInCloudant = async (data, file, docData) => {
    try {
        var response = await dbForApplicantDocs.insert(docData);
        console.log('Document related data inserted successfully !');
        var body = await dbForApplicantDocs.attachment.insert(response.id, file.originalname, data, file.mimetype, {
            rev: response.rev
        });
        console.log('Document inserted successfully !');
        return ({
            success: true,
            message: 'Document uploaded successfully !'
        });
    } catch (err) {
        console.log('Document related data insertion issue ! ' + err);
        return ({
            success: false,
            message: 'Document related data insertion issue !'
        });
    }
}
// Trigger mail to user/applicant
var triggerEmail = async (receiverEmailId, subject, mailBody) => {
    var transporter = nodemailer.createTransport(smtpTransport({
        service: 'gmail',
        host: 'smtp.gmail.com',
        auth: {
            user: 'studentdigitalid@gmail.com',
            pass: 'ctsadmin'
        }
    }));
    const mailOptions = {
        from: 'studentdigitalid@gmail.com',
        to: receiverEmailId,
        subject: subject,
        html: mailBody
    };
    try {
        var response = await transporter.sendMail(mailOptions);
        console.log('Mail triggered successfully to applicant !');
        return ({
            success: true,
            message: 'Mail triggered successfully to applicant !'
        });
    } catch (err) {
        console.log('Issues triggering mail to applicant ! ' + err);
        return ({
            success: false,
            message: 'Issues triggering mail to applicant ! '
        });
    }
}
//Invoke Hyperledger Fabric Chaincode
var invoke = async (chaincodeId, channelName, userDoingTxn, functionName, arguments) => {
    try {
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);
        const userExists = await wallet.exists(userDoingTxn);
        if (!userExists) {
            console.log('An identity for the user' + userDoingTxn + 'does not exist in the wallet');
            return ({
                success: false,
                message: 'User not registered ! '
            });
        }
        const gateway = new Gateway();
        await gateway.connect(ccp, {
            wallet,
            identity: userDoingTxn,
            discovery: {
                enabled: false
            }
        });
        const network = await gateway.getNetwork(channelName);
        const contract = network.getContract(chaincodeId);
        const result = await contract.submitTransaction(functionName, JSON.stringify(arguments));
        await gateway.disconnect();
        console.log(`Transaction has been evaluated, result is: ${result.toString()}`);
        return ({
            success: true,
            message: 'Txn submitted successfully ! ',
            response: result.toString()
        });
    } catch (error) {
        console.error(`Failed to submit transaction: ${error}`);
        return ({
            success: false,
            message: 'Failed to submit transaction ! '
        });
    }
}
//Query Hyperledger Fabric Chaincode
var query = async (channelName, chaincodeId, functionName, arguments, userDoingTxn) => {
    try {
        const walletPath = path.join(process.cwd(), 'wallet');
        const wallet = new FileSystemWallet(walletPath);
        console.log(`Wallet path: ${walletPath}`);
        const userExists = await wallet.exists(userDoingTxn);
        if (!userExists) {
            console.log('An identity for the user' + userDoingTxn + 'does not exist in the wallet');
            return ({
                success: false,
                message: 'User not registered ! '
            });
        }
        const gateway = new Gateway();
        await gateway.connect(ccp, {
            wallet,
            identity: userDoingTxn,
            discovery: {
                enabled: false
            }
        });
        const network = await gateway.getNetwork(channelName);
        const contract = network.getContract(chaincodeId);
        const result = await contract.evaluateTransaction(functionName, arguments);
        console.log(`Transaction has been evaluated, result is: ${result.toString()}`);
        return ({
            success: true,
            message: 'Queried successfully ! ',
            response: result.toString()
        });
    } catch (error) {
        console.error(`Failed to evaluate transaction: ${error}`);
        return ({
            success: false,
            response: 'No applicant present with this digital id ! '
        });
    }
}
//Get explorer on-load basic data
var getChannelData = async () => {
    try {
        var channelData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/channels/info');
        var channel_genesis_hash = channelData.data.channels[0].channel_genesis_hash;
        var blocks = channelData.data.channels[0].blocks;
        var currentBlockData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/block/' + channel_genesis_hash + '/' + (blocks - 1));
        var txnId = currentBlockData.data.transactions[0].payload.header.channel_header.tx_id;
        var txnData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/transaction/' + channel_genesis_hash + '/' + txnId);
        var chaincodeData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/chaincode/' + channel_genesis_hash);

        console.log("Data fetched succesfully");
        return ({
            success: true,
            message: "Data fetched succesfully",
            channelInfo: channelData.data,
            blockInfo: currentBlockData.data,
            txnInfo: txnData.data,
            chaincodeInfo: chaincodeData.data
        });
    } catch (error) {
        console.log("Basic explorer load data not fetched !");
        console.log(error);
        return ({
            success: false,
            message: "Basic explorer load data not fetched !"
        });
    }
}
//Get block specific data
var getBlockData = async (channel_genesis_hash, blockNumber) => {
    try {
        var currentBlockData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/block/' + channel_genesis_hash + '/' + blockNumber);
        var txnId = currentBlockData.data.transactions[0].payload.header.channel_header.tx_id;
        var txnData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/transaction/' + channel_genesis_hash + '/' + txnId);
        console.log("Data fetched succesfully");
        return ({
            success: true,
            message: "Data fetched succesfully",
            blockInfo: currentBlockData.data,
            txnInfo: txnData.data
        });
    } catch (error) {
        console.log("Block data not fetched !");
        return ({
            success: false,
            message: "Block data not fetched !"
        });
    }
}
//Get block specific data
var getTxnData = async (channel_genesis_hash, txnId) => {
    try {
        var currentTxnData = await axios.get('http://ec2-52-206-196-6.compute-1.amazonaws.com:3000/api/block/' + channel_genesis_hash + '/' + txnId);
        console.log("Data fetched succesfully");
        return ({
            success: true,
            message: "Data fetched succesfully",
            txnInfo: currentTxnData.data
        });
    } catch (error) {
        console.log("Txn data not fetched !");
        return ({
            success: false,
            message: "Txn data not fetched !"
        });
    }
}
/**********************
 * SWAGGER UI DEFINITION
 **********************/
/**
 * @swagger
 * /digitalId:
 *   get:
 *     tags:
 *     - digital_id_data
 *     summary: Get applicant data on the basis of digital Id
 *     description: Get applicant data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: digitalId
 *         description: Fetch applicant data using unique digital id
 *         in: query
 *         required: true
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the applicant details
 *         schema:
 *           type: object
 */
app.get('/digitalId', function (req, res) {
    var digitalId = req.query.digitalId;
    getDigitalIdDataSwagger(digitalId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                payload: JSON.parse(data.response)
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /digitalId:
 *   post:
 *     tags:
 *     - digital_id_data
 *     summary: Post applicant data by generating an unique id as digitalId to blockchain
 *     description: Endpoint for posting a verified applicant data to the blockchain
 *     consumes:
 *       - multipart/form-data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: fullName
 *         description: Applicant name
 *         in: query
 *         required: true
 *         type: string
 *       - name: ssn
 *         description: Applicant ssn
 *         in: query
 *         required: true
 *         type: string
 *       - name: emailId
 *         description: Applicant email id
 *         in: query
 *         required: true
 *         type: string
 *       - name: countrycode
 *         description: Applicant country code
 *         in: query
 *         required: true
 *         type: string
 *       - name: mobileNumber
 *         description: Applicant mobile number
 *         in: query
 *         required: true
 *         type: string
 *       - name: gender
 *         description: Applicant gender(Male/Female)
 *         in: query
 *         required: true
 *         type: string
 *       - name: address
 *         description: Applicant address
 *         in: query
 *         required: true
 *         type: string
 *       - name: dateOfBirth
 *         description: Applicant date of birth(dd/mm/yyyy)
 *         in: query
 *         required: true
 *         type: string
 *       - name: documentDetails
 *         description: Applicant id proof
 *         in: formData
 *         required: true
 *         type: file
 *     responses:
 *       200:
 *         description: A single JSON object containing the transaction id
 *         schema:
 *           type: object
 */
app.post('/digitalId', function (req, res) {
    var uniqueId = Date.now();
    var digitalIdData = {
        digitalId: uniqueId + '',
        fullName: req.query.fullName,
        emailId: req.query.emailId,
        countrycode: req.query.countrycode,
        ssn: req.query.ssn,
        mobileNumber: req.query.mobileNumber,
        gender: req.query.gender,
        address: req.query.address,
        createTimestamp: uniqueId,
        dateOfBirth: req.query.dateOfBirth,
        documentDetails: '',
        universityDetails: [],
        assessmentDetails: [],
        txnMsg: ""
    }
    var form = new multiparty.Form();
    var file = '';
    var imageType = '';
    form.parse(req, function (err, fields, files) {
        file = files.documentDetails[0];
        imageType = 'image/' + file.originalFilename.split('.')[1];
        fs.readFile(file.path, function (err, response) {
            var document = {
                _id: uniqueId + '-IdProof',
                docName: file.originalFilename,
                docType: "Identification Proof",
                digitalId: uniqueId + ''
            };
            digitalIdData.documentDetails = document;
            postDigitalIdData(response, file, digitalIdData, imageType).then(function (data) {
                if (data.success) {
                    res.json({
                        code: 200,
                        txn_Id: data.response,
                        digital_Id: digitalIdData.digitalId
                    })
                } else res.json({
                    code: 500,
                    message: data.message
                });
            });
        });
    });
});
/**
 * @swagger
 * /transcript:
 *   get:
 *     tags:
 *     - transcript_data
 *     summary: Get applicant transcript data on the basis of digital Id and registration Id
 *     description: Get transcript data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: digitalId
 *         description: Digital id of the applicant
 *         in: query
 *         required: true
 *         type: string
 *       - name: registrationId
 *         description: Registration id for the transcript
 *         in: query
 *         required: false
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the transcript details of the applicant
 *         schema:
 *           type: object
 */
app.get('/transcript', function (req, res) {
    var digitalId = req.query.digitalId;
    var registrationId = req.query.registrationId;
    getTranscriptData(digitalId, registrationId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                payload: data.response
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /transcript:
 *   post:
 *     tags:
 *     - transcript_data
 *     summary: Add transcript data to already existing digitalId to blockchain
 *     description: Endpoint for posting transcript data to a valid applicant with the mentioned digital Id to the blockchain
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: digitalId
 *         description: Applicant digital id
 *         in: query
 *         required: true
 *         type: string
 *       - name: skillSet
 *         description: Applicant selected skill set(NODE_JS, JAVA, PYTHON or BIG_DATA)
 *         in: query
 *         required: true
 *         type: string
 *       - name: assessmentScore
 *         description: Applicant assessment score
 *         in: query
 *         required: true
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the transaction id
 *         schema:
 *           type: object
 */
app.post('/transcript', function (req, res) {
    var digitalId = req.query.digitalId;
    var uniqueId = Date.now();
    var assessmentDetails = {
        registrationId: uniqueId + '',
        assessmentUserAnswer: '',
        assessmentCorrectAnswer: '',
        assessmentScore: req.query.assessmentScore,
        digitalId: req.query.digitalId,
        assessmentCode: '',
        skillSet: req.query.skillSet,
        transcriptSent: 'Approved'
    }
    var technicalSkills = [{
        skillset: 'NODE_JS',
        answers: 'a,d,c,c,a',
        assignmentCode: '5cc4478a451c0'
    }, {
        skillset: 'JAVA',
        answers: 'a,b,b,c,a',
        assignmentCode: '5cc4477f7ed4f'
    }, {
        skillset: 'PYTHON',
        answers: 'b,d,b,d,c',
        assignmentCode: '5cc44761701c6'
    }, {
        skillset: 'BIG_DATA',
        answers: 'd,b,a,a,c',
        assignmentCode: '5cc44771dfca0'
    }];
    for (var i = 0; i < technicalSkills.length; i++) {
        if (technicalSkills[i].skillSet === assessmentDetails.skillSet) {
            assessmentDetails.assessmentCode = technicalSkills[i].assignmentCode;
            assessmentDetails.assessmentCorrectAnswer = technicalSkills[i].answers;
        }
    }
    postTranscriptData(assessmentDetails, digitalId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                txn_Id: data.response,
                registrationId: assessmentDetails.registrationId
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /university:
 *   get:
 *     tags:
 *     - university_data
 *     summary: Get applicant univeristy data on the basis of digital Id
 *     description: Get transcript data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: digitalId
 *         description: Digital id of the applicant
 *         in: query
 *         required: true
 *         type: string
 *       - name: registrationId
 *         description: Registration id for the transcript
 *         in: query
 *         required: false
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the univeristy details of the applicant
 *         schema:
 *           type: object
 */
app.get('/university', function (req, res) {
    var digitalId = req.query.digitalId;
    var registrationId = req.query.registrationId;
    getUniversityData(digitalId, registrationId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                payload: data.response
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /university:
 *   post:
 *     tags:
 *     - university_data
 *     summary: Add university data to already existing digitalId to blockchain
 *     description: Endpoint for posting university data to a valid applicant with the mentioned digital Id to the blockchain
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: digitalId
 *         description: Applicant digital id
 *         in: query
 *         required: true
 *         type: string
 *       - name: universityName
 *         description: Applicant selected university name(University College London, University of Chicago, Imperial College London, Massachusetts Institute of Technology)
 *         in: query
 *         required: true
 *         type: string
 *       - name: courseAppliedFor
 *         description: Applicant selected course in university(Ancient History, Computer Science, Microservices)
 *         in: query
 *         required: true
 *         type: string
 *       - name: appliedDegreeType
 *         description: Applicant selected degree type in university(UG, PG)
 *         in: query
 *         required: true
 *         type: string
 *       - name: registrationId
 *         description: Applicant transcript registration id
 *         in: query
 *         required: true
 *         type: string
 *     responses:
 *       200:
 *         description: A single JSON object containing the transaction id
 *         schema:
 *           type: object
 */
app.post('/university', function (req, res) {
    var universityData = {
        universityName: req.query.universityName,
        universityAddress: '',
        universityId: '',
        courseAppliedFor: req.query.courseAppliedFor,
        appliedDegreeType: req.query.appliedDegreeType,
        courseStartDate: '',
        courseEndDate: '',
        degreeCompleteStatus: false,
        digitalId: req.query.digitalId,
        registrationId: req.query.registrationId,
        universityDocument: '',
        semesterDetails: []
    }
    var universityInfo = [{
        universityName: "University College London",
        universityAddress: "United Kingdom",
        universityId: "U-1"
    }, {
        universityName: "University of Chicago",
        universityAddress: "United States",
        universityId: "U-2"
    }, {
        universityName: "Imperial College London",
        universityAddress: "United Kingdom",
        universityId: "U-3"
    }, {
        universityName: "Massachusetts Institute of Technology",
        universityAddress: "United States",
        universityId: "U-4"
    }];
    for (var i = 0; i < universityInfo.length; i++) {
        if (universityInfo[i].universityName === universityData.universityName) {
            universityData.universityAddress = universityInfo[i].universityAddress;
            universityData.universityId = universityInfo[i].universityId;
            universityData.courseStartDate = Date.now() + '';
        }
    }
    postUniversityData(universityData, req.query.digitalId).then(function (data) {
        if (data.success) {
            res.json({
                code: 200,
                txn_Id: data.response
            });
        } else res.json({
            code: 500,
            payload: data.message
        });
    });
});
/**
 * @swagger
 * /semesterWiseCert:
 *   post:
 *     tags:
 *     - certificate_data
 *     summary: Add semester-wise certs to already existing digitalId in blockchain
 *     description: Endpoint for posting semester-wise cert data to a valid applicant with the mentioned digital Id to the blockchain
 *     consumes:
 *       - multipart/form-data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: digitalId
 *         description: Applicant digital id
 *         in: query
 *         required: true
 *         type: string
 *       - name: registrationId
 *         description: Applicant transcript registration id
 *         in: query
 *         required: true
 *         type: string
 *       - name: documentDetails
 *         description: Applicant semester-wise certificate
 *         in: formData
 *         required: true
 *         type: file
 *     responses:
 *       200:
 *         description: A single JSON object containing the transaction id
 *         schema:
 *           type: object
 */
app.post('/semesterWiseCert', function (req, res) {
    var digitalId = req.query.digitalId;
    var registrationId = req.query.registrationId;
    var form = new multiparty.Form();
    var file = '';
    var imageType = '';
    form.parse(req, function (err, fields, files) {
        file = files.documentDetails[0];
        imageType = 'image/' + file.originalFilename.split('.')[1];
        var semesterData = {
            semesterNo: '1',
            semesterDoc: ''
        };
        var document = {
            _id: req.query.digitalId + '-SemesterCert-' + semesterData.semesterNo,
            docName: file.originalFilename,
            docType: 'Semester Certificate',
            digitalId: req.query.digitalId + ''
        };
        fs.readFile(file.path, function (err, response) {
            postSemesterCerts(response, file, digitalId, registrationId, semesterData, document, imageType).then(function (data) {
                if (data.success) {
                    res.json({
                        code: 200,
                        txn_Id: data.response
                    })
                } else res.json({
                    code: 500,
                    message: data.message
                });
            });
        });
    });
});
/**
 * @swagger
 * /finalDegreeCert:
 *   post:
 *     tags:
 *     - certificate_data
 *     summary: Add final course certificate to already existing digitalId to blockchain
 *     description: Endpoint for posting course-end cert data to a valid applicant with the mentioned digital Id to the blockchain
 *     consumes:
 *       - multipart/form-data
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: digitalId
 *         description: Applicant digital id
 *         in: query
 *         required: true
 *         type: string
 *       - name: registrationId
 *         description: Applicant transcript registration id
 *         in: query
 *         required: true
 *         type: string
 *       - name: documentDetails
 *         description: Applicant course-end certificate
 *         in: formData
 *         required: true
 *         type: file
 *     responses:
 *       200:
 *         description: A single JSON object containing the transaction id
 *         schema:
 *           type: object
 */
app.post('/finalDegreeCert', function (req, res) {
    var digitalId = req.query.digitalId;
    var registrationId = req.query.registrationId;
    var form = new multiparty.Form();
    var file = '';
    var imageType = '';
    form.parse(req, function (err, fields, files) {
        file = files.documentDetails[0];
        imageType = 'image/' + file.originalFilename.split('.')[1];
        var document = {
            _id: req.query.digitalId + '-FinalDegreeCert',
            docName: file.originalFilename,
            docType: 'Final Degree Certificate',
            digitalId: req.query.digitalId + ''
        };
        fs.readFile(file.path, function (err, response) {
            postFinalDegreeEndCerts(response, file, digitalId, registrationId, document, imageType).then(function (data) {
                if (data.success) {
                    res.json({
                        code: 200,
                        txn_Id: data.response
                    })
                } else res.json({
                    code: 500,
                    message: data.message
                });
            });
        });
    });
});
/**************************

* SWAGGER ASYNC FUNCTIONS

**************************/
var getDigitalIdDataSwagger = async (digitalId) => {
    console.log(digitalId);
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) return ({
            success: true,
            message: "Data fetched successfully",
            response: digitalIdData.response
        });
        else return ({
            success: false,
            message: response
        });
    } catch (error) {
        console.log("Applicant data not fetched !");
        return ({
            success: false,
            message: "Applicant data not fetched !"
        });
    }
}
var postDigitalIdData = async (bufferData, file, digitalIdData, imageType) => {
    try {
        var response = await dbForApplicantDocs.insert(digitalIdData.documentDetails);
        console.log('Document related data inserted successfully !');
        var body = await dbForApplicantDocs.attachment.insert(response.id, file.originalFilename, bufferData, imageType, {
            rev: response.rev
        });
        console.log('Document inserted successfully !');
        var insertData = await invoke('digitalId', 'mychannel', 'university', 'createStudentRecord', digitalIdData);
        console.log('Data inserted into blockchain succesfully !');
        var mail = await triggerEmail(digitalIdData.emailId, 'Reg: Digital Id Request', 'Your digital id request has been approved. Your digital id is :' + digitalIdData.digitalId);
        console.log('Mail sent succesfully to the applicant !')
        return ({
            success: true,
            response: insertData.response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
var getTranscriptData = async (digitalId, registrationId) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            var transcriptInfo = digitalIdInfo.assessmentDetails;
            var transcriptData = [];
            if (registrationId != undefined) {
                for (var i = 0; i < transcriptInfo.length; i++) {
                    if (transcriptInfo[i].registrationId === registrationId)
                        transcriptData.push(transcriptInfo[i]);
                }
                return ({
                    success: true,
                    message: "Data fetched successfully",
                    response: transcriptData
                });
            } else return ({
                success: true,
                message: "Data fetched successfully",
                response: transcriptInfo
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (error) {
        console.log("Applicant data not fetched !");
        return ({
            success: false,
            message: "Applicant data not fetched !"
        });
    }
}
var postTranscriptData = async (transcriptData, digitalId) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            digitalIdInfo.assessmentDetails.push(transcriptData);
            var insertData = await invoke('digitalId', 'mychannel', 'university', 'addAssessmentDetails', digitalIdInfo);
            console.log('Data inserted into blockchain succesfully !' + insertData);
            var mail = await triggerEmail(digitalIdInfo.emailId, 'Reg: Transcript Details', 'Your assessment details have been approved. Your registration id is :' + transcriptData.registrationId);
            console.log('Mail sent succesfully to the applicant !')
            return ({
                success: true,
                response: insertData.response
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
var getUniversityData = async (digitalId, registrationId) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            var universityInfo = digitalIdInfo.universityDetails;
            var universityData = [];
            if (registrationId != undefined) {
                for (var i = 0; i < universityInfo.length; i++) {
                    if (universityInfo[i].registrationId === registrationId) universityData.push(universityInfo[i]);
                }
                return ({
                    success: true,
                    message: "Data fetched successfully",
                    response: universityData
                });
            } else return ({
                success: true,
                message: "Data fetched successfully",
                response: universityInfo
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (error) {
        console.log("Applicant data not fetched !");
        return ({
            success: false,
            message: "Applicant data not fetched !"
        });
    }
}
var postUniversityData = async (universityData, digitalId) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            digitalIdInfo.universityDetails.push(universityData);
            var insertData = await invoke('digitalId', 'mychannel', 'university', 'addUniveristyDetails', digitalIdInfo);
            console.log('Data inserted into blockchain succesfully !' + insertData);
            var mail = await triggerEmail(digitalIdInfo.emailId, 'Reg: University Details', 'University details has been added against your profile as selected');
            console.log('Mail sent succesfully to the applicant !')
            return ({
                success: true,
                response: insertData.response
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
var postSemesterCerts = async (bufferData, file, digitalId, registrationId, semesterData, document, imageType) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            for (var i = 0; i < digitalIdInfo.universityDetails.length; i++) {
                if (digitalIdInfo.universityDetails[i].registrationId === registrationId) {
                    if (digitalIdInfo.universityDetails[i].semesterDetails.length >= 4) return ({
                        success: false,
                        message: 'All semester certificates have been already uploaded for the applicant !'
                    });
                    else if (digitalIdInfo.universityDetails[i].semesterDetails.length === 0) {
                        semesterData.semesterDoc = document;
                        digitalIdInfo.universityDetails[i].semesterDetails.push(semesterData);
                    } else {
                        for (var j = 0; j < digitalIdInfo.universityDetails[i].semesterDetails.length; j++) {
                            if (digitalIdInfo.universityDetails[i].semesterDetails[j].semesterNo === '1') {
                                semesterData.semesterNo = '2';
                                document._id = digitalId + '-SemesterCert-' + semesterData.semesterNo;
                                semesterData.semesterDoc = document;
                            } else if (digitalIdInfo.universityDetails[i].semesterDetails[j].semesterNo === '2') {
                                semesterData.semesterNo = '3';
                                document._id = digitalId + '-SemesterCert-' + semesterData.semesterNo;
                                semesterData.semesterDoc = document;
                            } else if (digitalIdInfo.universityDetails[i].semesterDetails[j].semesterNo === '3') {
                                semesterData.semesterNo = '4';
                                document._id = digitalId + '-SemesterCert-' + semesterData.semesterNo;
                                semesterData.semesterDoc = document;
                            }
                        }
                        digitalIdInfo.universityDetails[i].semesterDetails.push(semesterData);
                    }
                }
            }
            var response = await dbForApplicantDocs.insert(document);
            console.log('Document related data inserted successfully !');
            var body = await dbForApplicantDocs.attachment.insert(response.id, file.originalFilename, bufferData, imageType, {
                rev: response.rev
            });
            console.log('Document inserted successfully !');
            var insertData = await invoke('digitalId', 'mychannel', 'university', 'addSemesterDetails', digitalIdInfo);
            console.log('Data inserted into blockchain succesfully !');
            var mail = await triggerEmail(digitalIdInfo.emailId, 'Reg: Semester Certs Addition', 'Your semester certs have been updated with your profile.');
            console.log('Mail sent succesfully to the applicant !')
            return ({
                success: true,
                response: insertData.response
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
var postFinalDegreeEndCerts = async (bufferData, file, digitalId, registrationId, document, imageType) => {
    try {
        var digitalIdData = await query('mychannel', 'digitalId', 'queryStudentDetails', digitalId, 'university');
        console.log("Data fetched successfully");
        if (digitalIdData.success) {
            var digitalIdInfo = JSON.parse(digitalIdData.response);
            for (var i = 0; i < digitalIdInfo.universityDetails.length; i++) {
                if (digitalIdInfo.universityDetails[i].registrationId === registrationId) {
                    digitalIdInfo.universityDetails[i].courseEndDate = Date.now() + '';
                    digitalIdInfo.universityDetails[i].universityDocument = document;
                    digitalIdInfo.universityDetails[i].degreeCompleteStatus = true;
                }
            }
            var response = await dbForApplicantDocs.insert(document);
            console.log('Document related data inserted successfully !');
            var body = await dbForApplicantDocs.attachment.insert(response.id, file.originalFilename, bufferData, imageType, {
                rev: response.rev
            });
            console.log('Document inserted successfully !');
            var insertData = await invoke('digitalId', 'mychannel', 'university', 'addFinalDegreeDetails', digitalIdInfo);
            console.log('Data inserted into blockchain succesfully !');
            var mail = await triggerEmail(digitalIdInfo.emailId, 'Reg: Final Degree Cert Addition', 'Your final degree certificate has been updated with your profile.');
            console.log('Mail sent succesfully to the applicant !')
            return ({
                success: true,
                response: insertData.response
            });
        } else return ({
            success: false,
            message: response
        });
    } catch (err) {
        console.log('Issue doing digitalId post call from swagger ui ! ' + err);
        return ({
            success: false,
            message: 'Issue doing digitalId post call from swagger ui ! '
        });
    }
}
app.listen(port);