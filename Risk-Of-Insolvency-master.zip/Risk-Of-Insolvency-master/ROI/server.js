var express = require('express');
var path = require('path');
var fs = require("fs");
var axios = require('axios'); 
var bodyParser = require('body-parser');
var port = process.env.PORT || process.env.VCAP_APP_PORT || '3001';
var nano = require('nano')('http://localhost:'+port);
var app = express();
var multer  = require('multer');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

var upload = multer({dest:__dirname + '/upload'});
var type = upload.single('file');
var headers = {headers : { 'X-Access-Token': 'VApdFa2CheO06XE1E5G4TZr6k339vIWI5l5xeNr1m3VGsWmWkSv1Wpbz0dKp0rNg' } };
app.use('/', express.static(__dirname + '/'));
app.use('/', express.static(__dirname +'/Images'));

/* Server starts with LoginPage.html */
app.get('/', function(req, res) {
    console.log("Open LoginPage.html page");
    res.sendFile(path.join(__dirname + '/LoginPage.html'));
});

/* Txn Function To Add New User/Participant In Network */
app.post('/createUser', type, function(req,res) {
	var cardName = "";
	var userDetails = {
		"$class": "org.roi.CreateUser",
		"user": {
			"$class": "org.roi.User",
			"userId": req.body.userId,
			"name": req.body.name,
			"password": req.body.password,
			"userRole": req.body.userRole
		}
	};
	if(req.body.userRole == "Shipper"){
		cardName = req.body.userRole.toLowerCase()+"@risk-of-insolvency";
	}else if(req.body.userRole == "Forwarder"){
		cardName = req.body.userRole.toLowerCase()+"@risk-of-insolvency";
	}else if(req.body.userRole == "Carrier"){
		cardName = req.body.userRole.toLowerCase()+"@risk-of-insolvency";
	}else if(req.body.userRole == "Bank"){
		cardName = req.body.userRole.toLowerCase()+"@risk-of-insolvency";
	}else if(req.body.userRole == "Consignee"){
		cardName = req.body.userRole.toLowerCase()+"@risk-of-insolvency";
	}
	var url = 'http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.CreateUser';
	submitTxn(cardName, userDetails, headers, url).then(function(data) {
	if(data.success)
		res.json ({success : true, message:"Success", response: data.response});
	else
		res.json ({success : false, message:"Issue Registering User"});
	});
});

/* Verify Logged In User Details */
app.post('/verifyLogin', function(req,res) {
	checkLoginUser(req.body.username).then(function(data) {
	if(data.success && data.response.length > 0 && data.response[0].password == req.body.password && data.response[0].userRole == req.body.role){
		res.json ({success : true, message:"Success", userDetails: data.response});
	}else
		res.json ({success : false, message:"UserId/Password/Role mismatch"});
	});
});

/* Fetching Participants And Consignments Data From Ledger On Page Load */
app.post('/getInitDetails', function(req,res) {
	fetchDetails(req.body.userRole, req.body.userId).then(function(data) {
	if(data.success){
		res.json ({success : true, message:"Success", initLoadData: data.response});
	}else
		res.json ({success : false, message:"For consignment creation atleast 1 partcipant of each role should be registered"});
	});
});

/* Txn Function To Create Consignment */
app.post('/createConsignment', type, function(req,res) {
	var imageAsBase64 = fs.readFileSync(req.file.destination+'/'+req.file.filename, 'base64');
	var consignment = JSON.parse(req.body.consignment.toString());

	fs.unlink(__dirname + '/upload/' + req.file.filename, function(err) {
		if (!err)
			console.log('File deleted!');
		else
			console.log(err);
	});
	consignment.shipperContract.contractData = imageAsBase64;
	var txnData = {
		"$class": "org.roi.CreateConsignment",
		"consignment": consignment
	}
	var url = 'http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.CreateConsignment';
	var cardName = 'shipper@risk-of-insolvency';
	submitTxn(cardName, txnData, headers, url).then(function(data) {
	if(data.success)
		res.json ({success : true, message:"Success", response: data.response});
	else
		res.json ({success : false, message:"Issue inserting data in ledger"});
	});
});


/* Fetching Pending Contracts Depending Upon User Role */
app.post('/pendingContracts', function(req,res) {
	pendingContracts(req.body.userRole, req.body.userId).then(function(data) {
	if(data.success){
		res.json ({success : true, message:"Success", initLoadData: data.response});
	}else
		res.json ({success : false, message:"Issue fetching pending contracts for the user"});
	});
});

/* Fetching Contracts Sent Back For Revision */
app.post('/reviseContracts', function(req,res) {
	reviseContracts(req.body.userRole, req.body.userId).then(function(data) {
	if(data.success){
		res.json ({success : true, message:"Success", initLoadData: data.response});
	}else
		res.json ({success : false, message:"Issue fetching contracts for revision for the user"});
	});
});

/* Txn Function To Update/Create Shipper/Forwarder Contract */
app.post('/updateContract', type, function(req,res) {
	var imageAsBase64 = fs.readFileSync(req.file.destination+'/'+req.file.filename, 'base64');
	var consignment = JSON.parse(req.body.consignment.toString());
	fs.unlink(__dirname + '/upload/' + req.file.filename, function(err) {
		if (!err)
			console.log('File deleted!');
		else
			console.log(err);
	});
	var txnData = {
	  "$class": "org.roi.UpdateContract",
	  "consignment": "resource:org.roi.Consignment#"+consignment.consignmentId,
	  "status": "resource:org.roi.Status#"+consignment.statusId,
	  "contract": "resource:org.roi.Contract#"+consignment.contractId,
	  "contractData": imageAsBase64,
	  "assignedToUserId": consignment.assignedToUserId,
	  "assignedToUserName": consignment.assignedToUserName,
	  "createdByUserRole": consignment.createdByUserRole,
	  "createdByUserId": consignment.createdByUserId,
	  "createdByUserName": consignment.createdByUserName,
	  "contractAmount": consignment.contractAmount,
	  "timeStamp": consignment.timeStamp,
	  "message": consignment.message
	}
	var cardName = consignment.createdByUserRole.toLowerCase()+'@risk-of-insolvency';
	var url = 'http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.UpdateContract';
	submitTxn(cardName, txnData, headers, url).then(function(data) {
	if(data.success)
		res.json ({success : true, message:"Success", response: data.response});
	else
		res.json ({success : false, message:"Issue inserting data in ledger"});
	});
});

/* Txn Function To Update/Create Bill Of Lading */
app.post('/updateBillOfLading', type, function(req,res) {
	var imageAsBase64 = fs.readFileSync(req.file.destination+'/'+req.file.filename, 'base64');
	var txnData = JSON.parse(req.body.consignment.toString());
	txnData.billOfLadingData = imageAsBase64;
	var cardName = 'carrier@risk-of-insolvency';
	fs.unlink(__dirname + '/upload/' + req.file.filename, function(err) {
		if (!err)
			console.log('File deleted!');
		else
			console.log(err);
	});
	var url = 'http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.UpdateBillOfLading';
	submitTxn(cardName, txnData, headers, url).then(function(data) {
	if(data.success)
		res.json ({success : true, message:"Success", response: data.response});
	else
		res.json ({success : false, message:"Issue inserting data in ledger"});
	});
});

/* Txn Function To Update Contract Status */
app.post('/updateContractStatus', function(req,res) {
	var data = JSON.parse(req.body.data);
	var cardName = data.userRoleUpdatingStatus.toLowerCase()+'@risk-of-insolvency';
	var txnData = {
	  "$class": "org.roi.UpdateContractStatus",
	  "consignment": "resource:org.roi.Consignment#"+data.consignmentId,
	  "status": "resource:org.roi.Status#"+data.statusId,
	  "bank": "resource:org.roi.BankData#"+data.bankId,
	  "userRoleUpdatingStatus": data.userRoleUpdatingStatus,
	  "userIdUpdatingStatus": data.userIdUpdatingStatus,
	  "message": data.message,
	  "timeStamp": data.timeStamp,
	  "contractStatus": data.contractStatus,
	  "contractAmount": data.contractAmount
	};
	
	var url = 'http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.UpdateContractStatus';
	submitTxn(cardName, txnData, headers, url).then(function(data) {
	if(data.success)
		res.json ({success : true, message:"Success", response: data.response});
	else
		res.json ({success : false, message:"Issue inserting data in ledger"});
	});
});

/* Txn Function To Update Bill Of Lading Status */
app.post('/updateBillOfLadingStatus', function(req,res) {
	var data = JSON.parse(req.body.data);
	var cardName = data.userRoleUpdatingStatus.toLowerCase()+'@risk-of-insolvency';
	var txnData = {
	  "$class": "org.roi.UpdateBillOfLadingStatus",
	  "consignment": "resource:org.roi.Consignment#"+data.consignment,
	  "status": "resource:org.roi.Status#"+data.status,
	  "bank": "resource:org.roi.BankData#"+data.bank,
	  "userRoleUpdatingStatus": data.userRoleUpdatingStatus,
	  "userIdUpdatingStatus": data.userIdUpdatingStatus,
	  "message": data.message,
	  "timeStamp": data.timeStamp,
	  "userBillOfLadingStatus": data.userBillOfLadingStatus,
	  "finalBillOfLadingStatus": data.finalBillOfLadingStatus,
	  "forwarderContractAmount": data.forwarderContractAmount,
	  "carrierContractAmount": data.carrierContractAmount
	};
	var url = 'http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.UpdateBillOfLadingStatus';
	submitTxn(cardName, txnData, headers, url).then(function(data) {
	if(data.success)
		res.json ({success : true, message:"Success", response: data.response});
	else
		res.json ({success : false, message:"Issue inserting data in ledger"});
	});
});

/* Fetching Consignment Data From Ledger */
app.post('/getConsignmentDetails', function(req,res) {
	getConsignmentDetails(req.body.consignmentId).then(function(data) {
	if(data.success){
		res.json ({success : true, message:"Success", initLoadData: data.response});
	}else
		res.json ({success : false, message:"Issue fetching consignment details for the user"});
	});
});

/* Fetching Pending Bill Of Ladings From Ledger Depending On UserRole and UserId */
app.post('/getPendingBillOfLadings', function(req,res) {
	getPendingBillOfLadings(req.body.userRole, req.body.userId).then(function(data) {
	if(data.success){
		res.json ({success : true, message:"Success", initLoadData: data.response});
	}else
		res.json ({success : false, message:"Issue fetching bill of ladings for the user"});
	});
});

/* Fetching All Consignment Details */
app.post('/getAllConsignment', function(req,res) {
	getAllConsignmentDetails().then(function(data) {
	if(data.success){
		res.json ({success : true, message:"Success", initLoadData: data.response});
	}else
		res.json ({success : false, message:"Issue fetching consignment details for bank"});
	});
});

var changeComposerCard = async (cardName, headers) => {
  try {
    var response = await axios.post('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/wallet/'+cardName+'/setDefault', '', headers);
	console.log("Composer card changed successfully");
	return ({success : true, message:"Composer card changed successfully", response:response});
  } catch (error) {
	console.log("Issue changing composer card");
	return ({success : false, message:"Issue changing composer card"});
  }
}

var submitTxn = async (cardName, txnDetails, headers, url) => {
  var composerCardChangeStatus = await changeComposerCard(cardName, headers);
  if(composerCardChangeStatus.response.status == "204" && composerCardChangeStatus.success){
	try{
	var response = await axios.post(url, txnDetails, headers);
	console.log("Record inserted successfully");
	return ({success : true, message:"Record inserted successfully", response:response.data});
	} catch (error){
		console.log("Issue inserting record into ledger");
		return ({success : false, message:"Issue inserting record into ledger"});
	}
  }else{
	console.log("Issue changing card while txn");
	return ({success : false, message:"Issue changing card while txn"});	  
  }
}

var fetchDetails = async (userRole, userId) => {
	var response = { };
	var forwarders, carriers, banks, consignees, consignments = [];
	try{		
		if(userRole == "Shipper"){
			var allForwarders = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.User?filter[where][userRole]=Forwarder', headers);
			
			var allBanks = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.User?filter[where][userRole]=Bank', headers);
			
			var allConsignees = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.User?filter[where][userRole]=Consignee', headers);
			
			response = {forwarders:JSON.stringify(allForwarders.data), banks:JSON.stringify(allBanks.data), consignees:JSON.stringify(allConsignees.data)};
		}else if(userRole == "Forwarder"){
			var allCarriers = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.User?filter[where][userRole]=Carrier', headers);
				
			var finalConsignments = new Array();
			var allConsignments = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.Consignment', headers);
			if(allConsignments.data.length > 0){
				for(var i=0; i <allConsignments.data.length; i++){
					if(allConsignments.data[i].shipperContract.assignedToUserId == userId && allConsignments.data[i].status.forwarderApprovedContract == "Approved"){
						finalConsignments.push(allConsignments.data[i]);
					}
				}
			}

			response = {carriers: JSON.stringify(allCarriers.data), consignments: JSON.stringify(finalConsignments)}
		}else if(userRole == "Carrier"){
			var finalConsignments = new Array();
			var allConsignments = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.Consignment', headers);
			if(allConsignments.data.length > 0){
				for(var i=0; i <allConsignments.data.length; i++){
					if(allConsignments.data[i].forwarderContract.assignedToUserId == userId && allConsignments.data[i].status.carrierApprovedContract == "Approved"){
						finalConsignments.push(allConsignments.data[i]);
					}
				}
			}

			response = {consignments: JSON.stringify(finalConsignments)}
		}
		return ({success : true, message:"Sending data to page load", response:response});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var checkLoginUser = async (userId) => {
	try{
		var loggedInUser = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.User?filter[where][userId]='+userId, headers);
		console.log("Data fetched successfully");
		return ({success : true, message:"Checking logged in user details", response:loggedInUser.data});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var pendingContracts = async (userRole, userId) => {
	try{
		var finalConsignments = new Array();
		var allConsignments = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.Consignment', headers);
		if(allConsignments.data.length > 0){
			for(var i=0; i <allConsignments.data.length; i++){
				if(userRole == "Forwarder" && allConsignments.data[i].shipperContract.assignedToUserId == userId && allConsignments.data[i].status.forwarderApprovedContract == "Pending"){
					finalConsignments.push(allConsignments.data[i]);
				}else if(userRole == "Carrier" && allConsignments.data[i].forwarderContract.assignedToUserId == userId && allConsignments.data[i].status.carrierApprovedContract == "Pending"){
					finalConsignments.push(allConsignments.data[i]);
				}
			}
		}
		console.log("Data fetched successfully");
		return ({success : true, message:"Data fetched successfully", response:JSON.stringify(finalConsignments)});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var reviseContracts = async (userRole, userId) => {
	try{
		var finalConsignments = new Array();
		var allConsignments = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.Consignment', headers);
		if(allConsignments.data.length > 0){
			for(var i=0; i <allConsignments.data.length; i++){
				if(userRole == "Forwarder" && allConsignments.data[i].forwarderContract.createdByUserId == userId && allConsignments.data[i].status.carrierApprovedContract == "Revise"){
					finalConsignments.push(allConsignments.data[i]);
				}else if(userRole == "Shipper" && allConsignments.data[i].shipperContract.createdByUserId == userId && allConsignments.data[i].status.forwarderApprovedContract == "Revise"){
					finalConsignments.push(allConsignments.data[i]);
				}
			}
		}
		console.log("Data fetched successfully");
		return ({success : true, message:"Data fetched successfully", response:JSON.stringify(finalConsignments)});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var getConsignmentDetails = async (consignmentId) => {
	try{
		var consignmentData = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.Consignment?filter[where][consignmentId]='+consignmentId, headers);
		console.log("Data fetched successfully");
		return ({success : true, message:"Data fetched successfully", response:JSON.stringify(consignmentData.data[0])});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var getAllConsignmentDetails = async () => {
	try{
		var consignmentData = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.Consignment', headers);
		console.log("Data fetched successfully");
		return ({success : true, message:"Data fetched successfully", response:JSON.stringify(consignmentData.data)});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

var getPendingBillOfLadings = async (userRole, userId) => {
	var finalBillOfLadings = new Array();
	try{
		var allConsignments = await axios.get('http://ec2-13-232-73-187.ap-south-1.compute.amazonaws.com:8080/api/org.roi.Consignment', headers);
		if(allConsignments.data.length > 0){
			for(var i=0; i<allConsignments.data.length; i++){
				if(userRole == "Shipper" && allConsignments.data[i].billOfLading.shipperId == userId && allConsignments.data[i].status.shipperBillOfLadingStatus == "Pending"){
					finalBillOfLadings.push(allConsignments.data[i]);
				}else if(userRole == "Forwarder" && allConsignments.data[i].billOfLading.forwarderId == userId && allConsignments.data[i].status.forwarderBillOfLadingStatus == "Pending"){
					finalBillOfLadings.push(allConsignments.data[i]);
				}else if(userRole == "Bank" && allConsignments.data[i].billOfLading.bankId == userId && allConsignments.data[i].status.bankBillOfLadingStatus == "Pending"){
					finalBillOfLadings.push(allConsignments.data[i]);
				}
			}
		}
		console.log("Data fetched successfully");
		return ({success : true, message:"Data fetched successfully", response:JSON.stringify(finalBillOfLadings)});
	} catch (error){
		console.log("Data not fetched");
		return ({success : false, message:"Data not fetched"});
	}
}

app.listen(port);
