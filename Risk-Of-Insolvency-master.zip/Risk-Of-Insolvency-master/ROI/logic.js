/**
 * Create CreateUser
 * @param {org.roi.CreateUser} userData
 * @transaction
 */
async function transactionCreateUser(userData) {
    var registry = await getParticipantRegistry('org.roi.User');
    var factory = getFactory();

    var newRecord = factory.newResource('org.roi', 'User', userData.user.userId);
    newRecord.name = userData.user.name;
    newRecord.password = userData.user.password;
    newRecord.userRole = userData.user.userRole;

    await registry.add(newRecord);
}

/**
 * Create CreateConsignment
 * @param {org.roi.CreateConsignment} consignment
 * @transaction
 */
async function transactionCreateConsignment(consignment) {

    var consignmentRegistry = await getAssetRegistry('org.roi.Consignment');
    var goodsRegistry = await getAssetRegistry('org.roi.Goods');
    var bankRegistry = await getAssetRegistry('org.roi.BankData');
    var contractRegistry = await getAssetRegistry('org.roi.Contract');
    var billOfLadingRegistry = await getAssetRegistry('org.roi.BillOfLading');
    var statusRegistry = await getAssetRegistry('org.roi.Status');

    var factory = getFactory();

    var newConsignment = factory.newResource('org.roi', 'Consignment', consignment.consignment.consignmentId);
    newConsignment.consignmentCreationTimeStamp = consignment.consignment.consignmentCreationTimeStamp;
    newConsignment.consigneeId = consignment.consignment.consigneeId;
    newConsignment.consignmentType = consignment.consignment.consignmentType;

    var newGoods = factory.newResource('org.roi', 'Goods', consignment.consignment.goods.goodsId);
    newGoods.goodsType = consignment.consignment.goods.goodsType;
    newGoods.label = consignment.consignment.goods.label;
    newGoods.quantity = consignment.consignment.goods.quantity;
    newGoods.mfgDate = consignment.consignment.goods.mfgDate;
    newGoods.consignmentId = consignment.consignment.goods.consignmentId;

    await goodsRegistry.add(newGoods);


    var newBank = factory.newResource('org.roi', 'BankData', consignment.consignment.bank.bankConsignmentId);
    newBank.bankId = consignment.consignment.bank.bankId;
    newBank.bankName = consignment.consignment.bank.bankName;
    newBank.shipperId = consignment.consignment.bank.shipperId;
    newBank.amountDepositedByShipper = consignment.consignment.bank.amountDepositedByShipper;
    newBank.forwarderId = consignment.consignment.bank.forwarderId;
    newBank.amountDepositedToForwarder = consignment.consignment.bank.amountDepositedToForwarder;
    newBank.carrierId = consignment.consignment.bank.carrierId;
    newBank.amountDepositedToCarrier = consignment.consignment.bank.amountDepositedToCarrier;
    newBank.consignmentId = consignment.consignment.bank.consignmentId;

    await bankRegistry.add(newBank);


    var newShipperContract = factory.newResource('org.roi', 'Contract', consignment.consignment.shipperContract.contractId);
    newShipperContract.contractData = consignment.consignment.shipperContract.contractData;
    newShipperContract.createdByUserId = consignment.consignment.shipperContract.createdByUserId;
    newShipperContract.createdByUserName = consignment.consignment.shipperContract.createdByUserName;
    newShipperContract.createdByUserRole = consignment.consignment.shipperContract.createdByUserRole;
    newShipperContract.assignedToUserId = consignment.consignment.shipperContract.assignedToUserId;
    newShipperContract.assignedToUserName = consignment.consignment.shipperContract.assignedToUserName;
    newShipperContract.assignedToRole = consignment.consignment.shipperContract.assignedToRole;
    newShipperContract.consignmentId = consignment.consignment.shipperContract.consignmentId;
    newShipperContract.contractAmount = consignment.consignment.shipperContract.contractAmount;
    newShipperContract.contractCreationTimeStamp = consignment.consignment.shipperContract.contractCreationTimeStamp;
    newShipperContract.contractUpdationTimestamp = consignment.consignment.shipperContract.contractUpdationTimestamp;

    await contractRegistry.add(newShipperContract);


    var newForwarderContract = factory.newResource('org.roi', 'Contract', consignment.consignment.forwarderContract.contractId);
    newForwarderContract.contractData = consignment.consignment.forwarderContract.contractData;
    newForwarderContract.createdByUserId = consignment.consignment.forwarderContract.createdByUserId;
    newForwarderContract.createdByUserName = consignment.consignment.forwarderContract.createdByUserName;
    newForwarderContract.createdByUserRole = consignment.consignment.forwarderContract.createdByUserRole;
    newForwarderContract.assignedToUserId = consignment.consignment.forwarderContract.assignedToUserId;
    newForwarderContract.assignedToUserName = consignment.consignment.forwarderContract.assignedToUserName;
    newForwarderContract.assignedToRole = consignment.consignment.forwarderContract.assignedToRole;
    newForwarderContract.consignmentId = consignment.consignment.forwarderContract.consignmentId;
    newForwarderContract.contractAmount = consignment.consignment.forwarderContract.contractAmount;
    newForwarderContract.contractCreationTimeStamp = consignment.consignment.forwarderContract.contractCreationTimeStamp;
    newForwarderContract.contractUpdationTimestamp = consignment.consignment.forwarderContract.contractUpdationTimestamp;

    await contractRegistry.add(newForwarderContract);


    var newBillOfLading = factory.newResource('org.roi', 'BillOfLading', consignment.consignment.billOfLading.billOfLadingId);
    newBillOfLading.billOfLadingData = consignment.consignment.billOfLading.billOfLadingData;
    newBillOfLading.carrierId = consignment.consignment.billOfLading.carrierId;
    newBillOfLading.carrierContractAmount = consignment.consignment.billOfLading.carrierContractAmount;
    newBillOfLading.shipperId = consignment.consignment.billOfLading.shipperId;
    newBillOfLading.forwarderId = consignment.consignment.billOfLading.forwarderId;
    newBillOfLading.forwarderContractAmount = consignment.consignment.billOfLading.forwarderContractAmount;
    newBillOfLading.bankId = consignment.consignment.billOfLading.bankId;
    newBillOfLading.consignmentId = consignment.consignment.billOfLading.consignmentId;
    newBillOfLading.billOfLadingCreationTimeStamp = consignment.consignment.billOfLading.billOfLadingCreationTimeStamp;
    newBillOfLading.billOfLadingUpdationTimeStamp = consignment.consignment.billOfLading.billOfLadingUpdationTimeStamp;

    await billOfLadingRegistry.add(newBillOfLading);


    var newStatus = factory.newResource('org.roi', 'Status', consignment.consignment.status.statusId);
    newStatus.forwarderApprovedContract = consignment.consignment.status.forwarderApprovedContract;
    newStatus.carrierApprovedContract = consignment.consignment.status.carrierApprovedContract;
    newStatus.shipperBillOfLadingStatus = consignment.consignment.status.shipperBillOfLadingStatus;
    newStatus.forwarderBillOfLadingStatus = consignment.consignment.status.forwarderBillOfLadingStatus;
    newStatus.bankBillOfLadingStatus = consignment.consignment.status.bankBillOfLadingStatus;
    newStatus.finalBillOfLadingStatus = consignment.consignment.status.finalBillOfLadingStatus;
    newStatus.consignmentId = consignment.consignment.status.consignmentId;
    newStatus.consignmentStatus = consignment.consignment.status.consignmentStatus;
    newStatus.consignmentMessage = consignment.consignment.status.consignmentMessage;
    newStatus.statusCreationTimeStamp = consignment.consignment.status.statusCreationTimeStamp;
    newStatus.statusUpdationTimeStamp = consignment.consignment.status.statusUpdationTimeStamp;

    await statusRegistry.add(newStatus);


    newConsignment.goods = newGoods;
    newConsignment.bank = newBank;
    newConsignment.shipperContract = newShipperContract;
    newConsignment.forwarderContract = newForwarderContract;
    newConsignment.billOfLading = newBillOfLading;
    newConsignment.status = newStatus;

    await consignmentRegistry.add(newConsignment);
}

/**
 * Create UpdateContractStatus
 * @param {org.roi.UpdateContractStatus} contractStatus
 * @transaction
 */
async function transactionUpdateContractStatus(contractStatus) {

    var statusRegistry = await getAssetRegistry('org.roi.Status');
    var bankRegistry = await getAssetRegistry('org.roi.BankData');
    var consignmentRegistry = await getAssetRegistry('org.roi.Consignment');

    if (contractStatus.userRoleUpdatingStatus == "Forwarder") {
        contractStatus.status.forwarderApprovedContract = contractStatus.contractStatus;
    }

    if (contractStatus.userRoleUpdatingStatus == "Carrier") {
        contractStatus.status.carrierApprovedContract = contractStatus.contractStatus;
    }

    contractStatus.status.consignmentMessage = contractStatus.message;
    contractStatus.status.statusUpdationTimeStamp = contractStatus.timeStamp;

    await statusRegistry.update(contractStatus.status);

    if (contractStatus.userRoleUpdatingStatus == "Forwarder" && contractStatus.contractStatus == "Approved") {
        contractStatus.bank.forwarderId = contractStatus.userIdUpdatingStatus;
        contractStatus.bank.amountDepositedByShipper = contractStatus.contractAmount;
    }

    if (contractStatus.userRoleUpdatingStatus == "Carrier" && contractStatus.contractStatus == "Approved") {
        contractStatus.bank.carrierId = contractStatus.userIdUpdatingStatus;
    }

    await bankRegistry.update(contractStatus.bank);

    contractStatus.consignment.status = contractStatus.status;
    contractStatus.consignment.bank = contractStatus.bank;

    await consignmentRegistry.update(contractStatus.consignment);
}

/**
 * Create UpdateBillOfLadingStatus
 * @param {org.roi.UpdateBillOfLadingStatus} billOfLadingStatus
 * @transaction
 */
async function transactionUpdateBillOfLadingStatus(billOfLadingStatus) {

    var statusRegistry = await getAssetRegistry('org.roi.Status');
    var bankRegistry = await getAssetRegistry('org.roi.BankData');
    var consignmentRegistry = await getAssetRegistry('org.roi.Consignment');

    if (billOfLadingStatus.userRoleUpdatingStatus == "Forwarder") {
        billOfLadingStatus.status.forwarderBillOfLadingStatus = billOfLadingStatus.userBillOfLadingStatus;
    }

    if (billOfLadingStatus.userRoleUpdatingStatus == "Shipper") {
        billOfLadingStatus.status.shipperBillOfLadingStatus = billOfLadingStatus.userBillOfLadingStatus;
    }

    if (billOfLadingStatus.userRoleUpdatingStatus == "Bank") {
        billOfLadingStatus.status.bankBillOfLadingStatus = billOfLadingStatus.userBillOfLadingStatus;
    }

    if (billOfLadingStatus.finalBillOfLadingStatus == "Approved" && billOfLadingStatus.userRoleUpdatingStatus == "Consignee") {
        billOfLadingStatus.status.consignmentStatus = "Received";
    }

    billOfLadingStatus.status.finalBillOfLadingStatus = billOfLadingStatus.finalBillOfLadingStatus;
    billOfLadingStatus.status.consignmentMessage = billOfLadingStatus.message;
    billOfLadingStatus.status.statusUpdationTimeStamp = billOfLadingStatus.timeStamp;

    await statusRegistry.update(billOfLadingStatus.status);

    if (billOfLadingStatus.finalBillOfLadingStatus == "Approved" && billOfLadingStatus.consignment.consignmentType == "Prepaid") {
        billOfLadingStatus.bank.amountDepositedToForwarder = billOfLadingStatus.consignment.shipperContract.contractAmount - billOfLadingStatus.carrierContractAmount;
        billOfLadingStatus.bank.amountDepositedToCarrier = billOfLadingStatus.carrierContractAmount;
    } else if (billOfLadingStatus.finalBillOfLadingStatus == "Approved" && billOfLadingStatus.consignment.consignmentType == "Postpaid" && billOfLadingStatus.userRoleUpdatingStatus == "Consignee") {
        billOfLadingStatus.bank.amountDepositedToForwarder = billOfLadingStatus.consignment.shipperContract.contractAmount - billOfLadingStatus.carrierContractAmount;
        billOfLadingStatus.bank.amountDepositedToCarrier = billOfLadingStatus.carrierContractAmount;
    }

    await bankRegistry.update(billOfLadingStatus.bank);

    billOfLadingStatus.consignment.status = billOfLadingStatus.status;
    billOfLadingStatus.consignment.bank = billOfLadingStatus.bank;

    await consignmentRegistry.update(billOfLadingStatus.consignment);
}

/**
 * Create UpdateContracts
 * @param {org.roi.UpdateContract} contractData
 * @transaction
 */
async function transactionUpdateContract(contractData) {

    var statusRegistry = await getAssetRegistry('org.roi.Status');
    var contractRegistry = await getAssetRegistry('org.roi.Contract');
    var consignmentRegistry = await getAssetRegistry('org.roi.Consignment');

    contractData.contract.contractData = contractData.contractData;
    contractData.contract.assignedToUserId = contractData.assignedToUserId;
    contractData.contract.assignedToUserName = contractData.assignedToUserName;
    contractData.contract.contractAmount = contractData.contractAmount;
    contractData.contract.createdByUserId = contractData.createdByUserId;
    contractData.contract.createdByUserName = contractData.createdByUserName;
    contractData.contract.createdByUserRole = contractData.createdByUserRole;

    if (contractData.contract.contractCreationTimeStamp == "") {
        contractData.contract.contractCreationTimeStamp = contractData.timeStamp;
    }
    contractData.contract.contractUpdationTimestamp = contractData.timeStamp;

    if (contractData.createdByUserRole == "Shipper") {
        contractData.contract.assignedToRole = "Forwarder";
    }

    if (contractData.createdByUserRole == "Forwarder") {
        contractData.contract.assignedToRole = "Carrier";
    }

    await contractRegistry.update(contractData.contract);

    contractData.status.consignmentMessage = contractData.message;
    contractData.status.statusUpdationTimeStamp = contractData.timeStamp;

    await statusRegistry.update(contractData.status);

    if (contractData.createdByUserRole == "Shipper") {
        contractData.consignment.shipperContract = contractData.contract;
        contractData.consignment.status = contractData.status;
        await consignmentRegistry.update(contractData.consignment);
    }

    if (contractData.createdByUserRole == "Forwarder") {
        contractData.consignment.forwarderContract = contractData.contract;
        contractData.consignment.status = contractData.status;
        await consignmentRegistry.update(contractData.consignment);
    }
}

/**
 * Create UpdateBillOfLading
 * @param {org.roi.UpdateBillOfLading} billOfLadingData
 * @transaction
 */
async function transactionUpdateBillOfLading(billOfLadingData) {

    var billOfLadingRegistry = await getAssetRegistry('org.roi.BillOfLading');
    var statusRegistry = await getAssetRegistry('org.roi.Status');
    var consignmentRegistry = await getAssetRegistry('org.roi.Consignment');

    billOfLadingData.billOfLading.billOfLadingData = billOfLadingData.billOfLadingData;
    billOfLadingData.billOfLading.carrierId = billOfLadingData.carrierId;
    billOfLadingData.billOfLading.carrierContractAmount = billOfLadingData.carrierContractAmount;
    billOfLadingData.billOfLading.shipperId = billOfLadingData.shipperId;
    billOfLadingData.billOfLading.forwarderId = billOfLadingData.forwarderId;
    billOfLadingData.billOfLading.forwarderContractAmount = billOfLadingData.forwarderContractAmount;
    billOfLadingData.billOfLading.bankId = billOfLadingData.bankId;
    if (billOfLadingData.billOfLading.billOfLadingCreationTimeStamp == "") {
        billOfLadingData.billOfLading.billOfLadingCreationTimeStamp = billOfLadingData.timeStamp;
    }
    billOfLadingData.billOfLading.billOfLadingUpdationTimeStamp = billOfLadingData.timeStamp;

    await billOfLadingRegistry.update(billOfLadingData.billOfLading);

    billOfLadingData.status.consignmentMessage = billOfLadingData.message;

    await statusRegistry.update(billOfLadingData.status);

    billOfLadingData.consignment.billOfLading = billOfLadingData.billOfLading;
    billOfLadingData.consignment.status = billOfLadingData.status;

    await consignmentRegistry.update(billOfLadingData.consignment);
}