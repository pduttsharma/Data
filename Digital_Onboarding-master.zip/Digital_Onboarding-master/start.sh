#!/bin/bash
#
# Copyright IBM Corp All Rights Reserved
#
# SPDX-License-Identifier: Apache-2.0
#
# Exit on first error, print all commands.
set -ev


docker-compose -f docker-compose.yml down

export COMPOSE_PROJECT_NAME="net"

docker-compose -f docker-compose.yml up -d

# wait for Hyperledger Fabric to start
# incase of errors when running later commands, issue export 
# FABRIC_START_TIMEOUT=<larger number>

export FABRIC_CFG_PATH=$PWD

export FABRIC_START_TIMEOUT=15

#echo ${FABRIC_START_TIMEOUT}

sleep ${FABRIC_START_TIMEOUT}

# Create the channel
docker exec -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@student.cts.com/msp" peer0.student.cts.com peer channel create -o orderer.cts.com:7050 -c mychannel -f /etc/hyperledger/configtx/channel.tx

# Join peer0.student.cts.com to the channel.
docker exec -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@student.cts.com/msp" peer0.student.cts.com peer channel join -b mychannel.block

# fetch the genesis block for joining 2nd peer to channel

docker exec -e "CORE_PEER_LOCALMSPID=Org2MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@university.cts.com/msp" peer0.university.cts.com peer channel fetch 0 mychannel.block -o orderer.cts.com:7050 -c mychannel

# join second peer to channel
docker exec -e "CORE_PEER_LOCALMSPID=Org2MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@university.cts.com/msp" peer0.university.cts.com peer channel join -b mychannel.block

# Install chain code on the channel
docker exec -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/student.cts.com/users/Admin@student.cts.com/msp" cli peer chaincode install -l node -n chaincode -p /tmp/chaincode/student -v 2.0


# Instantiate chain code on the channel with a sample record for unit testing
docker exec -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/student.cts.com/users/Admin@student.cts.com/msp" cli peer chaincode instantiate -o orderer.cts.com:7050 -C mychannel -l node -n chaincode -v 2.0 -c '{"Args":["Init"]}' -P "OR ('Org1MSP.member','Org2MSP.member')"

sleep 10

# Sample query to test instantiated record query from ledger
docker exec -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/student.cts.com/users/Admin@student.cts.com/msp" cli peer chaincode invoke -o orderer.cts.com:7050 -C mychannel -n chaincode -c '{"function":"queryStudentDetails","Args":["123"]}'
