var express = require('express');
var path = require('path');
var fs = require("fs");
var bodyParser = require('body-parser');
var port = process.env.PORT || process.env.VCAP_APP_PORT || '8083';
var nano = require('nano')('http://localhost:'+port);var app = express();
var multer = require('multer');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));

var upload = multer({
    dest: __dirname + '/upload'
});
var type = upload.single('file');

app.use('/', express.static(__dirname + '/'));
app.use('/', express.static(__dirname + '/Images'));

var cloudantUserName = "97db821e-87a4-4507-b8ee-fcc95b72b447-bluemix";
var cloudantPassword = "ae34609f865eac5720a3e08c9c0208840a9418090a98f9a4c1fcb9fa5573040b";
var dbCredentials_url = "https://" + cloudantUserName + ":" + cloudantPassword + "@" + cloudantUserName + ".cloudant.com"; // Set this to your own account

// Initialize the library with my account.
var cloudant = require('cloudant')(dbCredentials_url);

var dbForLogin = cloudant.db.use("logindetails");
var dbForStudentUniversityData = cloudant.db.use("studentuniversitydata");
var dbForAdminUniversityRequestTable = cloudant.db.use("adminuniversityrequesttable");


// viewed at http://localhost:8080
app.get('/', function(req, res) {
    console.log("Open LoginPage.html page");
    res.sendFile(path.join(__dirname + '/LoginPage.html'));
});

app.post('/loginData', function(req, res) {
    console.log("Got a POST request for LoginPage.html page");
    var response = "";
    var userName = req.body.username;
    var password = req.body.password;
    dbForLogin.get(userName, function(err, body) {
        if (!err) {
            var dbPassword = body.agentPassword;
            if (dbPassword === password) {
                response = {
                    status: 200,
                    message: 'Success'
                }
            } else {
                response = {
                    status: 300,
                    message: 'Username and Password does not match'
                }
            }
        } else {
            console.log(err);
            response = {
                status: 400,
                message: 'Username does not exists'
            }
        }
        res.send(JSON.stringify(response));
    });
});



app.post('/studentData', function(req, res) {
    console.log("Got a POST request for UniversityData.html page");
    var response = "";
    var requestId = "RE0";
    var studentData = JSON.parse(JSON.stringify(req.body));
    dbForAdminUniversityRequestTable.list(function(err, body) {
        if (!err) {
            console.log(body);
            body.rows.forEach(function(doc) {
                requestId = doc.id;
            });
        }
        requestId = requestId.replace(/(\d+)/, function() {
            return arguments[1] * 1 + 1
        });
        var requestDetails = {
            requestDate: new Date().toJSON().slice(0, 10).replace(/-/g, '/'),
            applicantName: studentData.name,
            status: 'Applied',
            digitalId: studentData.digitalId,
            digitalIdVerified: 'No',
            appliedFor: studentData.applyingFor
        }
        dbForStudentUniversityData.insert(studentData, function(err, body) {
            if (!err) {
                dbForAdminUniversityRequestTable.insert(requestDetails, requestId, function(err, body) {
                    if (!err) {
                        console.log("Data inserted in admin request table.");
                    } else {
                        response = {
                            status: 100,
                            message: 'Data not inserted successfully in admin request table.'
                        }
                    }
                });
                response = {
                    status: 200,
                    message: 'Data inserted successfully in applicant data table.',
                    id: body.id,
                    revid: body.rev
                }
            } else {
                response = {
                    status: 300,
                    message: 'Data not inserted successfully in applicant data table.'
                }
            }
            res.send(JSON.stringify(response));
        });
    });
});

app.post('/studentDoc', type, function(req, res) {
    console.log("Got a POST request for UniversityData.html page");
    var response = "";
    fs.readFile(__dirname + '/upload/' + req.file.filename, function(err, data) {
        if (!err) {
            dbForStudentUniversityData.attachment.insert(req.body.id, req.file.originalname, data, req.file.mimetype, {
                rev: req.body.rev
            }, function(err, body) {
                if (!err) {
                    fs.unlink(__dirname + '/upload/' + req.file.filename, function(err) {
                        if (!err)
                            console.log('File deleted!');
                        else
                            console.log(err);
                    });
                    response = {
                        status: 200,
                        message: 'Document uploaded successfully in applicant data table.'
                    }
                } else {
                    response = {
                        status: 300,
                        message: 'Document not uploaded successfully in applicant data table.'
                    }
                }
                res.send(JSON.stringify(response));
            });
        }
    });
});
app.listen(port);
