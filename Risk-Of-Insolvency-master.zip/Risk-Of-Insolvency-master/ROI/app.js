var myApp = angular.module("myModule", []);

myApp.directive('fileModel', ['$parse', function($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function() {
                scope.$apply(function() {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

myApp.service('fileUpload', ['$http', function($http) {
    this.uploadFileAndFieldsToUrl = function(file, fields, uploadUrl) {
        var fd = new FormData();
		fd.append('consignment', JSON.stringify(fields));
        fd.append('file', file);
		
        $http({
            method: 'POST',
            url: uploadUrl,
            data: fd,
            transformRequest: angular.identity,
            headers: {
                'Content-Type': undefined
            }
        }).then(function successCallback(response) {
            if (response.data.success) {
				if(uploadUrl == "/createConsignment"){
					window.location.href = '/Shipper.html';
				}else if(uploadUrl == "/updateBillOfLading"){
					window.location.href = '/Carrier.html';
				}else{
					if(fields.createdByUserRole == "Shipper"){
						window.location.href = '/Shipper.html';						
					}else if(fields.createdByUserRole == "Forwarder"){
						window.location.href = '/Forwarder.html';
					}
				}
            } else {
                alert(response.data.message);
            }
        });
    }
}]);

myApp.controller('login', ['$scope', '$http', '$window', function($scope, $http, $window) {
	
	var userInfo = {$class: "org.roi.User", userId: "", name: "", password: "", userRole:"" };
	$scope.userInfo = userInfo;

	$scope.userRoleTypes = ["Shipper", "Forwarder", "Carrier", "Bank", "Consignee"];
	
	$scope.userRoleForRegister = "Shipper";
	
	$scope.userRoleForLogin = "Shipper";

    $scope.Logout = function() {
        $window.location.href = '/LoginPage.html';        
    }
	
	$scope.submitRegisterationData = function () {
		$scope.userInfo.userRole = $scope.userRoleForRegister;
		$http({
            method: 'POST',
            url: '/createUser',
            data: $scope.userInfo
        }).then(function successCallback(response) {
			if (response.data.success == true) {
				window.location.href = '/LoginPage.html';					
			}else {
				alert(response.data.message);				
			}
		});
	}

    $scope.submitLoginData = function() {
        var userData = {
            username: $scope.loginUserId,
            password: $scope.loginPassword,
            role: $scope.userRoleForLogin
        }

        $http({
            method: 'POST',
            url: '/verifyLogin',
            data: userData
        }).then(function successCallback(response) {
            if (response.data.success == true) {
				if(response.data.userDetails[0].userRole == 'Shipper'){
					$window.sessionStorage.setItem("Username", response.data.userDetails[0].name);
					$window.sessionStorage.setItem("UserId", response.data.userDetails[0].userId);
					$window.sessionStorage.setItem("UserRole", response.data.userDetails[0].userRole);
					window.location.href = '/Shipper.html';				
				}else if(response.data.userDetails[0].userRole == 'Forwarder'){
					$window.sessionStorage.setItem("Username", response.data.userDetails[0].name);
					$window.sessionStorage.setItem("UserId", response.data.userDetails[0].userId);
					$window.sessionStorage.setItem("UserRole", response.data.userDetails[0].userRole);
					window.location.href = '/Forwarder.html';									
				}else if(response.data.userDetails[0].userRole == 'Carrier'){
					$window.sessionStorage.setItem("Username", response.data.userDetails[0].name);
					$window.sessionStorage.setItem("UserId", response.data.userDetails[0].userId);
					$window.sessionStorage.setItem("UserRole", response.data.userDetails[0].userRole);
					window.location.href = '/Carrier.html';									
				}else if(response.data.userDetails[0].userRole == 'Bank'){
					$window.sessionStorage.setItem("Username", response.data.userDetails[0].name);
					$window.sessionStorage.setItem("UserId", response.data.userDetails[0].userId);
					$window.sessionStorage.setItem("UserRole", response.data.userDetails[0].userRole);
					window.location.href = '/Bank.html';									
				}else if(response.data.userDetails[0].userRole == 'Consignee'){
					$window.sessionStorage.setItem("Username", response.data.userDetails[0].name);
					$window.sessionStorage.setItem("UserId", response.data.userDetails[0].userId);
					$window.sessionStorage.setItem("UserRole", response.data.userDetails[0].userRole);
					window.location.href = '/Consignee.html';									
				}else{
					alert("User not a present in the ledger");
				}
            } else {
                alert(response.data.message);
            }
        });
    }

}]);

myApp.controller('shipper', ['$scope', 'fileUpload', '$http', '$filter', '$window', function($scope, fileUpload, $http, $filter, $window) {
	
	function dateTime (){
		var now = new Date();
		return now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "T" + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
	}
	
	var uniqueId = Date.now();
	
	var timestamp = dateTime();
	
	var shipperContract = { $class: "org.roi.Contract", contractId: "S-"+uniqueId, contractData: "", createdByUserId: "", createdByUserName: "",
							createdByUserRole: "", assignedToUserId: "", assignedToUserName: "", assignedToRole: "", consignmentId: uniqueId,
							contractAmount: 0, contractCreationTimeStamp: timestamp, contractUpdationTimestamp: timestamp };
							
	var forwarderContract = { $class: "org.roi.Contract", contractId: "F-"+uniqueId, contractData: "", createdByUserId: "", createdByUserName: "",
							  createdByUserRole: "", assignedToUserId: "", assignedToUserName: "", assignedToRole: "", consignmentId: uniqueId,
							  contractAmount: 0, contractCreationTimeStamp: "", contractUpdationTimestamp: "" };
									   
	var billOfLading = { $class: "org.roi.BillOfLading", billOfLadingId: "BOL-"+uniqueId, billOfLadingData: "", carrierId: "", carrierContractAmount: "",
						 shipperId: "", forwarderId: "", forwarderContractAmount: "", bankId: "", consignmentId: "",
						 billOfLadingCreationTimeStamp: "", billOfLadingUpdationTimeStamp: "" };
						 
	var goods = { $class: "org.roi.Goods", goodsId: "G-"+uniqueId, goodsType: "", label: "", quantity: 0, mfgDate : "", consignmentId: uniqueId };
	
	var bank = { $class: "org.roi.BankData", bankConsignmentId: "BD-"+uniqueId, bankName: "", bankId: "", shipperId: "", amountDepositedByShipper: 0,
				 forwarderId: "", amountDepositedToForwarder: 0, carrierId: "", amountDepositedToCarrier: 0, consignmentId: uniqueId };
				 
	var status = { $class: "org.roi.Status", statusId: "ST-"+uniqueId, forwarderApprovedContract: "Pending", carrierApprovedContract: "Pending",
				   shipperBillOfLadingStatus: "Pending", forwarderBillOfLadingStatus: "Pending", bankBillOfLadingStatus: "Pending",
				   finalBillOfLadingStatus: "Pending", consignmentId: uniqueId, consignmentStatus: "Pending", consignmentMessage: "",
				   statusCreationTimeStamp: timestamp, statusUpdationTimeStamp: timestamp };

	var consignment = { $class: "org.roi.Consignment", consignmentId: uniqueId + '', consigneeId: "", consignmentType: "", consignmentCreationTimeStamp: 					timestamp, bank : bank, shipperContract : shipperContract, forwarderContract: forwarderContract , billOfLading : billOfLading, goods : 					  goods, status: status };
												
	$scope.consignment = consignment;
	
	$scope.consignmentType = ["Prepaid", "Postpaid"];;
	
	$scope.forwarders = null;
	$scope.banks = null;
	$scope.consignees = null;
	
    $scope.Logout = function() {
        window.location.href = '/LoginPage.html';        
    }
	
    $scope.reloadPage = function() {
        window.location.href = '/Shipper.html';        
    }
	
    $scope.getData = function() {	
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}		
        $http({
            method: 'POST',
            url: '/getInitDetails',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.forwarders = JSON.parse(response.data.initLoadData.forwarders);
				$scope.banks = JSON.parse(response.data.initLoadData.banks);
				$scope.consignees = JSON.parse(response.data.initLoadData.consignees);				
            } else {
                alert(response.data.message);
            }
        }); 
	}
	
	$scope.changedBankId = function(item){
		$scope.consignment.bank.bankName = item.name;
		$scope.consignment.bank.bankId = item.userId;
	}

	$scope.changedForwarderId = function(item){
		$scope.consignment.shipperContract.assignedToUserName = item.name;
		$scope.consignment.shipperContract.assignedToUserId = item.userId;
    }
	
	$scope.changedConsigneeId = function(item){
		$scope.consigneeName = item.name;
		$scope.consignment.consigneeId = item.userId;
    }
	
	$scope.consignment.shipperContract.createdByUserId = $window.sessionStorage.getItem("UserId");
	
	$scope.consignment.shipperContract.createdByUserName = $window.sessionStorage.getItem("Username");

    $scope.$watch('myFile', function(newFileObj) {
        if (newFileObj)
            $scope.filename = newFileObj.name;
    });

    $scope.submitShipperContractData = function() {
		$scope.consignment.status.consignmentMessage = "Consignment created with Id : " + $scope.consignment.consignmentId + " and shipper contract created with Id :" + $scope.consignment.shipperContract.contractId + " by userId : "+$window.sessionStorage.getItem("UserId");
		$scope.consignment.bank.shipperId = $scope.consignment.shipperContract.createdByUserId;
		$scope.consignment.shipperContract.createdByUserRole = "Shipper";
		$scope.consignment.shipperContract.assignedToRole = "Carrier";
        var file = $scope.myFile;					
        var uploadUrl = "/createConsignment";
        fileUpload.uploadFileAndFieldsToUrl(file, $scope.consignment, uploadUrl);
    }
	
    $scope.getPendingBillOfLadings = function() {
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}
        $http({
            method: 'POST',
            url: '/getPendingBillOfLadings',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.pendingBillOfLadings = JSON.parse(response.data.initLoadData);
            } else {
                alert(response.data.message);
            }
        });
    }
	
    $scope.getSelectedBillOfLadingDetails = function(clickedId) {	
		$window.sessionStorage.setItem("ConsignmentId", clickedId.consignmentId);
		window.location.href = '/Carrier_Read_Only.html';		
    }
	
    $scope.getContractsForRevision = function() {
        $http({
            method: 'GET',
            url: '/reviseContracts'
        }).then(function successCallback(response) {
            if (response.data.success) {
                $scope.revisionContracts = response.data.pendingContracts;
            } else {
                alert(response.data.message);
            }
        });
    }
	
    $scope.updateContractData = function(clickedId) {
		$window.sessionStorage.setItem("ConsignmentId", clickedId.consignmentId);
		window.location.href = '/ShipperContract.html';		
    }

}]);

myApp.controller('forwarder', ['$scope', 'fileUpload', '$http', '$filter', '$window', function($scope, fileUpload, $http, $filter, $window) {
	
	function dateTime (){
		var now = new Date();
		return now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "T" + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
	}
	
	var contractDataToBeUpdated = { consignmentId: "", statusId: "", contractId: "", contractData: "", assignedToUserId: "", assignedToUserName: "",
									createdByUserRole: "", createdByUserId: "", createdByUserName: "", contractAmount: "", timeStamp: "", message: "" } ;
									
	$scope.contractDataToBeUpdated = contractDataToBeUpdated;

    $scope.Logout = function() {
        window.location.href = '/LoginPage.html';        
    }
	
    $scope.reloadPage = function() {
        window.location.href = '/Carrier.html';        
    }
	
	$scope.forwarderId = $window.sessionStorage.getItem("UserId");
	
	$scope.forwarderName = $window.sessionStorage.getItem("Username");
	
	$scope.changedCarrierId = function(item){
		$scope.contractDataToBeUpdated.assignedToUserId = item.userId;
		$scope.carrierName = item.name;
    }
	
	$scope.changedConsignmentId = function(item){
		$scope.consignmentDataAsPerId = item;
    }
	
    $scope.getData = function() {
	
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}
		
        $http({
            method: 'POST',
            url: '/getInitDetails',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.carriers = JSON.parse(response.data.initLoadData.carriers);
				$scope.consignments = JSON.parse(response.data.initLoadData.consignments);				
            } else {
                alert(response.data.message);
            }
        }); 
	}
	
    $scope.$watch('myFile', function(newFileObj) {
        if (newFileObj)
            $scope.filename = newFileObj.name;
    });
	
    $scope.updateContract = function() {
	
		$scope.contractDataToBeUpdated.consignmentId = $scope.consignmentDataAsPerId.consignmentId;
		$scope.contractDataToBeUpdated.statusId = $scope.consignmentDataAsPerId.status.statusId;
		$scope.contractDataToBeUpdated.contractId = $scope.consignmentDataAsPerId.forwarderContract.contractId;
		$scope.contractDataToBeUpdated.assignedToUserName = $scope.carrierName;
		$scope.contractDataToBeUpdated.createdByUserRole = $window.sessionStorage.getItem("UserRole");
		$scope.contractDataToBeUpdated.createdByUserId = $window.sessionStorage.getItem("UserId");
		$scope.contractDataToBeUpdated.createdByUserName = $window.sessionStorage.getItem("Username");
		$scope.contractDataToBeUpdated.contractAmount = $scope.contractAmt;
		$scope.contractDataToBeUpdated.timeStamp = dateTime();
		$scope.contractDataToBeUpdated.message = "Forwarder contract created with Id : "+$scope.consignmentDataAsPerId.forwarderContract.contractId+ "in consignment with Id : "+$scope.consignmentDataAsPerId.consignmentId + "by userId : " +$window.sessionStorage.getItem("UserId");
        var file = $scope.myFile;					
        var uploadUrl = "/updateContract";
        fileUpload.uploadFileAndFieldsToUrl(file, $scope.contractDataToBeUpdated, uploadUrl);
	}
	
    $scope.getPendingBillOfLadings = function() {
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}
        $http({
            method: 'POST',
            url: '/getPendingBillOfLadings',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.pendingBillOfLadings = JSON.parse(response.data.initLoadData);
            } else {
                alert(response.data.message);
            }
        });
    }
	
    $scope.getSelectedBillOfLadingDetails = function(clickedId) {	
		$window.sessionStorage.setItem("ConsignmentId", clickedId.consignmentId);
		window.location.href = '/Carrier_Read_Only.html';		
    }
	
    $scope.getPendingContracts = function() {
	
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}		
	
        $http({
            method: 'POST',
            url: '/pendingContracts',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
                var pendingContracts = JSON.parse(response.data.initLoadData);
				$scope.pendingContracts = pendingContracts;
            } else {
                alert(response.data.message);
            }
        });
    }
	
    $scope.getContractData = function(clickedId) {
		$window.sessionStorage.setItem("ConsignmentId", clickedId.consignmentId);
		window.location.href = '/Shipper_Read_Only.html';			
    }
		
    $scope.getContractsForRevision = function() {
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}		
        $http({
            method: 'POST',
            url: '/reviseContracts',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
                $scope.revisionContracts = response.data.pendingContracts;
            } else {
                alert(response.data.message);
            }
        });
    }
	
    $scope.updateContractData = function(clickedId) {
		$window.sessionStorage.setItem("ConsignmentId", clickedId.consignmentId);
		window.location.href = '/Shipper_Update_Form.html';		
    }

}]);

myApp.controller('carrier', ['$scope', 'fileUpload', '$http', '$filter', '$window', function($scope, fileUpload, $http, $filter, $window) {
	
	function dateTime (){
		var now = new Date();
		return now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "T" + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
	}
	
	var updateBillOfLadingData = { $class: "org.roi.UpdateBillOfLading", consignment: "", billOfLading: "", status: "", billOfLadingData: "",
									 carrierId: "", carrierContractAmount: "", shipperId: "", forwarderId: "", forwarderContractAmount: "", bankId: "",
									 timeStamp: "", message: "" };
									 
	$scope.updateBillOfLadingData = updateBillOfLadingData;

    $scope.Logout = function() {
        window.location.href = '/LoginPage.html';        
    }

    $scope.reloadPage = function() {
        window.location.href = '/Carrier.html';        
    }
	
	$scope.changedConsignmentId = function(item){
		$scope.consignmentDataAsPerConId = item;
    }
	
	$scope.carrierId = $window.sessionStorage.getItem("UserId");
	
    $scope.getData = function() {
	
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}
		
        $http({
            method: 'POST',
            url: '/getInitDetails',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.consignments = JSON.parse(response.data.initLoadData.consignments);				
            } else {
                alert(response.data.message);
            }
        }); 
	}
	
    $scope.updateBillOfLading = function() {
		
		$scope.updateBillOfLadingData.consignment = "resource:org.roi.Consignment#"+$scope.consignmentDataAsPerConId.consignmentId;
		$scope.updateBillOfLadingData.billOfLading = "resource:org.roi.BillOfLading#"+$scope.consignmentDataAsPerConId.billOfLading.billOfLadingId;
		$scope.updateBillOfLadingData.status = "resource:org.roi.Status#"+$scope.consignmentDataAsPerConId.status.statusId;
		$scope.updateBillOfLadingData.carrierId = $window.sessionStorage.getItem("UserId");
		$scope.updateBillOfLadingData.carrierContractAmount = $scope.consignmentDataAsPerConId.forwarderContract.contractAmount;
		$scope.updateBillOfLadingData.shipperId = $scope.consignmentDataAsPerConId.shipperContract.createdByUserId;
		$scope.updateBillOfLadingData.forwarderId = $scope.consignmentDataAsPerConId.forwarderContract.createdByUserId;
		$scope.updateBillOfLadingData.forwarderContractAmount = $scope.consignmentDataAsPerConId.shipperContract.contractAmount;
		$scope.updateBillOfLadingData.bankId = $scope.consignmentDataAsPerConId.bank.bankId;
		$scope.updateBillOfLadingData.timeStamp = dateTime();
		$scope.updateBillOfLadingData.message = "Bill of Lading created with Id : "+$scope.consignmentDataAsPerConId.billOfLading.billOfLadingId+" in consignment with Id : "+$scope.consignmentDataAsPerConId.consignmentId+" by user Id : "+$window.sessionStorage.getItem("UserId");

        var file = $scope.myFile;					
        var uploadUrl = "/updateBillOfLading";
        fileUpload.uploadFileAndFieldsToUrl(file, $scope.updateBillOfLadingData, uploadUrl);		
	}
	
    $scope.$watch('myFile', function(newFileObj) {
        if (newFileObj)
            $scope.filename = newFileObj.name;
    });
	
    $scope.getPendingContracts = function() {
	
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}		
	
        $http({
            method: 'POST',
            url: '/pendingContracts',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
                var pendingContracts = JSON.parse(response.data.initLoadData);
				$scope.pendingContracts = pendingContracts;
            } else {
                alert(response.data.message);
            }
        });
    }
	
    $scope.getContractData = function(clickedId) {
		$window.sessionStorage.setItem("ConsignmentId", clickedId.consignmentId);
		window.location.href = '/Forwarder_Read_Only.html';			
    }

}]);

myApp.controller('bank', ['$scope', '$http', '$window', function($scope, $http, $window) {

    $scope.Logout = function() {
        $window.location.href = '/LoginPage.html';        
    }
	
	$scope.bankId = $window.sessionStorage.getItem("UserId");

    $scope.getPendingBillOfLadings = function() {
		var data = {
			userRole : $window.sessionStorage.getItem("UserRole"),
			userId : $window.sessionStorage.getItem("UserId")
		}
        $http({
            method: 'POST',
            url: '/getPendingBillOfLadings',
			data: data
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.pendingBillOfLadings = JSON.parse(response.data.initLoadData);
            } else {
                alert(response.data.message);
            }
        });
    }
	
    $scope.getConsignmentDetails = function() {

        $http({
            method: 'POST',
            url: '/getAllConsignment'
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.consignmentData = JSON.parse(response.data.initLoadData);
            } else {
                alert(response.data.message);
            }
        });
    }
	
    $scope.getSelectedBillOfLadingDetails = function(clickedId) {	
		$window.sessionStorage.setItem("ConsignmentId", clickedId.consignmentId);
		window.location.href = '/Carrier_Read_Only.html';		
    }

}]);

myApp.controller('shipperReadOnly', ['$scope', '$http', '$window', function($scope, $http, $window) {
	
	function dateTime (){
		var now = new Date();
		return now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "T" + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
	}
	
	$scope.showContractImage = function() {
		var imageData= 'data:image/jpeg;base64,'+$scope.shipperData.shipperContract.contractData;
		var newTab = window.open();
		newTab.document.body.innerHTML = '<img src="'+imageData+'" width="100px" height="100px">';
    }
	
	var updateContractStatus = { $class: "org.roi.UpdateContractStatus", consignmentId: "", statusId: "", bankId: "", userRoleUpdatingStatus: "",
								 userIdUpdatingStatus: "", message: "", timeStamp: "", contractStatus: "", contractAmount: "" };
								 
	$scope.updateContractStatusData = updateContractStatus;

    $scope.Logout = function() {
        $window.location.href = '/LoginPage.html';        
    }
	
    $scope.Back = function() {
		$window.location.href = '/Forwarder.html';			
    }
		
	$scope.forwarderId = $window.sessionStorage.getItem("UserId");
		
    $scope.getConsignmentData = function() {

        $http({
            method: 'POST',
            url: '/getConsignmentDetails',
            data: {consignmentId : $window.sessionStorage.getItem("ConsignmentId")}
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.shipperData = JSON.parse(response.data.initLoadData);
            } else {
                alert(response.data.message);
            }
        });
    }
	
	$scope.updateContractStatus = function(buttonValue) {
		if(buttonValue == "Approve"){
			$scope.updateContractStatusData.contractStatus = "Approved";
			$scope.updateContractStatusData.message = "Contract Id : " + $scope.shipperData.shipperContract.contractId + " has been approved in consignment Id : " + $scope.shipperData.consignmentId + " by forwarder with userId : "+ $window.sessionStorage.getItem("UserId");
		}else if(buttonvalue == "Revise"){
			$scope.updateContractStatusData.contractStatus = "Revise";
			$scope.updateContractStatusData.message = "Contract Id : " + $scope.shipperData.shipperContract.contractId + " has been sent back for revision in consignment Id : " + $scope.shipperData.consignmentId + " by forwarder with userId : "+ $window.sessionStorage.getItem("UserId");			
		}
		$scope.updateContractStatusData.consignmentId = $scope.shipperData.consignmentId;
		$scope.updateContractStatusData.statusId = $scope.shipperData.status.statusId;
		$scope.updateContractStatusData.bankId = $scope.shipperData.bank.bankConsignmentId;
		$scope.updateContractStatusData.userRoleUpdatingStatus = $window.sessionStorage.getItem("UserRole");
		$scope.updateContractStatusData.userIdUpdatingStatus = $window.sessionStorage.getItem("UserId");
		$scope.updateContractStatusData.timeStamp = dateTime();
		$scope.updateContractStatusData.contractAmount = $scope.shipperData.shipperContract.contractAmount;
        $http({
            method: 'POST',
            url: '/updateContractStatus',
            data: {data : JSON.stringify($scope.updateContractStatusData)}
        }).then(function successCallback(response) {
            if (response.data.success) {
                window.location.href = '/Forwarder.html';
            } else {
                alert(response.data.message);
            }
        });
    }

}]);

myApp.controller('forwarderReadOnly', ['$scope', '$http', '$window', function($scope, $http, $window) {

	function dateTime (){
		var now = new Date();
		return now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "T" + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
	}
	
	var updateContractStatus = { $class: "org.roi.UpdateContractStatus", consignmentId: "", statusId: "", bankId: "", userRoleUpdatingStatus: "",
								 userIdUpdatingStatus: "", message: "", timeStamp: "", contractStatus: "", contractAmount: "" };
								 
	$scope.updateContractStatusData = updateContractStatus;

    $scope.Logout = function() {
        $window.location.href = '/LoginPage.html';        
    }

	$scope.carrierId = $window.sessionStorage.getItem("UserId");
	
    $scope.Back = function() {
		$window.location.href = '/Carrier.html';			
    }

    $scope.getConsignmentData = function() {

        $http({
            method: 'POST',
            url: '/getConsignmentDetails',
            data: {consignmentId : $window.sessionStorage.getItem("ConsignmentId")}
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.forwarderData = JSON.parse(response.data.initLoadData);
            } else {
                alert(response.data.message);
            }
        });
    }
	
	$scope.showContractImage = function() {
		var imageData= 'data:image/jpeg;base64,'+$scope.forwarderData.forwarderContract.contractData;
		var newTab = window.open();
		newTab.document.body.innerHTML = '<img src="'+imageData+'" width="100px" height="100px">';
    }
	
	$scope.updateContractStatus = function(buttonValue) {
		if(buttonValue == "Approve"){
			$scope.updateContractStatusData.contractStatus = "Approved";
			$scope.updateContractStatusData.message = "Contract Id : " + $scope.forwarderData.forwarderContract.contractId + " has been approved in consignment Id : " + $scope.forwarderData.consignmentId + " by carrier with userId : "+ $window.sessionStorage.getItem("UserId");
		}else if(buttonvalue == "Revise"){
			$scope.updateContractStatusData.contractStatus = "Revise";
			$scope.updateContractStatusData.message = "Contract Id : " + $scope.forwarderData.forwarderContract.contractId + " has been sent back for revision in consignment Id : " + $scope.forwarderContract.consignmentId + " by carrier with userId : "+ $window.sessionStorage.getItem("UserId");	
		}
		$scope.updateContractStatusData.consignmentId = $scope.forwarderData.consignmentId;
		$scope.updateContractStatusData.statusId = $scope.forwarderData.status.statusId;
		$scope.updateContractStatusData.bankId = $scope.forwarderData.bank.bankConsignmentId;
		$scope.updateContractStatusData.userRoleUpdatingStatus = $window.sessionStorage.getItem("UserRole");
		$scope.updateContractStatusData.userIdUpdatingStatus = $window.sessionStorage.getItem("UserId");
		$scope.updateContractStatusData.timeStamp = dateTime();
		$scope.updateContractStatusData.contractAmount = $scope.forwarderData.forwarderContract.contractAmount;
        $http({
            method: 'POST',
            url: '/updateContractStatus',
            data: {data : JSON.stringify($scope.updateContractStatusData)}
        }).then(function successCallback(response) {
            if (response.data.success) {
                window.location.href = '/Carrier.html';
            } else {
                alert(response.data.message);
            }
        });
    }

}]);

myApp.controller('billOfLadingReadOnly', ['$scope', '$http', '$window', function($scope, $http, $window) {

	function dateTime (){
		var now = new Date();
		return now.getFullYear() + "-" + (now.getMonth() + 1) + "-" + now.getDate() + "T" + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
	}
	
	var updateBillOfLadingStatus = { $class: "org.roi.UpdateContractStatus", consignment: "", status: "", bank: "", userRoleUpdatingStatus: "",
									 userIdUpdatingStatus: "", message: "", timeStamp: "", userBillOfLadingStatus: "", finalBillOfLadingStatus: "",
									 forwarderContractAmount: "", carrierContractAmount: "" };
								 
	$scope.updateBillOfLadingStatus = updateBillOfLadingStatus;
	
	$scope.userRole = $window.sessionStorage.getItem("UserRole");
	$scope.userId = $window.sessionStorage.getItem("UserId");

    $scope.Logout = function() {
        $window.location.href = '/LoginPage.html';        
    }
	
	$scope.showContractImage = function() {
		var imageData= 'data:image/jpeg;base64,'+$scope.billOfLadingData.billOfLading.billOfLadingData;
		var newTab = window.open();
		newTab.document.body.innerHTML = '<img src="'+imageData+'" width="100px" height="100px">';
    }
	
    $scope.Back = function() {
		if($scope.userRole == "Shipper"){
			$window.location.href = '/Shipper.html';
		}else if($scope.userRole == "Forwarder"){
			$window.location.href = '/Forwarder.html';
		}else if($scope.userRole == "Bank"){
			$window.location.href = '/Bank.html';
		}
    }

    $scope.getConsignmentData = function() {

        $http({
            method: 'POST',
            url: '/getConsignmentDetails',
            data: {consignmentId : $window.sessionStorage.getItem("ConsignmentId")}
        }).then(function successCallback(response) {
            if (response.data.success) {
				$scope.billOfLadingData = JSON.parse(response.data.initLoadData);
            } else {
                alert(response.data.message);
            }
        });
    }
	
	$scope.updateLadingStatus = function(buttonValue) {
		if(buttonValue == "Approve"){
			$scope.updateBillOfLadingStatus.userBillOfLadingStatus = "Approved";
			$scope.updateBillOfLadingStatus.message = "Bill Of Lading : " + $scope.billOfLadingData.billOfLading.billOfLadingId + " has been approved in consignment Id : " + $scope.billOfLadingData.consignmentId + " by " + $window.sessionStorage.getItem("UserRole") + " with userId : "+ $window.sessionStorage.getItem("UserId");
		}else if(buttonvalue == "Revise"){
			$scope.updateBillOfLadingStatus.userBillOfLadingStatus = "Revise";
			$scope.updateBillOfLadingStatus.message = "Bill Of Lading Id : " + $scope.billOfLadingData.billOfLading.billOfLadingId + " has been sent back for revision in consignment Id : " + $scope.billOfLading.consignmentId + " by carrier with userId : "+ $window.sessionStorage.getItem("UserId");
		}
		$scope.updateBillOfLadingStatus.consignment = $scope.billOfLadingData.consignmentId;
		$scope.updateBillOfLadingStatus.status = $scope.billOfLadingData.status.statusId;
		$scope.updateBillOfLadingStatus.bank = $scope.billOfLadingData.bank.bankConsignmentId;
		$scope.updateBillOfLadingStatus.userRoleUpdatingStatus = $window.sessionStorage.getItem("UserRole");
		$scope.updateBillOfLadingStatus.userIdUpdatingStatus = $window.sessionStorage.getItem("UserId");
		$scope.updateBillOfLadingStatus.timeStamp = dateTime();
		$scope.updateBillOfLadingStatus.forwarderContractAmount = $scope.billOfLadingData.billOfLading.forwarderContractAmount;
		$scope.updateBillOfLadingStatus.carrierContractAmount = $scope.billOfLadingData.billOfLading.carrierContractAmount;
		if($scope.userRole == "Shipper" && $scope.updateBillOfLadingStatus.userBillOfLadingStatus == "Approved" &&	$scope.billOfLadingData.status.forwarderBillOfLadingStatus == "Approved" && $scope.billOfLadingData.status.bankBillOfLadingStatus == "Approved"){
			$scope.updateBillOfLadingStatus.finalBillOfLadingStatus = "Approved";
		}else if($scope.userRole == "Forwarder" && $scope.updateBillOfLadingStatus.userBillOfLadingStatus == "Approved" &&	$scope.billOfLadingData.status.shipperBillOfLadingStatus == "Approved" && $scope.billOfLadingData.status.bankBillOfLadingStatus == "Approved"){
			$scope.updateBillOfLadingStatus.finalBillOfLadingStatus = "Approved";
		}else if($scope.userRole == "Bank" && $scope.updateBillOfLadingStatus.userBillOfLadingStatus == "Approved" &&	$scope.billOfLadingData.status.forwarderBillOfLadingStatus == "Approved" && $scope.billOfLadingData.status.shipperBillOfLadingStatus == "Approved"){
			$scope.updateBillOfLadingStatus.finalBillOfLadingStatus = "Approved";
		}else{
			$scope.updateBillOfLadingStatus.finalBillOfLadingStatus = $scope.billOfLadingData.status.finalBillOfLadingStatus;			
		}
        $http({
            method: 'POST',
            url: '/updateBillOfLadingStatus',
            data: { data : JSON.stringify($scope.updateBillOfLadingStatus)}
        }).then(function successCallback(response) {
            if (response.data.success) {
				if($scope.userRole == "Shipper"){
					$window.location.href = '/Shipper.html';
				}else if($scope.userRole == "Forwarder"){
					$window.location.href = '/Forwarder.html';
				}else if($scope.userRole == "Bank"){
					$window.location.href = '/Bank.html';
				}
            } else {
                alert(response.data.message);
            }
        });
    }

}]);
